"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-mwrzahmf.js
function mediaHashFromUri2(uri) {
  if (!uri)
    return;
  return MEDIA_REF.exec(uri)?.[1];
}
function withMediaRefs2(api2) {
  return {
    ...api2,
    message: {
      ...api2.message,
      list: (input2, options2) => api2.message.list(input2, mediaRefOptions(options2))
    },
    session: {
      ...api2.session,
      message: {
        ...api2.session.message,
        get: (input2, options2) => api2.session.message.get(input2, mediaRefOptions(options2))
      },
      inbox: {
        ...api2.session.inbox,
        list: (input2, options2) => api2.session.inbox.list(input2, mediaRefOptions(options2))
      }
    }
  };
}
function mediaRefOptions(options2) {
  if (options2?.mediaRefs === false)
    return options2;
  const headers = new Headers(options2?.headers);
  headers.set(CAPABILITIES_HEADER, MEDIA_URI_CAPABILITY);
  return { ...options2, headers };
}
var MEDIA_URI_CAPABILITY, CAPABILITIES_HEADER, MEDIA_REF;
var init_rpc_runtime_mwrzahmf = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-mwrzahmf.js"() {
    MEDIA_URI_CAPABILITY = "experimental-media-uri";
    CAPABILITIES_HEADER = "X-OpenCode-Capabilities";
    MEDIA_REF = /^media:([0-9a-f]{64})$/;
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-9rqn6x4v.js
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __defProp2, __returnValue, __export2;
var init_rpc_runtime_9rqn6x4v = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-9rqn6x4v.js"() {
    __defProp2 = Object.defineProperty;
    __returnValue = (v) => v;
    __export2 = (target, all) => {
      for (var name in all)
        __defProp2(target, name, {
          get: all[name],
          enumerable: true,
          configurable: true,
          set: __exportSetter.bind(all, name)
        });
    };
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-gecjxyvt.js
function make7(connect2) {
  let current;
  const capacity = 4096;
  function stop2(connection) {
    connection.connected = void 0;
    connection.controller.abort();
    if (current === connection)
      current = void 0;
  }
  async function run(connection) {
    let iterator;
    let completion = {};
    try {
      if (connection.controller.signal.aborted)
        return;
      iterator = connect2(connection.controller.signal, () => {
        connection.subscribers.forEach((subscriber) => subscriber.activity?.());
      })[Symbol.asyncIterator]();
      while (!connection.controller.signal.aborted) {
        const item = await iterator.next();
        if (item.done || connection.controller.signal.aborted)
          break;
        if (item.value.type === "server.connected")
          connection.connected = item.value;
        connection.subscribers.forEach((subscriber) => subscriber.push(item.value));
      }
    } catch (error) {
      completion = { error };
    } finally {
      stop2(connection);
      try {
        await iterator?.return?.();
      } catch (error) {
        if (!("error" in completion))
          completion = { error };
      }
      connection.subscribers.forEach((subscriber) => subscriber.finish(completion));
    }
  }
  return {
    subscribe(options2) {
      return {
        [Symbol.asyncIterator]() {
          const pending = [];
          const queued = [];
          let started = false;
          let completion;
          let connection;
          const types = options2?.types?.length ? new Set(options2.types) : void 0;
          const selected = (value) => !types || value.type === "server.connected" || types.has(value.type);
          function finish(result, discard = true) {
            completion = result;
            if (discard)
              queued.length = 0;
            options2?.signal?.removeEventListener("abort", abort);
            if (connection?.subscribers.delete(subscriber) && !connection.subscribers.size)
              stop2(connection);
            pending.splice(0).forEach((request) => {
              if ("error" in result)
                request.reject(result.error);
              else
                request.resolve({ done: true, value: void 0 });
            });
          }
          function abort() {
            finish({});
          }
          const subscriber = {
            activity: options2?.onActivity,
            finish(result) {
              finish(result, false);
            },
            push(value) {
              if (completion)
                return;
              if (!selected(value))
                return;
              const request = pending.shift();
              if (request) {
                request.resolve({ done: false, value });
                return;
              }
              if (queued.length === capacity) {
                finish({ error: new Error(`Event subscriber exceeded its ${capacity}-event capacity`) });
                return;
              }
              queued.push(value);
            }
          };
          function start() {
            if (completion)
              return;
            const fresh = !current;
            connection = current ?? {
              controller: new AbortController(),
              subscribers: /* @__PURE__ */ new Set()
            };
            current = connection;
            connection.subscribers.add(subscriber);
            if (connection.connected)
              subscriber.push(connection.connected);
            if (fresh)
              run(connection);
          }
          return {
            next() {
              const value = queued.shift();
              if (value)
                return Promise.resolve({ done: false, value });
              if (completion) {
                if ("error" in completion)
                  return Promise.reject(completion.error);
                return Promise.resolve({ done: true, value: void 0 });
              }
              if (options2?.signal?.aborted) {
                abort();
                return Promise.resolve({ done: true, value: void 0 });
              }
              const request = Promise.withResolvers();
              pending.push(request);
              if (!started) {
                started = true;
                options2?.signal?.addEventListener("abort", abort, { once: true });
                start();
              }
              return request.promise;
            },
            return() {
              finish({});
              return Promise.resolve({ done: true, value: void 0 });
            }
          };
        }
      };
    }
  };
}
var exports_shared_events;
var init_rpc_runtime_gecjxyvt = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-gecjxyvt.js"() {
    init_rpc_runtime_9rqn6x4v();
    exports_shared_events = {};
    __export2(exports_shared_events, {
      SharedEvents: () => exports_shared_events,
      make: () => make7
    });
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-js54wxgp.js
var ClientError2;
var init_rpc_runtime_js54wxgp = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-js54wxgp.js"() {
    ClientError2 = class extends Error {
      reason;
      name = "ClientError";
      constructor(reason, options2) {
        const detail = options2?.detail ?? (options2?.cause instanceof Error ? options2.cause.message : void 0);
        super(detail ? `${reason}: ${detail}` : reason, options2);
        this.reason = reason;
      }
    };
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-t2ajednw.js
function make3(options2) {
  const fetch2 = options2.fetch ?? globalThis.fetch;
  const prepare = (descriptor, requestOptions) => {
    const baseUrl = new URL(options2.baseUrl);
    if (!baseUrl.pathname.endsWith("/"))
      baseUrl.pathname += "/";
    const url = new URL(descriptor.path.slice(1), baseUrl);
    for (const [key, value] of Object.entries(descriptor.query ?? {}))
      appendQuery(url.searchParams, key, value);
    const headers = new Headers(options2.headers);
    for (const [key, value] of Object.entries(descriptor.headers ?? {})) {
      if (value !== void 0 && value !== null)
        headers.set(key, String(value));
    }
    for (const [key, value] of new Headers(requestOptions?.headers))
      headers.set(key, value);
    if (descriptor.body !== void 0 && !headers.has("content-type"))
      headers.set("content-type", descriptor.binaryBody ? "application/octet-stream" : "application/json");
    return {
      url,
      init: {
        method: descriptor.method,
        signal: requestOptions?.signal,
        headers,
        body: descriptor.body === void 0 ? void 0 : descriptor.binaryBody ? descriptor.body : JSON.stringify(descriptor.body)
      }
    };
  };
  const execute = async (descriptor, requestOptions) => {
    try {
      const prepared = prepare(descriptor, requestOptions);
      return await fetch2(prepared.url, prepared.init);
    } catch (cause) {
      throw new ClientError2("Transport", { cause });
    }
  };
  const responseError = async (response, descriptor) => {
    if (descriptor.declaredStatuses.includes(response.status))
      throw declared(await json(response));
    try {
      await response.body?.cancel();
    } catch {
    }
    throw new ClientError2("UnexpectedStatus", { cause: { status: response.status }, detail: String(response.status) });
  };
  const request = async (descriptor, requestOptions) => {
    const response = await execute(descriptor, requestOptions);
    if (response.status !== descriptor.successStatus)
      return responseError(response, descriptor);
    if (descriptor.binary)
      return new Uint8Array(await response.arrayBuffer());
    if (descriptor.empty) {
      try {
        await response.body?.cancel();
      } catch {
      }
      return;
    }
    return await json(response);
  };
  const sse = (descriptor, requestOptions) => ({
    async *[Symbol.asyncIterator]() {
      const response = await execute(descriptor, requestOptions);
      if (response.status !== descriptor.successStatus)
        await responseError(response, descriptor);
      if (!isContentType(response, "text/event-stream")) {
        try {
          await response.body?.cancel();
        } catch {
        }
        throw new ClientError2("UnsupportedContentType", { detail: response.headers.get("content-type") });
      }
      if (response.body === null)
        throw new ClientError2("MalformedResponse");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      try {
        while (true) {
          let next;
          try {
            next = await reader.read();
          } catch (cause) {
            throw new ClientError2("Transport", { cause });
          }
          if (!next.done)
            requestOptions?.onActivity?.();
          buffer += decoder.decode(next.value, { stream: !next.done });
          if (buffer.length > maxSseEventBytes)
            throw new ClientError2("SseEventTooLarge");
          const trailingCarriageReturn = !next.done && buffer.endsWith("\r");
          if (trailingCarriageReturn)
            buffer = buffer.slice(0, -1);
          buffer = buffer.replaceAll(`\r
`, `
`).replaceAll("\r", `
`);
          if (trailingCarriageReturn)
            buffer += "\r";
          if (next.done && buffer !== "")
            buffer += `

`;
          let boundary = buffer.indexOf(`

`);
          while (boundary >= 0) {
            const block = buffer.slice(0, boundary);
            buffer = buffer.slice(boundary + 2);
            const data = block.split(`
`).flatMap((line) => line.startsWith("data:") ? [line.slice(5).trimStart()] : []).join(`
`);
            if (data !== "") {
              try {
                yield JSON.parse(data);
              } catch (cause) {
                throw new ClientError2("MalformedResponse", { cause });
              }
            }
            boundary = buffer.indexOf(`

`);
          }
          if (next.done)
            return;
        }
      } finally {
        try {
          await reader.cancel();
        } catch {
        }
        reader.releaseLock();
      }
    }
  });
  const client2 = {
    server: {
      info: (requestOptions) => request({ method: "GET", path: `/api/info`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions),
      pair: (requestOptions) => request({ method: "POST", path: `/api/pair`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions),
      connect: (input2, requestOptions) => request({
        method: "GET",
        path: `/auth/connect/${encodeURIComponent(input2.code)}`,
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions)
    },
    location: {
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/location`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      reload: (requestOptions) => request({
        method: "POST",
        path: `/api/location/reload`,
        successStatus: 204,
        declaredStatuses: [400, 401, 503],
        empty: true
      }, requestOptions)
    },
    agent: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/agent`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/agent/${encodeURIComponent(input2.agentID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    plugin: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/plugin`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      gui: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/plugin/gui`,
        query: { location: input2["location"], id: input2["id"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      check: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/plugin/check`,
        query: { location: input2?.["location"] },
        body: { target: input2?.["target"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      update: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/plugin/update`,
        query: { location: input2["location"] },
        body: { targets: input2["targets"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 503],
        empty: true
      }, requestOptions)
    },
    session: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session`,
        query: {
          limit: input2?.["limit"],
          order: input2?.["order"],
          search: input2?.["search"],
          parentID: input2?.["parentID"],
          archived: input2?.["archived"],
          directory: input2?.["directory"],
          project: input2?.["project"],
          subpath: input2?.["subpath"],
          cursor: input2?.["cursor"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session`,
        body: {
          id: input2?.["id"],
          parentID: input2?.["parentID"],
          title: input2?.["title"],
          agent: input2?.["agent"],
          model: input2?.["model"],
          location: input2?.["location"],
          metadata: input2?.["metadata"],
          permissions: input2?.["permissions"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      active: (requestOptions) => request({
        method: "GET",
        path: `/api/session/active`,
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions).then((value) => value.data),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      remove: (input2, requestOptions) => request({
        method: "DELETE",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}`,
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      fork: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/fork`,
        body: { before: input2["before"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      switchAgent: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/agent`,
        body: { agent: input2["agent"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      switchModel: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/model`,
        body: { model: input2["model"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      update: (input2, requestOptions) => request({
        method: "PATCH",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}`,
        body: {
          title: input2["title"],
          metadata: input2["metadata"],
          permissions: input2["permissions"],
          archived: input2["archived"]
        },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      move: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/move`,
        body: { directory: input2["directory"], delivery: input2["delivery"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      prompt: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/prompt`,
        body: {
          id: input2["id"],
          text: input2["text"],
          files: input2["files"],
          agents: input2["agents"],
          skills: input2["skills"],
          metadata: input2["metadata"],
          delivery: input2["delivery"],
          resume: input2["resume"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      command: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/command`,
        body: {
          name: input2["name"],
          text: input2["text"],
          files: input2["files"],
          agents: input2["agents"],
          skills: input2["skills"],
          delivery: input2["delivery"]
        },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 500],
        empty: true
      }, requestOptions),
      synthetic: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/synthetic`,
        body: {
          id: input2["id"],
          text: input2["text"],
          description: input2["description"],
          metadata: input2["metadata"],
          delivery: input2["delivery"],
          resume: input2["resume"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      shell: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/shell`,
        body: { id: input2["id"], command: input2["command"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      compact: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/compact`,
        body: { id: input2["id"], delivery: input2["delivery"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      revert: {
        stage: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/revert/stage`,
          body: { messageID: input2["messageID"], files: input2["files"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409, 500],
          empty: false
        }, requestOptions).then((value) => value.data),
        clear: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/revert`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409, 500],
          empty: true
        }, requestOptions),
        commit: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/revert/commit`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      context: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/context`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions).then((value) => value.data),
      diff: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/diff`,
        query: { from: input2["from"], to: input2["to"], context: input2["context"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions).then((value) => value.data),
      inbox: {
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/inbox`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        cancel: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/inbox/${encodeURIComponent(input2.inboxID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        update: (input2, requestOptions) => request({
          method: "PATCH",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/inbox/${encodeURIComponent(input2.inboxID)}`,
          body: { delivery: input2["delivery"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      generate: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/generate`,
        body: { prompt: input2["prompt"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions).then((value) => value.data),
      interrupt: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/interrupt`,
        query: { resume: input2["resume"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      background: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/background`,
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      message: {
        get: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/message/${encodeURIComponent(input2.messageID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      form: {
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        create: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form`,
          body: { id: input2["id"], title: input2["title"], metadata: input2["metadata"], fields: input2["fields"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        get: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form/${encodeURIComponent(input2.formID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        reply: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form/${encodeURIComponent(input2.formID)}/reply`,
          body: { answer: input2["answer"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions),
        cancel: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form/${encodeURIComponent(input2.formID)}`,
          query: { message: input2["message"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      environment: (input2, requestOptions) => request({
        method: "PUT",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/environment`,
        body: { variables: input2["variables"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      view: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/view`,
        body: { idle: input2["idle"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    experimental: {
      session: {
        stats: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/session/stats`,
          query: {
            from: input2?.["from"],
            to: input2?.["to"],
            project: input2?.["project"],
            timezone: input2?.["timezone"],
            tools: input2?.["tools"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401],
          empty: false
        }, requestOptions).then((value) => value.data),
        import: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/session/import`,
          body: { info: input2["info"], messages: input2["messages"], location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        export: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/export`,
          query: { sanitize: input2["sanitize"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 500],
          empty: false
        }, requestOptions).then((value) => value.data),
        skill: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/skill`,
          body: { id: input2["id"], resume: input2["resume"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        wait: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/wait`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        instructions: {
          entry: {
            list: (input2, requestOptions) => request({
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/instructions/entries`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false
            }, requestOptions).then((value) => value.data),
            put: (input2, requestOptions) => request({
              method: "PUT",
              path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/instructions/entries/${encodeURIComponent(input2.key)}`,
              body: { value: input2["value"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 413],
              empty: true
            }, requestOptions),
            remove: (input2, requestOptions) => request({
              method: "DELETE",
              path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/instructions/entries/${encodeURIComponent(input2.key)}`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true
            }, requestOptions)
          }
        },
        log: (input2, requestOptions) => sse({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/log`,
          query: { after: input2["after"], follow: input2["follow"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      generate: {
        text: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/generate/text`,
          body: { prompt: input2["prompt"], model: input2["model"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        image: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/generate/image`,
          body: {
            model: input2["model"],
            prompt: input2["prompt"],
            images: input2["images"],
            n: input2["n"],
            aspect: input2["aspect"],
            resolution: input2["resolution"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        decisions: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/generate/decisions`,
          body: { model: input2["model"], input: input2["input"], questions: input2["questions"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      voice: {
        models: (requestOptions) => request({
          method: "GET",
          path: `/api/experimental/voice/models`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        session: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/voice/session`,
          body: { model: input2["model"], session: input2["session"], transport: input2["transport"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      integration: {
        wellknown: {
          add: (input2, requestOptions) => request({
            method: "POST",
            path: `/api/experimental/integration/wellknown`,
            query: { location: input2["location"] },
            body: { url: input2["url"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true
          }, requestOptions)
        }
      },
      mcp: {
        add: (input2, requestOptions) => request({
          method: "PUT",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}`,
          query: { location: input2["location"] },
          body: { config: input2["config"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        remove: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        connect: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}/connect`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        disconnect: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}/disconnect`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        client: {
          token: (input2, requestOptions) => request({
            method: "POST",
            path: `/api/experimental/client-mcp/token`,
            query: { location: input2["location"], name: input2["name"] },
            headers: { "x-opencode-ticket": input2["x-opencode-ticket"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 403, 404],
            empty: false
          }, requestOptions)
        }
      },
      file: {
        write: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/fs/write`,
          query: { location: input2["location"], path: input2["path"] },
          body: input2["payload"],
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false,
          binaryBody: true
        }, requestOptions),
        watch: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/fs/watch`,
          query: { location: input2["location"] },
          body: { path: input2["path"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        unwatch: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/experimental/fs/watch`,
          query: { location: input2["location"] },
          body: { path: input2["path"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      persistentPty: {
        read: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/terminal/read`,
          query: { lines: input2["lines"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/terminal`,
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        create: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/terminal`,
          body: {
            command: input2["command"],
            args: input2["args"],
            cwd: input2["cwd"],
            title: input2["title"],
            env: input2["env"],
            size: input2["size"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        shutdown: (requestOptions) => request({
          method: "POST",
          path: `/api/experimental/persistent-pty/shutdown`,
          successStatus: 204,
          declaredStatuses: [400, 401, 503],
          empty: true
        }, requestOptions),
        handoff: (requestOptions) => request({
          method: "POST",
          path: `/api/experimental/persistent-pty/handoff`,
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions),
        get: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        update: (input2, requestOptions) => request({
          method: "PUT",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}`,
          body: { attachmentID: input2["attachmentID"], size: input2["size"], title: input2["title"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 501, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        snapshot: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}/snapshot`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        remove: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        connectToken: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}/connect-token`,
          headers: { "x-opencode-ticket": input2["x-opencode-ticket"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      media: {
        get: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/media/${encodeURIComponent(input2.hash)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false,
          binary: true
        }, requestOptions)
      },
      schedule: {
        create: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/schedule`,
          body: {
            sessionID: input2["sessionID"],
            name: input2["name"],
            when: input2["when"],
            if: input2["if"],
            until: input2["until"],
            ends: input2["ends"],
            prompt: input2["prompt"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/schedule`,
          query: { sessionID: input2["sessionID"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        get: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        pause: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}/pause`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        resume: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}/resume`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        delete: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 403, 404],
          empty: true
        }, requestOptions)
      },
      artifacts: {
        providers: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/artifacts/providers`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/artifacts`,
          query: { location: input2?.["location"], sessionID: input2?.["sessionID"], provider: input2?.["provider"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        create: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/experimental/artifacts`,
          query: { location: input2["location"] },
          body: {
            title: input2["title"],
            files: input2["files"],
            entry: input2["entry"],
            provider: input2["provider"],
            sessionID: input2["sessionID"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        get: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        update: (input2, requestOptions) => request({
          method: "PATCH",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}`,
          query: { location: input2["location"] },
          body: {
            title: input2["title"],
            files: input2["files"],
            entry: input2["entry"],
            sessionID: input2["sessionID"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        delete: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: true
        }, requestOptions),
        view: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}/view/${encodePath(input2.path)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false,
          binary: true
        }, requestOptions)
      },
      migration: {
        v1: {
          status: (requestOptions) => request({
            method: "GET",
            path: `/api/experimental/migration/v1`,
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false
          }, requestOptions)
        }
      },
      usage: {
        limits: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/experimental/usage/limits`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions)
      },
      config: {
        update: (input2, requestOptions) => request({
          method: "PATCH",
          path: `/api/experimental/config`,
          body: { shell: input2["shell"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      }
    },
    message: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/message`,
        query: { limit: input2["limit"], order: input2["order"], cursor: input2["cursor"], type: input2["type"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions)
    },
    model: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/model`,
        query: { location: input2?.["location"], types: input2?.["types"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      default: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/model/default`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    provider: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/provider`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/provider/${encodeURIComponent(input2.providerID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    integration: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/integration`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/integration/${encodeURIComponent(input2.integrationID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      connect: {
        key: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/key`,
          query: { location: input2["location"] },
          body: { key: input2["key"], answer: input2["answer"], label: input2["label"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        external: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/external`,
          query: { location: input2["location"] },
          body: { methodID: input2["methodID"], answer: input2["answer"], label: input2["label"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      oauth: {
        connect: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth`,
          query: { location: input2["location"] },
          body: { methodID: input2["methodID"], answer: input2["answer"], label: input2["label"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        status: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        complete: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth/${encodeURIComponent(input2.attemptID)}/complete`,
          query: { location: input2["location"] },
          body: { code: input2["code"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        cancel: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      command: {
        connect: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/command`,
          query: { location: input2["location"] },
          body: { methodID: input2["methodID"], label: input2["label"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        status: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/command/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        cancel: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/command/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      }
    },
    mcp: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/mcp`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      resource: {
        catalog: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/mcp/resource`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      }
    },
    credential: {
      list: (requestOptions) => request({ method: "GET", path: `/api/credential`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions).then((value) => value.data),
      create: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/credential`,
        body: {
          id: input2["id"],
          integrationID: input2["integrationID"],
          label: input2["label"],
          value: input2["value"],
          activate: input2["activate"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      update: (input2, requestOptions) => request({
        method: "PATCH",
        path: `/api/credential/${encodeURIComponent(input2.credentialID)}`,
        body: { label: input2["label"] },
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions),
      activate: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/credential/${encodeURIComponent(input2.credentialID)}/activate`,
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions),
      remove: (input2, requestOptions) => request({
        method: "DELETE",
        path: `/api/credential/${encodeURIComponent(input2.credentialID)}`,
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions)
    },
    project: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/project`,
        query: { archived: input2?.["archived"] },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions),
      update: (input2, requestOptions) => request({
        method: "PATCH",
        path: `/api/project/${encodeURIComponent(input2.projectID)}`,
        body: {
          canonical: input2["canonical"],
          name: input2["name"],
          icon: input2["icon"],
          commands: input2["commands"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    form: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/form`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    permission: {
      request: {
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/permission/request`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      saved: {
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/permission/saved`,
          query: { projectID: input2?.["projectID"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        update: (input2, requestOptions) => request({
          method: "PATCH",
          path: `/api/permission/saved/${encodeURIComponent(input2.id)}`,
          body: { action: input2["action"], resource: input2["resource"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        remove: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/permission/saved/${encodeURIComponent(input2.id)}`,
          successStatus: 204,
          declaredStatuses: [400, 401],
          empty: true
        }, requestOptions)
      },
      create: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission`,
        body: {
          id: input2["id"],
          action: input2["action"],
          resources: input2["resources"],
          save: input2["save"],
          metadata: input2["metadata"],
          source: input2["source"],
          agent: input2["agent"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission/${encodeURIComponent(input2.requestID)}`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      reply: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission/${encodeURIComponent(input2.requestID)}/reply`,
        body: { decision: input2["decision"], message: input2["message"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    file: {
      read: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/fs/read/${encodePath(input2.path)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false,
        binary: true
      }, requestOptions),
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/fs/list`,
        query: { location: input2?.["location"], path: input2?.["path"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      find: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/fs/find`,
        query: { location: input2["location"], query: input2["query"], type: input2["type"], limit: input2["limit"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    command: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/command`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    skill: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/skill`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    rpc: {
      call: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/rpc/${encodeURIComponent(input2.rpcID)}/${encodeURIComponent(input2.method)}`,
        query: { location: input2["location"] },
        body: { input: input2["input"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions)
    },
    event: {
      subscribe: (input2, requestOptions) => sse({
        method: "GET",
        path: `/api/event`,
        query: { types: input2?.["types"] },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions)
    },
    pty: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/pty`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/pty`,
        query: { location: input2?.["location"] },
        body: {
          command: input2?.["command"],
          args: input2?.["args"],
          cwd: input2?.["cwd"],
          title: input2?.["title"],
          env: input2?.["env"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/pty/${encodeURIComponent(input2.ptyID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      update: (input2, requestOptions) => request({
        method: "PUT",
        path: `/api/pty/${encodeURIComponent(input2.ptyID)}`,
        query: { location: input2["location"] },
        body: { title: input2["title"], size: input2["size"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input2, requestOptions) => request({
        method: "DELETE",
        path: `/api/pty/${encodeURIComponent(input2.ptyID)}`,
        query: { location: input2["location"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      connect: {
        token: (input2, requestOptions) => request({
          method: "POST",
          path: `/api/pty/${encodeURIComponent(input2.ptyID)}/connect-token`,
          query: { location: input2["location"] },
          headers: { "x-opencode-ticket": input2["x-opencode-ticket"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions)
      }
    },
    shell: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/shell`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/shell`,
        query: { location: input2["location"] },
        body: {
          command: input2["command"],
          cwd: input2["cwd"],
          timeout: input2["timeout"],
          metadata: input2["metadata"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/shell/${encodeURIComponent(input2.id)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      output: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/shell/${encodeURIComponent(input2.id)}/output`,
        query: { location: input2["location"], cursor: input2["cursor"], limit: input2["limit"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input2, requestOptions) => request({
        method: "DELETE",
        path: `/api/shell/${encodeURIComponent(input2.id)}`,
        query: { location: input2["location"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    reference: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/reference`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    worktree: {
      list: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/worktree`,
        query: { projectID: input2["projectID"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/worktree`,
        body: {
          projectID: input2["projectID"],
          from: input2["from"],
          branch: input2["branch"],
          directory: input2["directory"],
          name: input2["name"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input2, requestOptions) => request({
        method: "DELETE",
        path: `/api/worktree`,
        body: { projectID: input2["projectID"], directory: input2["directory"], force: input2["force"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      refresh: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/worktree/refresh`,
        body: { projectID: input2["projectID"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    vcs: {
      init: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/vcs/init`,
        query: { location: input2?.["location"], provider: input2?.["provider"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 409, 501, 503],
        empty: true
      }, requestOptions),
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/vcs`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      base: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/vcs/base`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      status: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/vcs/status`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      branch: {
        list: (input2, requestOptions) => request({
          method: "GET",
          path: `/api/vcs/branch`,
          query: { location: input2?.["location"], search: input2?.["search"], limit: input2?.["limit"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      diff: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/vcs/diff`,
        query: {
          location: input2["location"],
          mode: input2["mode"],
          base: input2["base"],
          context: input2["context"],
          untracked: input2["untracked"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    debug: {
      heapDump: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/debug/heap-dump`,
        query: { directory: input2?.["directory"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 500],
        empty: false
      }, requestOptions),
      location: {
        list: (requestOptions) => request({
          method: "GET",
          path: `/api/debug/location`,
          successStatus: 200,
          declaredStatuses: [400, 401],
          empty: false
        }, requestOptions),
        evict: (input2, requestOptions) => request({
          method: "DELETE",
          path: `/api/debug/location`,
          query: { location: input2?.["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401],
          empty: true
        }, requestOptions)
      }
    },
    websearch: {
      providers: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/websearch/provider`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      query: (input2, requestOptions) => request({
        method: "POST",
        path: `/api/websearch`,
        query: { location: input2["location"] },
        body: { query: input2["query"], providerID: input2["providerID"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    config: {
      get: (input2, requestOptions) => request({
        method: "GET",
        path: `/api/config`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      shells: (requestOptions) => request({
        method: "GET",
        path: `/api/config/shell`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    }
  };
  return {
    ...client2,
    session: {
      ...client2.session,
      stats: client2.experimental.session.stats,
      import: client2.experimental.session.import,
      export: client2.experimental.session.export,
      skill: client2.experimental.session.skill,
      wait: client2.experimental.session.wait,
      instructions: {
        entry: {
          list: client2.experimental.session.instructions.entry.list,
          put: client2.experimental.session.instructions.entry.put,
          remove: client2.experimental.session.instructions.entry.remove
        }
      },
      log: client2.experimental.session.log
    },
    generate: {
      text: client2.experimental.generate.text,
      image: client2.experimental.generate.image,
      decisions: client2.experimental.generate.decisions
    },
    voice: {
      models: client2.experimental.voice.models,
      session: client2.experimental.voice.session
    },
    integration: {
      ...client2.integration,
      wellknown: {
        add: client2.experimental.integration.wellknown.add
      }
    },
    mcp: {
      ...client2.mcp,
      add: client2.experimental.mcp.add,
      remove: client2.experimental.mcp.remove,
      connect: client2.experimental.mcp.connect,
      disconnect: client2.experimental.mcp.disconnect,
      client: {
        token: client2.experimental.mcp.client.token
      }
    },
    file: {
      ...client2.file,
      write: client2.experimental.file.write,
      watch: client2.experimental.file.watch,
      unwatch: client2.experimental.file.unwatch
    },
    migration: {
      v1: {
        status: client2.experimental.migration.v1.status
      }
    },
    usage: {
      limits: client2.experimental.usage.limits
    },
    config: {
      ...client2.config,
      update: client2.experimental.config.update
    }
  };
}
function encodePath(value) {
  return value.split("/").map(encodeURIComponent).join("/");
}
function appendQuery(params, key, value) {
  if (value === void 0)
    return;
  if (value === null) {
    params.append(key, "null");
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value)
      appendQuery(params, key, item);
    return;
  }
  if (typeof value === "object") {
    for (const [child, item] of Object.entries(value))
      appendQuery(params, `${key}[${child}]`, item);
    return;
  }
  params.append(key, String(value));
}
async function json(response) {
  if (!isContentType(response, "application/json") && !response.headers.get("content-type")?.includes("+json")) {
    try {
      await response.body?.cancel();
    } catch {
    }
    throw new ClientError2("UnsupportedContentType", { detail: response.headers.get("content-type") });
  }
  let text;
  try {
    text = await response.text();
  } catch (cause) {
    throw new ClientError2("Transport", { cause });
  }
  if (text === "")
    throw new ClientError2("MalformedResponse");
  try {
    return JSON.parse(text);
  } catch (cause) {
    throw new ClientError2("MalformedResponse", { cause });
  }
}
function declared(body) {
  const error = Object.assign(new Error(body.message ?? body.data?.message), body);
  if (body._tag)
    error.name = body._tag;
  return error;
}
function isContentType(response, expected) {
  return response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() === expected;
}
var exports_client2, maxSseEventBytes;
var init_rpc_runtime_t2ajednw = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-t2ajednw.js"() {
    init_rpc_runtime_js54wxgp();
    init_rpc_runtime_9rqn6x4v();
    exports_client2 = {};
    __export2(exports_client2, {
      make: () => make3
    });
    maxSseEventBytes = 16 * 1024 * 1024;
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-sdjh9vmn.js
var isInvalidRequestError2, isUnauthorizedError2, isLocationNotFoundError2, isServiceUnavailableError2, isAgentNotFoundError2, isPluginNotFoundError2, isInvalidCursorError2, isSessionNotFoundError2, isMessageNotFoundError2, isConflictError2, isCommandNotFoundError2, isCommandExecutionError2, isSessionBusyError2, isUnknownError2, isFormNotFoundError2, isFormInvalidAnswerError2, isFormAlreadySettledError2, isSkillNotFoundError2, isInstructionEntryValueTooLargeError2, isProviderNotFoundError2, isModelNotFoundError2, isUnsupportedModelError2, isProviderRequestError2, isIntegrationNotFoundError2, isIntegrationAttemptNotFoundError2, isIntegrationMethodNotFoundError2, isMcpServerNotFoundError2, isForbiddenError2, isProjectNotFoundError2, isPermissionSavedNotFoundError2, isPermissionNotFoundError2, isFileNotFoundError2, isRpcError2, isRpcInternalError2, isPtyNotFoundError2, isPtyFeatureUnsupportedError2, isScheduleNotFoundError2, isArtifactNotFoundError2, isShellNotFoundError2, isWorktreeError2, isVcsInitNotSupportedError2;
var init_rpc_runtime_sdjh9vmn = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-sdjh9vmn.js"() {
    isInvalidRequestError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "InvalidRequestError";
    isUnauthorizedError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "UnauthorizedError";
    isLocationNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "LocationNotFoundError";
    isServiceUnavailableError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ServiceUnavailableError";
    isAgentNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "AgentNotFoundError";
    isPluginNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "PluginNotFoundError";
    isInvalidCursorError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "InvalidCursorError";
    isSessionNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "SessionNotFoundError";
    isMessageNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "MessageNotFoundError";
    isConflictError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ConflictError";
    isCommandNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "CommandNotFoundError";
    isCommandExecutionError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "CommandExecutionError";
    isSessionBusyError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "SessionBusyError";
    isUnknownError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "UnknownError";
    isFormNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "FormNotFoundError";
    isFormInvalidAnswerError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "FormInvalidAnswerError";
    isFormAlreadySettledError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "FormAlreadySettledError";
    isSkillNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "SkillNotFoundError";
    isInstructionEntryValueTooLargeError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "InstructionEntryValueTooLargeError";
    isProviderNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ProviderNotFoundError";
    isModelNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ModelNotFoundError";
    isUnsupportedModelError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "UnsupportedModelError";
    isProviderRequestError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ProviderRequestError";
    isIntegrationNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "IntegrationNotFoundError";
    isIntegrationAttemptNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "IntegrationAttemptNotFoundError";
    isIntegrationMethodNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "IntegrationMethodNotFoundError";
    isMcpServerNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "McpServerNotFoundError";
    isForbiddenError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ForbiddenError";
    isProjectNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ProjectNotFoundError";
    isPermissionSavedNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "PermissionSavedNotFoundError";
    isPermissionNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "PermissionNotFoundError";
    isFileNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "FileNotFoundError";
    isRpcError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "RpcError";
    isRpcInternalError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "RpcInternalError";
    isPtyNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "PtyNotFoundError";
    isPtyFeatureUnsupportedError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "PtyFeatureUnsupportedError";
    isScheduleNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ScheduleNotFoundError";
    isArtifactNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ArtifactNotFoundError";
    isShellNotFoundError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "ShellNotFoundError";
    isWorktreeError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "WorktreeError";
    isVcsInitNotSupportedError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "VcsInitNotSupportedError";
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-xqwq6bgr.js
function makeRpc2(raw, events) {
  return (definition) => {
    const subscribe = (name, options2) => {
      if (!Object.hasOwn(definition.events, name))
        throw new Error(`Unknown RPC event: ${definition.id}.${name}`);
      const type = eventType(definition, name);
      return {
        [Symbol.asyncIterator]() {
          const controller = new AbortController();
          const signal2 = options2?.signal ? AbortSignal.any([controller.signal, options2.signal]) : controller.signal;
          const iterator = (async function* () {
            try {
              for await (const published of events.subscribe({ signal: signal2 })) {
                if (signal2.aborted)
                  return;
                if (published.type !== type)
                  continue;
                yield published;
              }
            } catch (error) {
              if (!signal2.aborted)
                throw error;
            } finally {
              controller.abort();
            }
          })();
          return {
            next: () => iterator.next(),
            return: () => {
              controller.abort();
              return iterator.return();
            }
          };
        }
      };
    };
    return Object.assign(Object.fromEntries(Object.keys(definition.methods).map((name) => [
      name,
      async (input2, options2) => {
        try {
          const result = await raw.rpc.call({
            rpcID: definition.id,
            method: name,
            input: input2,
            location: options2?.location
          }, { signal: options2?.signal, headers: options2?.headers });
          return result.output;
        } catch (error) {
          if (!isRpcError2(error) && !isRpcInternalError2(error))
            throw error;
          throw error.data === void 0 ? { type: error.type, message: error.message } : { type: error.type, message: error.message, data: error.data };
        }
      }
    ])), {
      events: {
        subscribe,
        on: (name, handler, options2) => {
          const controller = new AbortController();
          const signal2 = options2?.signal ? AbortSignal.any([controller.signal, options2.signal]) : controller.signal;
          const source = subscribe(name, { signal: signal2 });
          (async () => {
            for await (const event2 of source)
              await handler(event2);
          })().catch((error) => console.error(error));
          return () => controller.abort();
        }
      }
    });
  };
}
function eventType(definition, name) {
  return `rpc.${definition.id}.${name}`;
}
var init_rpc_runtime_xqwq6bgr = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-xqwq6bgr.js"() {
    init_rpc_runtime_sdjh9vmn();
  }
});

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-wbnz2gjn.js
function make2(options2) {
  const raw = make3(options2);
  const events = make7((signal2, onActivity) => raw.event.subscribe(void 0, { signal: signal2, onActivity }));
  return {
    ...raw,
    rpc: Object.assign(makeRpc2(raw, events), raw.rpc),
    event: events
  };
}
var exports_client;
var init_rpc_runtime_wbnz2gjn = __esm({
  "../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-wbnz2gjn.js"() {
    init_rpc_runtime_gecjxyvt();
    init_rpc_runtime_t2ajednw();
    init_rpc_runtime_xqwq6bgr();
    init_rpc_runtime_9rqn6x4v();
    exports_client = {};
    __export2(exports_client, {
      OpenCode: () => exports_client,
      make: () => make2
    });
  }
});

// ../../../node_modules/@opencode/client/dist/promise/index.js
var promise_exports = {};
__export(promise_exports, {
  ClientError: () => ClientError2,
  OpenCode: () => exports_client,
  isAgentNotFoundError: () => isAgentNotFoundError2,
  isArtifactNotFoundError: () => isArtifactNotFoundError2,
  isCommandExecutionError: () => isCommandExecutionError2,
  isCommandNotFoundError: () => isCommandNotFoundError2,
  isConflictError: () => isConflictError2,
  isFileNotFoundError: () => isFileNotFoundError2,
  isForbiddenError: () => isForbiddenError2,
  isFormAlreadySettledError: () => isFormAlreadySettledError2,
  isFormInvalidAnswerError: () => isFormInvalidAnswerError2,
  isFormNotFoundError: () => isFormNotFoundError2,
  isInstructionEntryValueTooLargeError: () => isInstructionEntryValueTooLargeError2,
  isIntegrationAttemptNotFoundError: () => isIntegrationAttemptNotFoundError2,
  isIntegrationMethodNotFoundError: () => isIntegrationMethodNotFoundError2,
  isIntegrationNotFoundError: () => isIntegrationNotFoundError2,
  isInvalidCursorError: () => isInvalidCursorError2,
  isInvalidRequestError: () => isInvalidRequestError2,
  isLocationNotFoundError: () => isLocationNotFoundError2,
  isMcpServerNotFoundError: () => isMcpServerNotFoundError2,
  isMessageNotFoundError: () => isMessageNotFoundError2,
  isModelNotFoundError: () => isModelNotFoundError2,
  isPermissionNotFoundError: () => isPermissionNotFoundError2,
  isPermissionSavedNotFoundError: () => isPermissionSavedNotFoundError2,
  isPluginNotFoundError: () => isPluginNotFoundError2,
  isProjectNotFoundError: () => isProjectNotFoundError2,
  isProviderNotFoundError: () => isProviderNotFoundError2,
  isProviderRequestError: () => isProviderRequestError2,
  isPtyFeatureUnsupportedError: () => isPtyFeatureUnsupportedError2,
  isPtyNotFoundError: () => isPtyNotFoundError2,
  isRpcError: () => isRpcError2,
  isRpcInternalError: () => isRpcInternalError2,
  isScheduleNotFoundError: () => isScheduleNotFoundError2,
  isServiceUnavailableError: () => isServiceUnavailableError2,
  isSessionBusyError: () => isSessionBusyError2,
  isSessionNotFoundError: () => isSessionNotFoundError2,
  isShellNotFoundError: () => isShellNotFoundError2,
  isSkillNotFoundError: () => isSkillNotFoundError2,
  isUnauthorizedError: () => isUnauthorizedError2,
  isUnknownError: () => isUnknownError2,
  isUnsupportedModelError: () => isUnsupportedModelError2,
  isVcsInitNotSupportedError: () => isVcsInitNotSupportedError2,
  isWorktreeError: () => isWorktreeError2,
  mediaHashFromUri: () => mediaHashFromUri2,
  withMediaRefs: () => withMediaRefs2
});
var init_promise = __esm({
  "../../../node_modules/@opencode/client/dist/promise/index.js"() {
    init_rpc_runtime_mwrzahmf();
    init_rpc_runtime_wbnz2gjn();
    init_rpc_runtime_xqwq6bgr();
    init_rpc_runtime_t2ajednw();
    init_rpc_runtime_js54wxgp();
    init_rpc_runtime_sdjh9vmn();
    init_rpc_runtime_gecjxyvt();
  }
});

// src/sidecar.ts
var import_node_crypto2 = require("node:crypto");
var import_node_readline = __toESM(require("node:readline"), 1);
init_promise();

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-ve4aws36.js
var import_node_child_process = require("node:child_process");
var stderrLimit = 8 * 1024;
function spawnServiceContender2(command, args, env) {
  const child = (0, import_node_child_process.spawn)(command, args, {
    detached: true,
    windowsHide: true,
    stdio: ["ignore", "ignore", "pipe"],
    env: { ...process.env, ...env }
  });
  let error;
  let closed = false;
  let stderr = Buffer.alloc(0);
  const onStderr = (chunk) => {
    const tail = chunk.subarray(-stderrLimit);
    stderr = tail.length === stderrLimit ? Buffer.from(tail) : Buffer.concat([stderr.subarray(-(stderrLimit - tail.length)), tail]);
  };
  child.stderr?.on("data", onStderr);
  if (child.stderr !== null && "unref" in child.stderr && typeof child.stderr.unref === "function")
    child.stderr.unref();
  child.once("error", (cause) => {
    error = new Error("Failed to start server", { cause });
  });
  child.once("close", () => {
    closed = true;
  });
  child.unref();
  return {
    child,
    error: () => error,
    closed: () => closed,
    stderr: () => stderr.toString("utf8").trim(),
    release: () => {
      child.stderr?.off("data", onStderr);
      child.stderr?.resume();
      stderr = Buffer.alloc(0);
    }
  };
}
function contenderPool2(timing) {
  const contenders = /* @__PURE__ */ new Set();
  let failure;
  let spawnDelay = timing.spawnDelay;
  let lastSpawn = 0;
  return {
    failure: () => failure,
    serviceAnswered() {
      spawnDelay = timing.spawnDelay;
    },
    evict(pid) {
      for (const item of contenders) {
        if (item.child.pid === pid || contenderFinished2(item)) {
          item.release();
          contenders.delete(item);
        }
      }
      failure = void 0;
      lastSpawn = 0;
    },
    recruitNow() {
      lastSpawn = Date.now() - spawnDelay;
    },
    reap() {
      const finished = [...contenders].filter(contenderFinished2);
      failure ??= finished.map(contenderFailure).find((error) => error !== void 0);
      if (finished.some((item) => item.child.exitCode === 0))
        spawnDelay = Math.min(spawnDelay * 2, timing.maxSpawnDelay);
      finished.forEach((item) => contenders.delete(item));
      return contenders.size === 0 ? failure : void 0;
    },
    shouldRecruit(registered2) {
      if (lastSpawn === 0 && registered2)
        lastSpawn = Date.now();
      return failure === void 0 && contenders.size < 2 && Date.now() - lastSpawn >= spawnDelay;
    },
    add(contender) {
      contenders.add(contender);
      lastSpawn = Date.now();
    },
    releaseAll() {
      contenders.forEach((contender) => contender.release());
    }
  };
}
function contenderFailure(contender) {
  const error = contender.error();
  if (error !== void 0)
    return error;
  if (contender.child.exitCode !== null && contender.child.exitCode !== 0)
    return startupError(`Server process exited with code ${contender.child.exitCode}`, contender.stderr());
  if (contender.child.signalCode !== null)
    return startupError(`Server process terminated by ${contender.child.signalCode}`, contender.stderr());
  return;
}
function contenderFinished2(contender) {
  return contender.error() !== void 0 || contender.closed();
}
function startupError(message, stderr) {
  return new Error(stderr ? `${message}
${stderr}` : message);
}

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-xgnj2w4v.js
var timings = /* @__PURE__ */ new WeakMap();
var defaultEnsureTiming2 = {
  pollInterval: 25,
  requestTimeout: 2e3,
  spawnDelay: 5e3,
  maxSpawnDelay: 3e4,
  promiseTimeout: 12e4,
  stopPollInterval: 50,
  stopPollAttempts: 100
};
function ensureTiming2(options2) {
  return timings.get(options2) ?? defaultEnsureTiming2;
}

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-sxt88q69.js
function matchesVersion2(version, options2) {
  if (options2.version === void 0)
    return true;
  if (version === void 0)
    return false;
  if (typeof options2.version === "function")
    return options2.version(version);
  return version === options2.version;
}

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-8ye1ye6f.js
var import_node_os = require("node:os");
var import_node_path = require("node:path");
function decide2(service, options2) {
  if (!matchesVersion2(service.version, options2))
    return { _tag: "replace", pty: service.state === "ready" ? "handoff" : "clear" };
  if (!service.compatible)
    return fail("Background service uses an incompatible health protocol. Update this client or explicitly restart the service.");
  if (service.state === "ready")
    return { _tag: "reuse" };
  if (service.state === "failed")
    return fail("Background service failed to start");
  return { _tag: "wait" };
}
function fail(message) {
  return { _tag: "fail", error: new Error(message) };
}
function fallback2() {
  return (0, import_node_path.join)(process.env["XDG_STATE_HOME"] ?? (0, import_node_path.join)((0, import_node_os.homedir)(), ".local", "state"), "opencode", "service.json");
}
function same2(left, right) {
  return left.id === right.id && left.version === right.version && left.url === right.url && left.pid === right.pid;
}
async function probeResult2(info, timeout = defaultEnsureTiming2.requestTimeout) {
  const endpoint = {
    url: info.url,
    auth: info.password === void 0 ? void 0 : { type: "basic", username: "opencode", password: info.password }
  };
  const signal2 = AbortSignal.timeout(timeout);
  const result = await fetch(new URL("/api/info", info.url), { headers: headers2(endpoint), signal: signal2 }).then(async (response2) => ({
    response: response2,
    body: response2.status === 404 ? void 0 : await response2.json()
  })).catch(() => {
    return;
  });
  if (result === void 0)
    return { service: void 0, timedOut: signal2.aborted };
  const response = result.response;
  if (response.status === 404)
    return {
      service: {
        info,
        endpoint,
        version: info.version,
        state: "ready",
        compatible: false
      },
      timedOut: false
    };
  const serverInfo = decodeInfo(result.body);
  if (serverInfo === void 0)
    return { service: void 0, timedOut: false };
  if (serverInfo.pid !== info.pid)
    return { service: void 0, timedOut: false };
  if (info.version !== void 0 && serverInfo.version !== info.version)
    return { service: void 0, timedOut: false };
  return {
    service: {
      info,
      endpoint,
      version: serverInfo.version,
      state: response.ok ? "ready" : response.status === 500 ? "failed" : "waiting",
      compatible: true
    },
    timedOut: false
  };
}
function headers2(endpoint) {
  if (endpoint.auth === void 0)
    return;
  return {
    authorization: "Basic " + Buffer.from(endpoint.auth.username + ":" + endpoint.auth.password).toString("base64")
  };
}
function decodeInfo(input2) {
  if (typeof input2 !== "object" || input2 === null)
    return;
  if (!("version" in input2) || typeof input2.version !== "string")
    return;
  if (!("pid" in input2) || typeof input2.pid !== "number" || !Number.isInteger(input2.pid) || input2.pid < 0)
    return;
  return { version: input2.version, pid: input2.pid };
}

// ../../../node_modules/@opencode/client/dist/chunks/rpc-runtime-tq7qack3.js
init_rpc_runtime_9rqn6x4v();
var import_promises = require("node:fs/promises");
var exports_pty_handoff = {};
__export2(exports_pty_handoff, {
  PtyHandoff: () => exports_pty_handoff,
  clear: () => clear2,
  complete: () => complete2,
  environment: () => environment2,
  prepare: () => prepare2
});
async function prepare2(file, info, timeout) {
  const existing = await read(file);
  if (existing !== void 0 && existing.expiresAt > Date.now() && same(existing.source, info))
    return;
  const { OpenCode } = await Promise.resolve().then(() => (init_promise(), promise_exports));
  const client2 = OpenCode.make({
    baseUrl: info.url,
    headers: headers2({
      url: info.url,
      auth: info.password === void 0 ? void 0 : { type: "basic", username: "opencode", password: info.password }
    })
  });
  const handoff = await client2.experimental.persistentPty.handoff({ signal: AbortSignal.timeout(timeout) }).then(parse).catch(async (cause) => {
    const concurrent = await read(file);
    if (concurrent !== void 0 && concurrent.expiresAt > Date.now() && same(concurrent.source, info))
      return;
    console.warn("Background service cannot hand off persistent terminals; shutting them down before replacement", cause);
    await client2.experimental.persistentPty.shutdown({ signal: AbortSignal.timeout(timeout) }).catch(() => {
    });
    return null;
  });
  if (handoff === void 0)
    return;
  await publish(file, info, handoff).catch((cause) => console.warn("Failed to publish persistent terminal handoff", cause));
}
function parse(body) {
  if (typeof body !== "object" || body === null || !("handoff" in body))
    throw new Error("Invalid persistent terminal handoff response");
  if (body.handoff === null)
    return null;
  if (!isHandoff(body.handoff) || body.handoff.expiresAt <= Date.now())
    throw new Error("Invalid or expired persistent terminal handoff");
  return body.handoff;
}
async function publish(file, info, handoff) {
  const temporary = `${file}.pty-handoff.${crypto.randomUUID()}.tmp`;
  await (0, import_promises.writeFile)(temporary, JSON.stringify({
    source: { id: info.id, pid: info.pid, url: info.url },
    handoff,
    expiresAt: handoff?.expiresAt ?? Date.now() + 3e4
  }), { mode: 384, flag: "wx" });
  await (0, import_promises.rename)(temporary, file + ".pty-handoff").finally(() => (0, import_promises.rm)(temporary, { force: true }));
}
async function environment2(file, env) {
  const record = await read(file);
  const current = await (0, import_promises.readFile)(file, "utf8").then((text) => JSON.parse(text)).catch(() => {
    return;
  });
  const handoff = record !== void 0 && record.expiresAt > Date.now() && (current === void 0 || same(record.source, current)) ? record.handoff : void 0;
  return { ...env, OPENCODE_PTY_HANDOFF: handoff == null ? void 0 : JSON.stringify(handoff) };
}
async function complete2(file, info) {
  const record = await read(file);
  if (record !== void 0 && !same(record.source, info))
    await clear2(file);
}
async function clear2(file) {
  await (0, import_promises.rm)(file + ".pty-handoff", { force: true });
}
async function read(file) {
  const value = await (0, import_promises.readFile)(file + ".pty-handoff", "utf8").then((text) => JSON.parse(text)).catch(() => {
    return;
  });
  if (typeof value !== "object" || value === null || !("source" in value) || !("handoff" in value))
    return;
  if (typeof value.source !== "object" || value.source === null)
    return;
  if (!("pid" in value.source) || typeof value.source.pid !== "number")
    return;
  if (!("url" in value.source) || typeof value.source.url !== "string")
    return;
  if ("id" in value.source && typeof value.source.id !== "string")
    return;
  if (value.handoff !== null && !isHandoff(value.handoff))
    return;
  if (!("expiresAt" in value) || typeof value.expiresAt !== "number" || !Number.isFinite(value.expiresAt))
    return;
  return {
    source: {
      id: "id" in value.source && typeof value.source.id === "string" ? value.source.id : void 0,
      pid: value.source.pid,
      url: value.source.url
    },
    handoff: value.handoff,
    expiresAt: value.expiresAt
  };
}
function same(left, right) {
  return left.id === right.id && left.pid === right.pid && left.url === right.url;
}
function isHandoff(value) {
  return typeof value === "object" && value !== null && "directory" in value && typeof value.directory === "string" && "instanceID" in value && typeof value.instanceID === "string" && "ticket" in value && typeof value.ticket === "string" && "expiresAt" in value && typeof value.expiresAt === "number" && Number.isFinite(value.expiresAt);
}

// ../../../node_modules/@opencode/client/dist/promise/service.js
var import_promises2 = require("node:fs/promises");
async function discover(options2 = {}) {
  const found = (await registered(options2.file)).service;
  if (found?.state !== "ready")
    return;
  if (!found.compatible)
    return;
  if (!matchesVersion2(found.version, options2))
    return;
  return found.endpoint;
}
async function ensure(options2 = {}) {
  const timing = ensureTiming2(options2);
  const deadline = Date.now() + timing.promiseTimeout;
  const pool = contenderPool2(timing);
  let timeouts;
  let announced = false;
  const announce = (reason, previousVersion) => {
    if (announced)
      return;
    announced = true;
    options2.onStart?.(reason, previousVersion);
  };
  const spawnContender = async () => {
    const [command, ...args] = options2.command ?? ["opencode", "serve", "--service"];
    if (command === void 0)
      throw new Error("Missing service command");
    try {
      return spawnServiceContender2(command, args, await environment2(options2.file ?? fallback2(), options2.env));
    } catch (cause) {
      throw new Error("Failed to start server", { cause });
    }
  };
  try {
    while (true) {
      if (Date.now() >= deadline)
        throw pool.failure() ?? new Error("Timed out waiting for the background service to start");
      const registration = await registered(options2.file, timing.requestTimeout);
      if (registration.timedOut && registration.info !== void 0) {
        timeouts = {
          info: registration.info,
          count: timeouts !== void 0 && same2(timeouts.info, registration.info) ? timeouts.count + 1 : 1
        };
        if (timeouts.count >= 3) {
          announce("missing");
          console.warn("Background service is unresponsive; recovery cannot preserve persistent terminals");
          await clear2(options2.file ?? fallback2());
          await terminate(registration.info, options2, timing);
          pool.evict(registration.info.pid);
          pool.recruitNow();
          timeouts = void 0;
        }
      } else
        timeouts = void 0;
      if (registration.service !== void 0) {
        pool.serviceAnswered();
        const service2 = registration.service;
        const decision = decide2(service2, options2);
        if (decision._tag === "fail")
          throw decision.error;
        if (decision._tag === "reuse") {
          await complete2(options2.file ?? fallback2(), service2.info);
          return service2.endpoint;
        }
        if (decision._tag === "replace") {
          announce("version-mismatch", service2.version);
          if (service2.state !== "ready")
            console.warn("Background service is not ready; replacement cannot preserve persistent terminals");
          await stop({ file: options2.file, pty: decision.pty }).catch(() => {
            return;
          });
          pool.evict(service2.info.pid);
        }
      } else {
        const failed = pool.reap();
        if (failed !== void 0)
          throw failed;
        if (pool.shouldRecruit(registration.info !== void 0)) {
          announce("missing");
          pool.add(await spawnContender());
        }
      }
      await delay(timing.pollInterval);
    }
  } finally {
    pool.releaseAll();
  }
}
async function stop(options2 = {}) {
  const info = await read2(options2.file);
  await (options2.pty === "handoff" && info !== void 0 ? prepare2(options2.file ?? fallback2(), info, defaultEnsureTiming2.requestTimeout) : clear2(options2.file ?? fallback2())).catch((cause) => console.warn("Failed to prepare persistent terminals for replacement", cause));
  if (info !== void 0)
    await terminate(info, options2, ensureTiming2(options2));
}
async function read2(file) {
  const text = await (0, import_promises2.readFile)(file ?? fallback2(), "utf8").catch(() => {
    return;
  });
  if (text === void 0)
    return;
  try {
    return JSON.parse(text);
  } catch {
    return;
  }
}
async function registered(file, timeout) {
  const info = await read2(file);
  if (info === void 0)
    return { info: void 0, service: void 0, timedOut: false };
  return { info, ...await probeResult2(info, timeout) };
}
function signal(pid, name) {
  try {
    process.kill(pid, name);
  } catch {
  }
}
function stopped(pid) {
  try {
    process.kill(pid, 0);
    return false;
  } catch {
    return true;
  }
}
async function waitUntilStopped(pid, timing) {
  for (let attempt = 0; attempt <= timing.stopPollAttempts; attempt++) {
    if (stopped(pid))
      return true;
    if (attempt < timing.stopPollAttempts)
      await delay(timing.stopPollInterval);
  }
  return false;
}
async function terminate(info, options2, timing) {
  const current = await read2(options2.file);
  if (current === void 0 || !same2(current, info))
    return;
  signal(info.pid, "SIGTERM");
  if (!await waitUntilStopped(info.pid, timing)) {
    signal(info.pid, "SIGKILL");
    if (!await waitUntilStopped(info.pid, timing))
      throw new Error(`Server process ${info.pid} is still running`);
  }
  const latest = await read2(options2.file);
  if (latest === void 0 || !same2(latest, info))
    return;
  await (0, import_promises2.rm)(options2.file ?? fallback2(), { force: true });
}
function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
var Service = { discover, ensure, stop, headers: headers2 };

// ../../../packages/integration-kit/src/contract.ts
var MAX_OFFERS = 16;
var LABEL_MAX = 120;
var DETAIL_MAX = 300;
var APP_VERSION_MAX = 64;
var SEMVER_PATTERN = "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?(\\+[0-9A-Za-z.-]+)?$";
var DISPLAY_PATTERN = "^[^/\\\\\\p{Cc}]+$";
var HANDLE_PATTERN = "^[^\\p{Cc}]+$";
var CONTROL_PATTERN = "[\\p{Cc}]";
var OFFER_ID_PATTERN = "^[A-Za-z0-9_-]{8,64}$";
var SESSION_ID_PATTERN = "^[A-Za-z0-9_-]{1,128}$";
var GENERATION_PATTERN = "^[A-Za-z0-9_-]{1,128}(?![\\s\\S])";
var semver = () => ({ type: "string", maxLength: 64, pattern: SEMVER_PATTERN });
var display = (maxLength) => ({ type: "string", minLength: 1, maxLength, pattern: DISPLAY_PATTERN });
var empty = () => ({ type: "object", additionalProperties: false, properties: {} });
var outcome = (values) => ({
  type: "object",
  required: ["outcome"],
  properties: { outcome: { enum: values } }
});
var bindingAuthority = {
  type: "object",
  additionalProperties: false,
  required: ["serviceGeneration", "registryGeneration", "revision"],
  properties: {
    serviceGeneration: { type: "string", pattern: GENERATION_PATTERN },
    registryGeneration: { type: "string", pattern: GENERATION_PATTERN },
    revision: { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER }
  }
};
var publicBinding = {
  type: "object",
  additionalProperties: false,
  required: ["offerID", "label"],
  properties: {
    offerID: { type: "string", pattern: `${OFFER_ID_PATTERN}(?![\\s\\S])` },
    label: display(LABEL_MAX)
  }
};
var RPC_SCHEMAS = {
  "status.input": empty(),
  "status.output": {
    type: "object",
    required: ["contract", "integration"],
    properties: {
      contract: { const: 1 },
      integration: {
        type: "object",
        required: ["id", "version", "family", "spec"],
        properties: {
          id: { type: "string", pattern: "^[a-z][a-z0-9-]{0,31}$" },
          version: semver(),
          family: { enum: ["native", "vendor-mcp", "api"] },
          spec: { const: 0 }
        }
      },
      host: {
        type: "object",
        required: ["state"],
        properties: {
          state: { enum: ["absent", "incompatible", "outdated", "ok", "unknown", "unsupported"] },
          partVersion: semver(),
          expectedRange: { type: "string", minLength: 1, maxLength: 64, pattern: "^[0-9xX*^~<>=|. -]+$" },
          appVersion: display(APP_VERSION_MAX),
          action: { enum: ["install", "update"] }
        }
      },
      connection: {
        type: "object",
        required: ["state"],
        properties: {
          state: { enum: ["none", "available", "attached", "connected", "signed_out", "error"] },
          offers: { type: "integer", minimum: 0, maximum: MAX_OFFERS },
          attachedSessions: { type: "integer", minimum: 0, maximum: 1e4 }
        }
      },
      notices: {
        type: "array",
        maxItems: 8,
        uniqueItems: true,
        items: { type: "string", pattern: "^[a-z][a-z0-9_]{0,31}$" }
      }
    }
  },
  "installHost.input": { type: "object", additionalProperties: false, properties: { target: { const: "default" } } },
  "installHost.output": {
    type: "object",
    required: ["outcome"],
    properties: {
      outcome: { enum: ["installed", "updated", "unchanged", "refused", "failed"] },
      detail: display(DETAIL_MAX)
    }
  },
  "hosts.input": empty(),
  "hosts.output": {
    type: "object",
    required: ["offers"],
    properties: {
      offers: {
        type: "array",
        maxItems: MAX_OFFERS,
        items: {
          type: "object",
          required: ["offerID", "label", "protocol"],
          properties: {
            offerID: { type: "string", pattern: OFFER_ID_PATTERN },
            label: display(LABEL_MAX),
            document: display(LABEL_MAX),
            appVersion: display(APP_VERSION_MAX),
            protocol: { enum: ["ok", "incompatible"] }
          }
        }
      }
    }
  },
  "attachHost.input": {
    type: "object",
    additionalProperties: false,
    required: ["offerID", "sessionID"],
    properties: {
      offerID: { type: "string", pattern: OFFER_ID_PATTERN },
      sessionID: { type: "string", pattern: SESSION_ID_PATTERN }
    }
  },
  "attachHost.output": outcome(["attached", "busy", "gone", "refused"]),
  "detachHost.input": {
    type: "object",
    additionalProperties: false,
    required: ["sessionID"],
    properties: { sessionID: { type: "string", pattern: SESSION_ID_PATTERN } }
  },
  "detachHost.output": outcome(["detached", "none"]),
  "bindingRead.input": {
    type: "object",
    additionalProperties: false,
    required: ["sessionID"],
    properties: { sessionID: { type: "string", pattern: `${SESSION_ID_PATTERN}(?![\\s\\S])` } }
  },
  "bindingRead.output": {
    type: "object",
    oneOf: [
      {
        type: "object",
        additionalProperties: false,
        required: ["state", "authority", "binding"],
        properties: { state: { const: "attached" }, authority: bindingAuthority, binding: publicBinding }
      },
      {
        type: "object",
        additionalProperties: false,
        required: ["state", "authority"],
        properties: { state: { const: "none" }, authority: bindingAuthority }
      },
      {
        type: "object",
        additionalProperties: false,
        required: ["state"],
        properties: { state: { const: "unknown" }, authority: bindingAuthority }
      }
    ]
  },
  "advertise.output": outcome(["accepted", "renewed", "refused"]),
  "withdraw.output": outcome(["withdrawn", "none"]),
  "status_changed.event": empty(),
  "hosts_changed.event": empty()
};
var OPAQUE_INPUT = { type: "object" };
function withoutPatterns(value) {
  if (Array.isArray(value)) return value.map(withoutPatterns);
  if (typeof value !== "object" || value === null) return value;
  return Object.fromEntries(
    Object.entries(value).filter(([key, item]) => !(key === "pattern" && typeof item === "string")).map(([key, item]) => [key, withoutPatterns(item)])
  );
}
function rpcDefinition(rpcID, family) {
  const schemas = RPC_SCHEMAS;
  const schema = (name) => withoutPatterns(schemas[name] ?? OPAQUE_INPUT);
  const io = (method, input2) => ({
    input: input2 ? structuredClone(input2) : schema(`${method}.input`),
    output: schema(`${method}.output`)
  });
  const event2 = (name) => ({ schema: { ...schema(`${name}.event`), type: "object" } });
  const methods = { status: io("status") };
  const events = { status_changed: event2("status_changed") };
  if (family === "native") {
    methods.installHost = io("installHost");
    methods.hosts = io("hosts");
    methods.attachHost = io("attachHost");
    methods.detachHost = io("detachHost");
    methods.bindingRead = io("bindingRead");
    methods.advertise = io("advertise", OPAQUE_INPUT);
    methods.withdraw = io("withdraw", OPAQUE_INPUT);
    events.hosts_changed = event2("hosts_changed");
  }
  return { id: rpcID, methods, events };
}
var DISPLAY = new RegExp(DISPLAY_PATTERN, "u");
var HANDLE = new RegExp(HANDLE_PATTERN, "u");
function boundedDetail(value) {
  const clean = value.replace(/[/\\]/g, " ").replace(new RegExp(CONTROL_PATTERN, "gu"), " ").replace(/\s+/g, " ").trim();
  const bounded = [...clean].slice(0, DETAIL_MAX).join("").trim();
  return bounded.length > 0 ? bounded : void 0;
}

// ../../../packages/integration-kit/src/host-client.ts
var import_node_crypto = require("node:crypto");
var import_node_net = __toESM(require("node:net"), 1);
var HOST_ADDRESS = "127.0.0.1";
var MAX_REQUEST_BYTES = 1024 * 1024;
var MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
var DEFAULT_HOST_TIMEOUT_MS = 3e4;
var HOST_ERROR_CODES = [
  "unauthorized",
  "invalid_request",
  "method_not_found",
  "method_disabled",
  "invalid_args",
  "stale_handle",
  "stale_revision",
  "expectation_failed",
  "mode_conflict",
  "busy",
  "quarantined",
  "permission_denied",
  "internal"
];
var HostError = class extends Error {
  code;
  // The host's own explanation of a refusal, as bounded display text; never the endpoint.
  detail;
  constructor(code, message, detail) {
    super(message);
    this.name = "HostError";
    this.code = code;
    this.detail = detail;
  }
};
async function requestHost(endpoint, method, params = {}, options2 = {}) {
  if (endpoint.host !== HOST_ADDRESS) throw new HostError("invalid_request", "Hosts listen on 127.0.0.1 only.");
  const id = (0, import_node_crypto.randomUUID)();
  const line = `${JSON.stringify({ id, token: endpoint.token, method, params })}
`;
  if (Buffer.byteLength(line) > MAX_REQUEST_BYTES) throw new HostError("invalid_request", "Host request is too large.");
  const timeoutMs = options2.timeoutMs ?? DEFAULT_HOST_TIMEOUT_MS;
  return await new Promise((resolve, reject) => {
    const socket = import_node_net.default.createConnection({ host: HOST_ADDRESS, port: endpoint.port });
    let buffer = Buffer.alloc(0);
    let settled = false;
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      options2.signal?.removeEventListener("abort", abort);
      socket.destroy();
      if (error) reject(error);
      else resolve(result);
    };
    const abort = () => finish(new HostError("cancelled", "Host request cancelled."));
    const timer = setTimeout(() => finish(new HostError("timeout", "Host request timed out.")), timeoutMs);
    options2.signal?.addEventListener("abort", abort, { once: true });
    if (options2.signal?.aborted) return abort();
    socket.on("connect", () => socket.write(line));
    socket.on("data", (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      const newline = buffer.indexOf(10);
      if (newline < 0) {
        if (buffer.byteLength > MAX_RESPONSE_BYTES)
          finish(new HostError("invalid_response", "Host response too large."));
        return;
      }
      let envelope;
      try {
        envelope = JSON.parse(buffer.subarray(0, newline).toString("utf8"));
      } catch {
        return finish(new HostError("invalid_response", "Host returned malformed JSON."));
      }
      if (typeof envelope !== "object" || envelope === null || Array.isArray(envelope)) {
        return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      }
      const response = envelope;
      if (response.id !== id) return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      if (response.ok === false) {
        const raw = response.error?.code;
        const code = typeof raw === "string" && HOST_ERROR_CODES.includes(raw) ? raw : "internal";
        const detail = typeof response.error?.message === "string" ? boundedDetail(response.error.message) : void 0;
        return finish(new HostError(code, `Host refused the request (${code}).`, detail));
      }
      if (response.ok !== true || !("result" in response)) {
        return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      }
      finish(null, response.result);
    });
    socket.on("error", () => finish(new HostError("unreachable", "Host is unreachable.")));
    socket.on("end", () => finish(new HostError("unreachable", "Host closed the connection.")));
  });
}

// src/sidecar.ts
var client;
var rpc;
var channels = /* @__PURE__ */ new Map();
var queues = /* @__PURE__ */ new Map();
var send = (value) => process.stdout.write(`${JSON.stringify(value)}
`);
var event = (c, name, data) => send({ channel: c.id, event: name, data });
var options = (c) => ({ location: { directory: c.directory }, signal: AbortSignal.timeout(3e3) });
async function api() {
  if (client) return client;
  const endpoint = await Service.discover();
  if (!endpoint) throw new Error("Start OpenCode before connecting the panel.");
  client = exports_client.make({ baseUrl: endpoint.url, headers: Service.headers(endpoint) });
  rpc = client.rpc(rpcDefinition("neuralnomads.houdini", "native"));
  return client;
}
async function advertise(c) {
  const result = await rpc.advertise?.(
    {
      host: c.binding.host,
      port: c.binding.port,
      token: c.binding.token,
      script_handle: c.handle,
      label: c.label,
      protocol: 1,
      offer_key: c.key
    },
    options(c)
  );
  if (result?.outcome !== "accepted" && result?.outcome !== "renewed") throw new Error("Houdini offer was refused.");
}
async function verify(c) {
  const read3 = await rpc.bindingRead?.({ sessionID: c.sessionID }, options(c));
  if (read3?.state !== "attached") throw new Error("Houdini was detached; choose Connect to attach again.");
  const binding = read3.binding;
  if (binding?.label !== c.label) throw new Error("This conversation is attached to another host.");
}
async function close(c) {
  channels.delete(c.id);
  if (c.timer) clearInterval(c.timer);
  c.abort.abort();
  await requestHost(
    c.binding,
    "cancel",
    { script_handle: c.handle, session_id: c.sessionID },
    { timeoutMs: 2e3 }
  ).catch(() => {
  });
  await verify(c).then(() => rpc.detachHost?.({ sessionID: c.sessionID }, options(c))).catch(() => {
  });
  await rpc.withdraw?.({ offer_key: c.key, token: c.binding.token }, options(c)).catch(() => {
  });
}
async function stream(c) {
  const service = await api();
  try {
    for await (const item of service.event.subscribe({ signal: c.abort.signal })) {
      const data = item.data;
      if (data.sessionID !== c.sessionID) continue;
      if (item.type === "session.text.delta") event(c, "assistant_delta", { text: data.delta ?? "" });
      else if (item.type === "session.text.ended") event(c, "assistant_end", {});
      else if (item.type === "session.execution.started") event(c, "status", { state: "busy" });
      else if (item.type === "session.execution.succeeded" || item.type === "session.execution.interrupted")
        event(c, "status", { state: "idle" });
      else if (item.type === "session.execution.failed") event(c, "error", { message: "OpenCode execution failed." });
      else if (item.type === "permission.asked")
        event(c, "permission", { request_id: data.id, action: data.action, resources: data.resources });
    }
  } catch {
    if (!c.abort.signal.aborted) event(c, "error", { message: "OpenCode disconnected; choose Connect to reconnect." });
  }
}
async function connect(id, params) {
  const service = await api();
  const previous = channels.get(id);
  if (previous) await close(previous);
  if (params.host !== "127.0.0.1" || !Number.isInteger(params.port) || !/^[0-9a-f]{64}$/.test(String(params.token)))
    throw new Error("Invalid host endpoint.");
  const directory = String(params.directory ?? "");
  if (!directory) throw new Error("Select a project directory.");
  const session = await service.session.create({ title: "Houdini", location: { directory } });
  const c = {
    id,
    directory,
    sessionID: session.id,
    label: `Houdini ${(0, import_node_crypto2.randomUUID)().slice(0, 8)}`,
    key: (0, import_node_crypto2.randomUUID)(),
    binding: { host: "127.0.0.1", port: Number(params.port), token: String(params.token) },
    handle: String(params.script_handle),
    abort: new AbortController(),
    pending: false
  };
  try {
    await advertise(c);
    const result = await rpc.hosts?.({}, options(c));
    const offer = (result?.offers ?? []).find(
      (offer2) => offer2.label === c.label
    );
    if (!offer) throw new Error("No validated Houdini offer.");
    const attached = await rpc.attachHost?.({ offerID: offer.offerID, sessionID: c.sessionID }, options(c));
    if (attached?.outcome !== "attached") throw new Error("Houdini attachment was refused.");
    channels.set(id, c);
    let warned = false;
    c.timer = setInterval(() => {
      if (c.pending) return;
      c.pending = true;
      void api().then(() => advertise(c)).then(() => verify(c)).catch(() => {
        client = void 0;
        if (!warned)
          event(c, "error", { message: "Conversation detached or service unavailable; choose Connect to reconnect." });
        warned = true;
      }).finally(() => {
        c.pending = false;
      });
    }, 5e3);
    void stream(c);
    event(c, "session", { id: session.id, resumed: false });
    event(c, "history", { messages: [] });
    event(c, "status", { state: "idle" });
  } catch (error) {
    await close(c);
    throw error;
  }
}
async function dispatch(request) {
  try {
    const params = request.params ?? {};
    if (request.method === "connect" || request.method === "new_session") await connect(request.channel, params);
    else {
      const c = channels.get(request.channel);
      if (!c) throw new Error("Choose Connect first.");
      const service = await api();
      if (request.method === "close") await close(c);
      else if (request.method === "interrupt") {
        await requestHost(
          c.binding,
          "cancel",
          { script_handle: c.handle, session_id: c.sessionID },
          { timeoutMs: 2e3 }
        );
        await service.session.interrupt({ sessionID: c.sessionID, resume: false });
      } else if (request.method === "prompt") {
        await verify(c);
        await requestHost(
          c.binding,
          "resume",
          { script_handle: c.handle, session_id: c.sessionID },
          { timeoutMs: 2e3 }
        );
        await service.session.prompt({ sessionID: c.sessionID, text: String(params.text ?? "") });
      } else if (request.method === "permission_reply") {
        const decision = params.reply;
        if (decision !== "once" && decision !== "reject") throw new Error("Invalid permission answer.");
        await service.permission.reply({ sessionID: c.sessionID, requestID: String(params.request_id), decision });
      } else throw new Error("Unknown panel action.");
    }
    send({ id: request.id, result: {} });
  } catch {
    send({
      channel: request.channel,
      event: "error",
      data: { message: "Connection or action failed. Check OpenCode and Houdini, then choose Connect." }
    });
    send({ id: request.id, error: { message: "Panel action failed." } });
  }
}
var input = import_node_readline.default.createInterface({ input: process.stdin, crlfDelay: Infinity });
input.on("line", (line) => {
  try {
    if (Buffer.byteLength(line) > 1024 * 1024) throw new Error("Request too large");
    const request = JSON.parse(line);
    if (!request.id || !request.channel || !request.method) throw new Error("Invalid request");
    const next = (queues.get(request.channel) ?? Promise.resolve()).then(() => dispatch(request));
    queues.set(request.channel, next);
    void next.finally(() => {
      if (queues.get(request.channel) === next) queues.delete(request.channel);
    });
  } catch {
    send({ error: { message: "Invalid panel request." } });
  }
});
input.on("close", () => {
  void Promise.allSettled([...channels.values()].map(close)).finally(() => process.exit(0));
});
