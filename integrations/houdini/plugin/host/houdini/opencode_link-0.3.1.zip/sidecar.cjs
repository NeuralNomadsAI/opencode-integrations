"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// packages/integration-kit/src/panel-pipes.ts
var import_node_readline = __toESM(require("node:readline"), 1);

// node_modules/@opencode/client/dist/chunks/rpc-runtime-9rqn6x4v.js
var __defProp2 = Object.defineProperty;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp2(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};

// node_modules/@opencode/client/dist/chunks/rpc-runtime-gecjxyvt.js
var exports_shared_events = {};
__export(exports_shared_events, {
  SharedEvents: () => exports_shared_events,
  make: () => make7
});
function make7(connect) {
  let current;
  const capacity = 4096;
  function stop(connection) {
    connection.connected = void 0;
    connection.controller.abort();
    if (current === connection)
      current = void 0;
  }
  async function run(connection) {
    let iterator;
    let completion = {};
    try {
      if (connection.controller.signal.aborted)
        return;
      iterator = connect(connection.controller.signal, () => {
        connection.subscribers.forEach((subscriber) => subscriber.activity?.());
      })[Symbol.asyncIterator]();
      while (!connection.controller.signal.aborted) {
        const item = await iterator.next();
        if (item.done || connection.controller.signal.aborted)
          break;
        if (item.value.type === "server.connected")
          connection.connected = item.value;
        connection.subscribers.forEach((subscriber) => subscriber.push(item.value));
      }
    } catch (error) {
      completion = { error };
    } finally {
      stop(connection);
      try {
        await iterator?.return?.();
      } catch (error) {
        if (!("error" in completion))
          completion = { error };
      }
      connection.subscribers.forEach((subscriber) => subscriber.finish(completion));
    }
  }
  return {
    subscribe(options) {
      return {
        [Symbol.asyncIterator]() {
          const pending = [];
          const queued = [];
          let started = false;
          let completion;
          let connection;
          const types = options?.types?.length ? new Set(options.types) : void 0;
          const selected = (value) => !types || value.type === "server.connected" || types.has(value.type);
          function finish(result, discard = true) {
            completion = result;
            if (discard)
              queued.length = 0;
            options?.signal?.removeEventListener("abort", abort);
            if (connection?.subscribers.delete(subscriber) && !connection.subscribers.size)
              stop(connection);
            pending.splice(0).forEach((request2) => {
              if ("error" in result)
                request2.reject(result.error);
              else
                request2.resolve({ done: true, value: void 0 });
            });
          }
          function abort() {
            finish({});
          }
          const subscriber = {
            activity: options?.onActivity,
            finish(result) {
              finish(result, false);
            },
            push(value) {
              if (completion)
                return;
              if (!selected(value))
                return;
              const request2 = pending.shift();
              if (request2) {
                request2.resolve({ done: false, value });
                return;
              }
              if (queued.length === capacity) {
                finish({ error: new Error(`Event subscriber exceeded its ${capacity}-event capacity`) });
                return;
              }
              queued.push(value);
            }
          };
          function start() {
            if (completion)
              return;
            const fresh = !current;
            connection = current ?? {
              controller: new AbortController(),
              subscribers: /* @__PURE__ */ new Set()
            };
            current = connection;
            connection.subscribers.add(subscriber);
            if (connection.connected)
              subscriber.push(connection.connected);
            if (fresh)
              run(connection);
          }
          return {
            next() {
              const value = queued.shift();
              if (value)
                return Promise.resolve({ done: false, value });
              if (completion) {
                if ("error" in completion)
                  return Promise.reject(completion.error);
                return Promise.resolve({ done: true, value: void 0 });
              }
              if (options?.signal?.aborted) {
                abort();
                return Promise.resolve({ done: true, value: void 0 });
              }
              const request2 = Promise.withResolvers();
              pending.push(request2);
              if (!started) {
                started = true;
                options?.signal?.addEventListener("abort", abort, { once: true });
                start();
              }
              return request2.promise;
            },
            return() {
              finish({});
              return Promise.resolve({ done: true, value: void 0 });
            }
          };
        }
      };
    }
  };
}

// node_modules/@opencode/client/dist/chunks/rpc-runtime-js54wxgp.js
var ClientError2 = class extends Error {
  reason;
  name = "ClientError";
  constructor(reason, options) {
    const detail = options?.detail ?? (options?.cause instanceof Error ? options.cause.message : void 0);
    super(detail ? `${reason}: ${detail}` : reason, options);
    this.reason = reason;
  }
};

// node_modules/@opencode/client/dist/chunks/rpc-runtime-t2ajednw.js
var exports_client2 = {};
__export(exports_client2, {
  make: () => make3
});
var maxSseEventBytes = 16 * 1024 * 1024;
function make3(options) {
  const fetch = options.fetch ?? globalThis.fetch;
  const prepare = (descriptor, requestOptions) => {
    const baseUrl = new URL(options.baseUrl);
    if (!baseUrl.pathname.endsWith("/"))
      baseUrl.pathname += "/";
    const url = new URL(descriptor.path.slice(1), baseUrl);
    for (const [key, value] of Object.entries(descriptor.query ?? {}))
      appendQuery(url.searchParams, key, value);
    const headers = new Headers(options.headers);
    for (const [key, value] of Object.entries(descriptor.headers ?? {})) {
      if (value !== void 0 && value !== null)
        headers.set(key, String(value));
    }
    for (const [key, value] of new Headers(requestOptions?.headers))
      headers.set(key, value);
    if (descriptor.body !== void 0 && !headers.has("content-type"))
      headers.set("content-type", descriptor.binaryBody ? "application/octet-stream" : "application/json");
    return {
      url,
      init: {
        method: descriptor.method,
        signal: requestOptions?.signal,
        headers,
        body: descriptor.body === void 0 ? void 0 : descriptor.binaryBody ? descriptor.body : JSON.stringify(descriptor.body)
      }
    };
  };
  const execute = async (descriptor, requestOptions) => {
    try {
      const prepared = prepare(descriptor, requestOptions);
      return await fetch(prepared.url, prepared.init);
    } catch (cause) {
      throw new ClientError2("Transport", { cause });
    }
  };
  const responseError = async (response, descriptor) => {
    if (descriptor.declaredStatuses.includes(response.status))
      throw declared(await json(response));
    try {
      await response.body?.cancel();
    } catch {
    }
    throw new ClientError2("UnexpectedStatus", { cause: { status: response.status }, detail: String(response.status) });
  };
  const request2 = async (descriptor, requestOptions) => {
    const response = await execute(descriptor, requestOptions);
    if (response.status !== descriptor.successStatus)
      return responseError(response, descriptor);
    if (descriptor.binary)
      return new Uint8Array(await response.arrayBuffer());
    if (descriptor.empty) {
      try {
        await response.body?.cancel();
      } catch {
      }
      return;
    }
    return await json(response);
  };
  const sse = (descriptor, requestOptions) => ({
    async *[Symbol.asyncIterator]() {
      const response = await execute(descriptor, requestOptions);
      if (response.status !== descriptor.successStatus)
        await responseError(response, descriptor);
      if (!isContentType(response, "text/event-stream")) {
        try {
          await response.body?.cancel();
        } catch {
        }
        throw new ClientError2("UnsupportedContentType", { detail: response.headers.get("content-type") });
      }
      if (response.body === null)
        throw new ClientError2("MalformedResponse");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      try {
        while (true) {
          let next;
          try {
            next = await reader.read();
          } catch (cause) {
            throw new ClientError2("Transport", { cause });
          }
          if (!next.done)
            requestOptions?.onActivity?.();
          buffer += decoder.decode(next.value, { stream: !next.done });
          if (buffer.length > maxSseEventBytes)
            throw new ClientError2("SseEventTooLarge");
          const trailingCarriageReturn = !next.done && buffer.endsWith("\r");
          if (trailingCarriageReturn)
            buffer = buffer.slice(0, -1);
          buffer = buffer.replaceAll(`\r
`, `
`).replaceAll("\r", `
`);
          if (trailingCarriageReturn)
            buffer += "\r";
          if (next.done && buffer !== "")
            buffer += `

`;
          let boundary = buffer.indexOf(`

`);
          while (boundary >= 0) {
            const block = buffer.slice(0, boundary);
            buffer = buffer.slice(boundary + 2);
            const data = block.split(`
`).flatMap((line) => line.startsWith("data:") ? [line.slice(5).trimStart()] : []).join(`
`);
            if (data !== "") {
              try {
                yield JSON.parse(data);
              } catch (cause) {
                throw new ClientError2("MalformedResponse", { cause });
              }
            }
            boundary = buffer.indexOf(`

`);
          }
          if (next.done)
            return;
        }
      } finally {
        try {
          await reader.cancel();
        } catch {
        }
        reader.releaseLock();
      }
    }
  });
  const client = {
    server: {
      info: (requestOptions) => request2({ method: "GET", path: `/api/info`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions),
      pair: (requestOptions) => request2({ method: "POST", path: `/api/pair`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions),
      connect: (input, requestOptions) => request2({
        method: "GET",
        path: `/auth/connect/${encodeURIComponent(input.code)}`,
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions)
    },
    location: {
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/location`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      reload: (requestOptions) => request2({
        method: "POST",
        path: `/api/location/reload`,
        successStatus: 204,
        declaredStatuses: [400, 401, 503],
        empty: true
      }, requestOptions)
    },
    agent: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/agent`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/agent/${encodeURIComponent(input.agentID)}`,
        query: { location: input["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    plugin: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/plugin`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      gui: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/plugin/gui`,
        query: { location: input["location"], id: input["id"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      check: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/plugin/check`,
        query: { location: input?.["location"] },
        body: { target: input?.["target"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      update: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/plugin/update`,
        query: { location: input["location"] },
        body: { targets: input["targets"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 503],
        empty: true
      }, requestOptions)
    },
    session: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session`,
        query: {
          limit: input?.["limit"],
          order: input?.["order"],
          search: input?.["search"],
          parentID: input?.["parentID"],
          archived: input?.["archived"],
          directory: input?.["directory"],
          project: input?.["project"],
          subpath: input?.["subpath"],
          cursor: input?.["cursor"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions),
      create: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session`,
        body: {
          id: input?.["id"],
          parentID: input?.["parentID"],
          title: input?.["title"],
          agent: input?.["agent"],
          model: input?.["model"],
          location: input?.["location"],
          metadata: input?.["metadata"],
          permissions: input?.["permissions"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      active: (requestOptions) => request2({
        method: "GET",
        path: `/api/session/active`,
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions).then((value) => value.data),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input.sessionID)}`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      remove: (input, requestOptions) => request2({
        method: "DELETE",
        path: `/api/session/${encodeURIComponent(input.sessionID)}`,
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      fork: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/fork`,
        body: { before: input["before"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      switchAgent: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/agent`,
        body: { agent: input["agent"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      switchModel: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/model`,
        body: { model: input["model"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      update: (input, requestOptions) => request2({
        method: "PATCH",
        path: `/api/session/${encodeURIComponent(input.sessionID)}`,
        body: {
          title: input["title"],
          metadata: input["metadata"],
          permissions: input["permissions"],
          archived: input["archived"]
        },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      move: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/move`,
        body: { directory: input["directory"], delivery: input["delivery"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      prompt: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/prompt`,
        body: {
          id: input["id"],
          text: input["text"],
          files: input["files"],
          agents: input["agents"],
          skills: input["skills"],
          metadata: input["metadata"],
          delivery: input["delivery"],
          resume: input["resume"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      command: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/command`,
        body: {
          name: input["name"],
          text: input["text"],
          files: input["files"],
          agents: input["agents"],
          skills: input["skills"],
          delivery: input["delivery"]
        },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 500],
        empty: true
      }, requestOptions),
      synthetic: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/synthetic`,
        body: {
          id: input["id"],
          text: input["text"],
          description: input["description"],
          metadata: input["metadata"],
          delivery: input["delivery"],
          resume: input["resume"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      shell: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/shell`,
        body: { id: input["id"], command: input["command"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      compact: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/compact`,
        body: { id: input["id"], delivery: input["delivery"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      revert: {
        stage: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/revert/stage`,
          body: { messageID: input["messageID"], files: input["files"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409, 500],
          empty: false
        }, requestOptions).then((value) => value.data),
        clear: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/revert`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409, 500],
          empty: true
        }, requestOptions),
        commit: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/revert/commit`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      context: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/context`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions).then((value) => value.data),
      diff: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/diff`,
        query: { from: input["from"], to: input["to"], context: input["context"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions).then((value) => value.data),
      inbox: {
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/inbox`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        cancel: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/inbox/${encodeURIComponent(input.inboxID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        update: (input, requestOptions) => request2({
          method: "PATCH",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/inbox/${encodeURIComponent(input.inboxID)}`,
          body: { delivery: input["delivery"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      generate: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/generate`,
        body: { prompt: input["prompt"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions).then((value) => value.data),
      interrupt: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/interrupt`,
        query: { resume: input["resume"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      background: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/background`,
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      message: {
        get: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/message/${encodeURIComponent(input.messageID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      form: {
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/form`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        create: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/form`,
          body: { id: input["id"], title: input["title"], metadata: input["metadata"], fields: input["fields"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        get: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/form/${encodeURIComponent(input.formID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        reply: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/form/${encodeURIComponent(input.formID)}/reply`,
          body: { answer: input["answer"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions),
        cancel: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input.sessionID)}/form/${encodeURIComponent(input.formID)}`,
          query: { message: input["message"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      environment: (input, requestOptions) => request2({
        method: "PUT",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/environment`,
        body: { variables: input["variables"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      view: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/view`,
        body: { idle: input["idle"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    experimental: {
      session: {
        stats: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/stats`,
          query: {
            from: input?.["from"],
            to: input?.["to"],
            project: input?.["project"],
            timezone: input?.["timezone"],
            tools: input?.["tools"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401],
          empty: false
        }, requestOptions).then((value) => value.data),
        import: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/import`,
          body: { info: input["info"], messages: input["messages"], location: input["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        export: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/export`,
          query: { sanitize: input["sanitize"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 500],
          empty: false
        }, requestOptions).then((value) => value.data),
        skill: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/skill`,
          body: { id: input["id"], resume: input["resume"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        wait: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/wait`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        instructions: {
          entry: {
            list: (input, requestOptions) => request2({
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/instructions/entries`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false
            }, requestOptions).then((value) => value.data),
            put: (input, requestOptions) => request2({
              method: "PUT",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/instructions/entries/${encodeURIComponent(input.key)}`,
              body: { value: input["value"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 413],
              empty: true
            }, requestOptions),
            remove: (input, requestOptions) => request2({
              method: "DELETE",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/instructions/entries/${encodeURIComponent(input.key)}`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true
            }, requestOptions)
          }
        },
        log: (input, requestOptions) => sse({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/log`,
          query: { after: input["after"], follow: input["follow"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      generate: {
        text: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/generate/text`,
          body: { prompt: input["prompt"], model: input["model"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        image: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/generate/image`,
          body: {
            model: input["model"],
            prompt: input["prompt"],
            images: input["images"],
            n: input["n"],
            aspect: input["aspect"],
            resolution: input["resolution"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        decisions: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/generate/decisions`,
          body: { model: input["model"], input: input["input"], questions: input["questions"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      voice: {
        models: (requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/voice/models`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        session: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/voice/session`,
          body: { model: input["model"], session: input["session"], transport: input["transport"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      integration: {
        wellknown: {
          add: (input, requestOptions) => request2({
            method: "POST",
            path: `/api/experimental/integration/wellknown`,
            query: { location: input["location"] },
            body: { url: input["url"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true
          }, requestOptions)
        }
      },
      mcp: {
        add: (input, requestOptions) => request2({
          method: "PUT",
          path: `/api/experimental/mcp/${encodeURIComponent(input.server)}`,
          query: { location: input["location"] },
          body: { config: input["config"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        remove: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/mcp/${encodeURIComponent(input.server)}`,
          query: { location: input["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        connect: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/mcp/${encodeURIComponent(input.server)}/connect`,
          query: { location: input["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        disconnect: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/mcp/${encodeURIComponent(input.server)}/disconnect`,
          query: { location: input["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        client: {
          token: (input, requestOptions) => request2({
            method: "POST",
            path: `/api/experimental/client-mcp/token`,
            query: { location: input["location"], name: input["name"] },
            headers: { "x-opencode-ticket": input["x-opencode-ticket"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 403, 404],
            empty: false
          }, requestOptions)
        }
      },
      file: {
        write: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/fs/write`,
          query: { location: input["location"], path: input["path"] },
          body: input["payload"],
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false,
          binaryBody: true
        }, requestOptions),
        watch: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/fs/watch`,
          query: { location: input["location"] },
          body: { path: input["path"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        unwatch: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/fs/watch`,
          query: { location: input["location"] },
          body: { path: input["path"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      persistentPty: {
        read: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/terminal/read`,
          query: { lines: input["lines"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/terminal`,
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        create: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/terminal`,
          body: {
            command: input["command"],
            args: input["args"],
            cwd: input["cwd"],
            title: input["title"],
            env: input["env"],
            size: input["size"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        shutdown: (requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/persistent-pty/shutdown`,
          successStatus: 204,
          declaredStatuses: [400, 401, 503],
          empty: true
        }, requestOptions),
        handoff: (requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/persistent-pty/handoff`,
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions),
        get: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        update: (input, requestOptions) => request2({
          method: "PUT",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}`,
          body: { attachmentID: input["attachmentID"], size: input["size"], title: input["title"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 501, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        snapshot: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}/snapshot`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        remove: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        connectToken: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}/connect-token`,
          headers: { "x-opencode-ticket": input["x-opencode-ticket"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      media: {
        get: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/media/${encodeURIComponent(input.hash)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false,
          binary: true
        }, requestOptions)
      },
      schedule: {
        create: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/schedule`,
          body: {
            sessionID: input["sessionID"],
            name: input["name"],
            when: input["when"],
            if: input["if"],
            until: input["until"],
            ends: input["ends"],
            prompt: input["prompt"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/schedule`,
          query: { sessionID: input["sessionID"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        get: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        pause: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}/pause`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        resume: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}/resume`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        delete: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 403, 404],
          empty: true
        }, requestOptions)
      },
      artifacts: {
        providers: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts/providers`,
          query: { location: input?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts`,
          query: { location: input?.["location"], sessionID: input?.["sessionID"], provider: input?.["provider"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        create: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/artifacts`,
          query: { location: input["location"] },
          body: {
            title: input["title"],
            files: input["files"],
            entry: input["entry"],
            provider: input["provider"],
            sessionID: input["sessionID"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        get: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}`,
          query: { location: input["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        update: (input, requestOptions) => request2({
          method: "PATCH",
          path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}`,
          query: { location: input["location"] },
          body: {
            title: input["title"],
            files: input["files"],
            entry: input["entry"],
            sessionID: input["sessionID"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        delete: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}`,
          query: { location: input["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: true
        }, requestOptions),
        view: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}/view/${encodePath(input.path)}`,
          query: { location: input["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false,
          binary: true
        }, requestOptions)
      },
      migration: {
        v1: {
          status: (requestOptions) => request2({
            method: "GET",
            path: `/api/experimental/migration/v1`,
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false
          }, requestOptions)
        }
      },
      usage: {
        limits: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/usage/limits`,
          query: { location: input?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions)
      },
      config: {
        update: (input, requestOptions) => request2({
          method: "PATCH",
          path: `/api/experimental/config`,
          body: { shell: input["shell"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      }
    },
    message: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/message`,
        query: { limit: input["limit"], order: input["order"], cursor: input["cursor"], type: input["type"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions)
    },
    model: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/model`,
        query: { location: input?.["location"], types: input?.["types"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      default: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/model/default`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    provider: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/provider`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/provider/${encodeURIComponent(input.providerID)}`,
        query: { location: input["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    integration: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/integration`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/integration/${encodeURIComponent(input.integrationID)}`,
        query: { location: input["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      connect: {
        key: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/key`,
          query: { location: input["location"] },
          body: { key: input["key"], answer: input["answer"], label: input["label"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        external: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/external`,
          query: { location: input["location"] },
          body: { methodID: input["methodID"], answer: input["answer"], label: input["label"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      oauth: {
        connect: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth`,
          query: { location: input["location"] },
          body: { methodID: input["methodID"], answer: input["answer"], label: input["label"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        status: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth/${encodeURIComponent(input.attemptID)}`,
          query: { location: input["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        complete: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth/${encodeURIComponent(input.attemptID)}/complete`,
          query: { location: input["location"] },
          body: { code: input["code"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        cancel: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth/${encodeURIComponent(input.attemptID)}`,
          query: { location: input["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      command: {
        connect: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/command`,
          query: { location: input["location"] },
          body: { methodID: input["methodID"], label: input["label"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        status: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/command/${encodeURIComponent(input.attemptID)}`,
          query: { location: input["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        cancel: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/command/${encodeURIComponent(input.attemptID)}`,
          query: { location: input["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      }
    },
    mcp: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/mcp`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      resource: {
        catalog: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/mcp/resource`,
          query: { location: input?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      }
    },
    credential: {
      list: (requestOptions) => request2({ method: "GET", path: `/api/credential`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions).then((value) => value.data),
      create: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/credential`,
        body: {
          id: input["id"],
          integrationID: input["integrationID"],
          label: input["label"],
          value: input["value"],
          activate: input["activate"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      update: (input, requestOptions) => request2({
        method: "PATCH",
        path: `/api/credential/${encodeURIComponent(input.credentialID)}`,
        body: { label: input["label"] },
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions),
      activate: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/credential/${encodeURIComponent(input.credentialID)}/activate`,
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions),
      remove: (input, requestOptions) => request2({
        method: "DELETE",
        path: `/api/credential/${encodeURIComponent(input.credentialID)}`,
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions)
    },
    project: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/project`,
        query: { archived: input?.["archived"] },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions),
      update: (input, requestOptions) => request2({
        method: "PATCH",
        path: `/api/project/${encodeURIComponent(input.projectID)}`,
        body: {
          canonical: input["canonical"],
          name: input["name"],
          icon: input["icon"],
          commands: input["commands"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    form: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/form`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    permission: {
      request: {
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/permission/request`,
          query: { location: input?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      saved: {
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/permission/saved`,
          query: { projectID: input?.["projectID"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        update: (input, requestOptions) => request2({
          method: "PATCH",
          path: `/api/permission/saved/${encodeURIComponent(input.id)}`,
          body: { action: input["action"], resource: input["resource"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        remove: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/permission/saved/${encodeURIComponent(input.id)}`,
          successStatus: 204,
          declaredStatuses: [400, 401],
          empty: true
        }, requestOptions)
      },
      create: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/permission`,
        body: {
          id: input["id"],
          action: input["action"],
          resources: input["resources"],
          save: input["save"],
          metadata: input["metadata"],
          source: input["source"],
          agent: input["agent"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/permission`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/permission/${encodeURIComponent(input.requestID)}`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      reply: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input.sessionID)}/permission/${encodeURIComponent(input.requestID)}/reply`,
        body: { decision: input["decision"], message: input["message"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    file: {
      read: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/fs/read/${encodePath(input.path)}`,
        query: { location: input["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false,
        binary: true
      }, requestOptions),
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/fs/list`,
        query: { location: input?.["location"], path: input?.["path"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      find: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/fs/find`,
        query: { location: input["location"], query: input["query"], type: input["type"], limit: input["limit"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    command: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/command`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    skill: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/skill`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    rpc: {
      call: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/rpc/${encodeURIComponent(input.rpcID)}/${encodeURIComponent(input.method)}`,
        query: { location: input["location"] },
        body: { input: input["input"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions)
    },
    event: {
      subscribe: (input, requestOptions) => sse({
        method: "GET",
        path: `/api/event`,
        query: { types: input?.["types"] },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions)
    },
    pty: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/pty`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/pty`,
        query: { location: input?.["location"] },
        body: {
          command: input?.["command"],
          args: input?.["args"],
          cwd: input?.["cwd"],
          title: input?.["title"],
          env: input?.["env"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/pty/${encodeURIComponent(input.ptyID)}`,
        query: { location: input["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      update: (input, requestOptions) => request2({
        method: "PUT",
        path: `/api/pty/${encodeURIComponent(input.ptyID)}`,
        query: { location: input["location"] },
        body: { title: input["title"], size: input["size"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input, requestOptions) => request2({
        method: "DELETE",
        path: `/api/pty/${encodeURIComponent(input.ptyID)}`,
        query: { location: input["location"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      connect: {
        token: (input, requestOptions) => request2({
          method: "POST",
          path: `/api/pty/${encodeURIComponent(input.ptyID)}/connect-token`,
          query: { location: input["location"] },
          headers: { "x-opencode-ticket": input["x-opencode-ticket"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions)
      }
    },
    shell: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/shell`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/shell`,
        query: { location: input["location"] },
        body: {
          command: input["command"],
          cwd: input["cwd"],
          timeout: input["timeout"],
          metadata: input["metadata"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/shell/${encodeURIComponent(input.id)}`,
        query: { location: input["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      output: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/shell/${encodeURIComponent(input.id)}/output`,
        query: { location: input["location"], cursor: input["cursor"], limit: input["limit"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input, requestOptions) => request2({
        method: "DELETE",
        path: `/api/shell/${encodeURIComponent(input.id)}`,
        query: { location: input["location"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    reference: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/reference`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    worktree: {
      list: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/worktree`,
        query: { projectID: input["projectID"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/worktree`,
        body: {
          projectID: input["projectID"],
          from: input["from"],
          branch: input["branch"],
          directory: input["directory"],
          name: input["name"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input, requestOptions) => request2({
        method: "DELETE",
        path: `/api/worktree`,
        body: { projectID: input["projectID"], directory: input["directory"], force: input["force"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      refresh: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/worktree/refresh`,
        body: { projectID: input["projectID"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    vcs: {
      init: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/vcs/init`,
        query: { location: input?.["location"], provider: input?.["provider"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 409, 501, 503],
        empty: true
      }, requestOptions),
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      base: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs/base`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      status: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs/status`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      branch: {
        list: (input, requestOptions) => request2({
          method: "GET",
          path: `/api/vcs/branch`,
          query: { location: input?.["location"], search: input?.["search"], limit: input?.["limit"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      diff: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs/diff`,
        query: {
          location: input["location"],
          mode: input["mode"],
          base: input["base"],
          context: input["context"],
          untracked: input["untracked"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    debug: {
      heapDump: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/debug/heap-dump`,
        query: { directory: input?.["directory"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 500],
        empty: false
      }, requestOptions),
      location: {
        list: (requestOptions) => request2({
          method: "GET",
          path: `/api/debug/location`,
          successStatus: 200,
          declaredStatuses: [400, 401],
          empty: false
        }, requestOptions),
        evict: (input, requestOptions) => request2({
          method: "DELETE",
          path: `/api/debug/location`,
          query: { location: input?.["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401],
          empty: true
        }, requestOptions)
      }
    },
    websearch: {
      providers: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/websearch/provider`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      query: (input, requestOptions) => request2({
        method: "POST",
        path: `/api/websearch`,
        query: { location: input["location"] },
        body: { query: input["query"], providerID: input["providerID"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    config: {
      get: (input, requestOptions) => request2({
        method: "GET",
        path: `/api/config`,
        query: { location: input?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      shells: (requestOptions) => request2({
        method: "GET",
        path: `/api/config/shell`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    }
  };
  return {
    ...client,
    session: {
      ...client.session,
      stats: client.experimental.session.stats,
      import: client.experimental.session.import,
      export: client.experimental.session.export,
      skill: client.experimental.session.skill,
      wait: client.experimental.session.wait,
      instructions: {
        entry: {
          list: client.experimental.session.instructions.entry.list,
          put: client.experimental.session.instructions.entry.put,
          remove: client.experimental.session.instructions.entry.remove
        }
      },
      log: client.experimental.session.log
    },
    generate: {
      text: client.experimental.generate.text,
      image: client.experimental.generate.image,
      decisions: client.experimental.generate.decisions
    },
    voice: {
      models: client.experimental.voice.models,
      session: client.experimental.voice.session
    },
    integration: {
      ...client.integration,
      wellknown: {
        add: client.experimental.integration.wellknown.add
      }
    },
    mcp: {
      ...client.mcp,
      add: client.experimental.mcp.add,
      remove: client.experimental.mcp.remove,
      connect: client.experimental.mcp.connect,
      disconnect: client.experimental.mcp.disconnect,
      client: {
        token: client.experimental.mcp.client.token
      }
    },
    file: {
      ...client.file,
      write: client.experimental.file.write,
      watch: client.experimental.file.watch,
      unwatch: client.experimental.file.unwatch
    },
    migration: {
      v1: {
        status: client.experimental.migration.v1.status
      }
    },
    usage: {
      limits: client.experimental.usage.limits
    },
    config: {
      ...client.config,
      update: client.experimental.config.update
    }
  };
}
function encodePath(value) {
  return value.split("/").map(encodeURIComponent).join("/");
}
function appendQuery(params, key, value) {
  if (value === void 0)
    return;
  if (value === null) {
    params.append(key, "null");
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value)
      appendQuery(params, key, item);
    return;
  }
  if (typeof value === "object") {
    for (const [child, item] of Object.entries(value))
      appendQuery(params, `${key}[${child}]`, item);
    return;
  }
  params.append(key, String(value));
}
async function json(response) {
  if (!isContentType(response, "application/json") && !response.headers.get("content-type")?.includes("+json")) {
    try {
      await response.body?.cancel();
    } catch {
    }
    throw new ClientError2("UnsupportedContentType", { detail: response.headers.get("content-type") });
  }
  let text;
  try {
    text = await response.text();
  } catch (cause) {
    throw new ClientError2("Transport", { cause });
  }
  if (text === "")
    throw new ClientError2("MalformedResponse");
  try {
    return JSON.parse(text);
  } catch (cause) {
    throw new ClientError2("MalformedResponse", { cause });
  }
}
function declared(body) {
  const error = Object.assign(new Error(body.message ?? body.data?.message), body);
  if (body._tag)
    error.name = body._tag;
  return error;
}
function isContentType(response, expected) {
  return response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() === expected;
}

// node_modules/@opencode/client/dist/chunks/rpc-runtime-sdjh9vmn.js
var isRpcError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "RpcError";
var isRpcInternalError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "RpcInternalError";

// node_modules/@opencode/client/dist/chunks/rpc-runtime-xqwq6bgr.js
function makeRpc2(raw, events) {
  return (definition) => {
    const subscribe = (name, options) => {
      if (!Object.hasOwn(definition.events, name))
        throw new Error(`Unknown RPC event: ${definition.id}.${name}`);
      const type = eventType(definition, name);
      return {
        [Symbol.asyncIterator]() {
          const controller = new AbortController();
          const signal = options?.signal ? AbortSignal.any([controller.signal, options.signal]) : controller.signal;
          const iterator = (async function* () {
            try {
              for await (const published of events.subscribe({ signal })) {
                if (signal.aborted)
                  return;
                if (published.type !== type)
                  continue;
                yield published;
              }
            } catch (error) {
              if (!signal.aborted)
                throw error;
            } finally {
              controller.abort();
            }
          })();
          return {
            next: () => iterator.next(),
            return: () => {
              controller.abort();
              return iterator.return();
            }
          };
        }
      };
    };
    return Object.assign(Object.fromEntries(Object.keys(definition.methods).map((name) => [
      name,
      async (input, options) => {
        try {
          const result = await raw.rpc.call({
            rpcID: definition.id,
            method: name,
            input,
            location: options?.location
          }, { signal: options?.signal, headers: options?.headers });
          return result.output;
        } catch (error) {
          if (!isRpcError2(error) && !isRpcInternalError2(error))
            throw error;
          throw error.data === void 0 ? { type: error.type, message: error.message } : { type: error.type, message: error.message, data: error.data };
        }
      }
    ])), {
      events: {
        subscribe,
        on: (name, handler, options) => {
          const controller = new AbortController();
          const signal = options?.signal ? AbortSignal.any([controller.signal, options.signal]) : controller.signal;
          const source = subscribe(name, { signal });
          (async () => {
            for await (const event of source)
              await handler(event);
          })().catch((error) => console.error(error));
          return () => controller.abort();
        }
      }
    });
  };
}
function eventType(definition, name) {
  return `rpc.${definition.id}.${name}`;
}

// node_modules/@opencode/client/dist/chunks/rpc-runtime-wbnz2gjn.js
var exports_client = {};
__export(exports_client, {
  OpenCode: () => exports_client,
  make: () => make2
});
function make2(options) {
  const raw = make3(options);
  const events = make7((signal, onActivity) => raw.event.subscribe(void 0, { signal, onActivity }));
  return {
    ...raw,
    rpc: Object.assign(makeRpc2(raw, events), raw.rpc),
    event: events
  };
}

// packages/integration-kit/src/panel.ts
var import_node_path = require("node:path");

// packages/integration-kit/src/contract.ts
var MAX_OFFERS = 16;
var LABEL_MAX = 120;
var DETAIL_MAX = 300;
var APP_VERSION_MAX = 64;
var SEMVER_PATTERN = "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?(\\+[0-9A-Za-z.-]+)?$";
var DISPLAY_PATTERN = "^[^/\\\\\\p{Cc}]+$";
var HANDLE_PATTERN = "^[^\\p{Cc}]+$";
var CONTROL_PATTERN = "[\\p{Cc}]";
var OFFER_ID_PATTERN = "^[A-Za-z0-9_-]{8,64}$";
var SESSION_ID_PATTERN = "^[A-Za-z0-9_-]{1,128}$";
var GENERATION_PATTERN = "^[A-Za-z0-9_-]{1,128}(?![\\s\\S])";
var semver = () => ({ type: "string", maxLength: 64, pattern: SEMVER_PATTERN });
var display = (maxLength) => ({ type: "string", minLength: 1, maxLength, pattern: DISPLAY_PATTERN });
var empty = () => ({ type: "object", additionalProperties: false, properties: {} });
var outcome = (values) => ({
  type: "object",
  required: ["outcome"],
  properties: { outcome: { enum: values } }
});
var bindingAuthority = {
  type: "object",
  additionalProperties: false,
  required: ["serviceGeneration", "registryGeneration", "revision"],
  properties: {
    serviceGeneration: { type: "string", pattern: GENERATION_PATTERN },
    registryGeneration: { type: "string", pattern: GENERATION_PATTERN },
    revision: { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER }
  }
};
var publicBinding = {
  type: "object",
  additionalProperties: false,
  required: ["offerID", "label"],
  properties: {
    offerID: { type: "string", pattern: `${OFFER_ID_PATTERN}(?![\\s\\S])` },
    label: display(LABEL_MAX)
  }
};
var RPC_SCHEMAS = {
  "status.input": empty(),
  "status.output": {
    type: "object",
    required: ["contract", "integration"],
    properties: {
      contract: { const: 1 },
      integration: {
        type: "object",
        required: ["id", "version", "family", "spec"],
        properties: {
          id: { type: "string", pattern: "^[a-z][a-z0-9-]{0,31}$" },
          version: semver(),
          family: { enum: ["native", "vendor-mcp", "api"] },
          spec: { const: 0 }
        }
      },
      host: {
        type: "object",
        required: ["state"],
        properties: {
          state: { enum: ["absent", "incompatible", "outdated", "ok", "unknown", "unsupported"] },
          partVersion: semver(),
          expectedRange: { type: "string", minLength: 1, maxLength: 64, pattern: "^[0-9xX*^~<>=|. -]+$" },
          appVersion: display(APP_VERSION_MAX),
          action: { enum: ["install", "update"] }
        }
      },
      connection: {
        type: "object",
        required: ["state"],
        properties: {
          state: { enum: ["none", "available", "attached", "connected", "signed_out", "error"] },
          offers: { type: "integer", minimum: 0, maximum: MAX_OFFERS },
          attachedSessions: { type: "integer", minimum: 0, maximum: 1e4 }
        }
      },
      notices: {
        type: "array",
        maxItems: 8,
        uniqueItems: true,
        items: { type: "string", pattern: "^[a-z][a-z0-9_]{0,31}$" }
      }
    }
  },
  "installHost.input": { type: "object", additionalProperties: false, properties: { target: { const: "default" } } },
  "installHost.output": {
    type: "object",
    required: ["outcome"],
    properties: {
      outcome: { enum: ["installed", "updated", "unchanged", "refused", "failed"] },
      detail: display(DETAIL_MAX)
    }
  },
  "hosts.input": empty(),
  "hosts.output": {
    type: "object",
    required: ["offers"],
    properties: {
      offers: {
        type: "array",
        maxItems: MAX_OFFERS,
        items: {
          type: "object",
          required: ["offerID", "label", "protocol"],
          properties: {
            offerID: { type: "string", pattern: OFFER_ID_PATTERN },
            label: display(LABEL_MAX),
            document: display(LABEL_MAX),
            appVersion: display(APP_VERSION_MAX),
            protocol: { enum: ["ok", "incompatible"] }
          }
        }
      }
    }
  },
  "attachHost.input": {
    type: "object",
    additionalProperties: false,
    required: ["offerID", "sessionID"],
    properties: {
      offerID: { type: "string", pattern: OFFER_ID_PATTERN },
      sessionID: { type: "string", pattern: SESSION_ID_PATTERN },
      takeover: { type: "boolean" }
    }
  },
  "attachHost.output": {
    ...outcome(["attached", "busy", "gone", "refused"]),
    properties: {
      outcome: { enum: ["attached", "busy", "gone", "refused"] },
      replaced: { type: "boolean" }
    }
  },
  "detachHost.input": {
    type: "object",
    additionalProperties: false,
    required: ["sessionID"],
    properties: { sessionID: { type: "string", pattern: SESSION_ID_PATTERN } }
  },
  "detachHost.output": outcome(["detached", "none"]),
  "bindingRead.input": {
    type: "object",
    additionalProperties: false,
    required: ["sessionID"],
    properties: { sessionID: { type: "string", pattern: `${SESSION_ID_PATTERN}(?![\\s\\S])` } }
  },
  "bindingRead.output": {
    type: "object",
    oneOf: [
      {
        type: "object",
        additionalProperties: false,
        required: ["state", "authority", "binding"],
        properties: { state: { const: "attached" }, authority: bindingAuthority, binding: publicBinding }
      },
      {
        type: "object",
        additionalProperties: false,
        required: ["state", "authority"],
        properties: { state: { const: "none" }, authority: bindingAuthority }
      },
      {
        type: "object",
        additionalProperties: false,
        required: ["state"],
        properties: { state: { const: "unknown" }, authority: bindingAuthority }
      }
    ]
  },
  "advertise.output": {
    ...outcome(["accepted", "renewed", "refused"]),
    properties: {
      outcome: { enum: ["accepted", "renewed", "refused"] },
      panel_runtime: { type: "string", maxLength: 4096 }
    }
  },
  "withdraw.output": outcome(["withdrawn", "none"]),
  "status_changed.event": empty(),
  "hosts_changed.event": empty()
};
var OPAQUE_INPUT = { type: "object" };
function withoutPatterns(value) {
  if (Array.isArray(value)) return value.map(withoutPatterns);
  if (typeof value !== "object" || value === null) return value;
  return Object.fromEntries(
    Object.entries(value).filter(([key, item]) => !(key === "pattern" && typeof item === "string")).map(([key, item]) => [key, withoutPatterns(item)])
  );
}
function rpcDefinition(rpcID, family) {
  const schemas = RPC_SCHEMAS;
  const schema = (name) => withoutPatterns(schemas[name] ?? OPAQUE_INPUT);
  const io = (method, input) => ({
    input: input ? structuredClone(input) : schema(`${method}.input`),
    output: schema(`${method}.output`)
  });
  const event = (name) => ({ schema: { ...schema(`${name}.event`), type: "object" } });
  const methods = { status: io("status") };
  const events = { status_changed: event("status_changed") };
  if (family === "native") {
    methods.installHost = io("installHost");
    methods.hosts = io("hosts");
    methods.attachHost = io("attachHost");
    methods.detachHost = io("detachHost");
    methods.bindingRead = io("bindingRead");
    methods.advertise = io("advertise", OPAQUE_INPUT);
    methods.withdraw = io("withdraw", OPAQUE_INPUT);
    events.hosts_changed = event("hosts_changed");
  }
  return { id: rpcID, methods, events };
}
var DISPLAY = new RegExp(DISPLAY_PATTERN, "u");
var HANDLE = new RegExp(HANDLE_PATTERN, "u");
function boundedDetail(value) {
  const clean = value.replace(/[/\\]/g, " ").replace(new RegExp(CONTROL_PATTERN, "gu"), " ").replace(/\s+/g, " ").trim();
  const bounded = [...clean].slice(0, DETAIL_MAX).join("").trim();
  return bounded.length > 0 ? bounded : void 0;
}

// packages/integration-kit/src/host-client.ts
var import_node_crypto = require("node:crypto");
var import_node_net = __toESM(require("node:net"), 1);
var HOST_ADDRESS = "127.0.0.1";
var MAX_REQUEST_BYTES = 1024 * 1024;
var MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
var DEFAULT_HOST_TIMEOUT_MS = 3e4;
var HOST_ERROR_CODES = [
  "unauthorized",
  "invalid_request",
  "method_not_found",
  "method_disabled",
  "invalid_args",
  "stale_handle",
  "stale_revision",
  "expectation_failed",
  "mode_conflict",
  "busy",
  "quarantined",
  "permission_denied",
  "internal"
];
var HostError = class extends Error {
  code;
  // The host's own explanation of a refusal, as bounded display text; never the endpoint.
  detail;
  // The details the host gave with its refusal (`error.data`, a JSON object), such as the current revision.
  data;
  constructor(code, message, detail, data) {
    super(message);
    this.name = "HostError";
    this.code = code;
    this.detail = detail;
    this.data = data;
  }
};
var MESSAGE_TEXT_MAX = 300;
var MESSAGE_DATA_MAX = 2e3;
function refusalText(message) {
  if (typeof message !== "string") return void 0;
  const clean = message.replace(new RegExp("\\p{Cc}", "gu"), " ").replace(/\s+/g, " ").trim();
  return clean ? [...clean].slice(0, MESSAGE_TEXT_MAX).join("") : void 0;
}
function refusalData(data) {
  if (typeof data !== "object" || data === null || Array.isArray(data) || !Object.keys(data).length) return void 0;
  return data;
}
function refusalMessage(code, text, data) {
  let message = `Host refused the request (${code})${text ? `: ${text}` : "."}`;
  if (data) {
    const json2 = JSON.stringify(data);
    message += ` ${json2.length > MESSAGE_DATA_MAX ? `${json2.slice(0, MESSAGE_DATA_MAX)}\u2026` : json2}`;
  }
  return message;
}
async function requestHost(endpoint, method, params = {}, options = {}) {
  if (endpoint.host !== HOST_ADDRESS) throw new HostError("invalid_request", "Hosts listen on 127.0.0.1 only.");
  const id = (0, import_node_crypto.randomUUID)();
  const line = `${JSON.stringify({ id, token: endpoint.token, method, params })}
`;
  if (Buffer.byteLength(line) > MAX_REQUEST_BYTES) throw new HostError("invalid_request", "Host request is too large.");
  const timeoutMs = options.timeoutMs ?? DEFAULT_HOST_TIMEOUT_MS;
  return await new Promise((resolve, reject) => {
    const socket = import_node_net.default.createConnection({ host: HOST_ADDRESS, port: endpoint.port });
    let buffer = Buffer.alloc(0);
    let settled = false;
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", abort);
      socket.destroy();
      if (error) reject(error);
      else resolve(result);
    };
    const abort = () => finish(new HostError("cancelled", "Host request cancelled."));
    const timer = setTimeout(() => finish(new HostError("timeout", "Host request timed out.")), timeoutMs);
    options.signal?.addEventListener("abort", abort, { once: true });
    if (options.signal?.aborted) return abort();
    socket.on("connect", () => socket.write(line));
    socket.on("data", (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      const newline = buffer.indexOf(10);
      if (newline < 0) {
        if (buffer.byteLength > MAX_RESPONSE_BYTES)
          finish(new HostError("invalid_response", "Host response too large."));
        return;
      }
      let envelope;
      try {
        envelope = JSON.parse(buffer.subarray(0, newline).toString("utf8"));
      } catch {
        return finish(new HostError("invalid_response", "Host returned malformed JSON."));
      }
      if (typeof envelope !== "object" || envelope === null || Array.isArray(envelope)) {
        return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      }
      const response = envelope;
      if (response.id !== id) return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      if (response.ok === false) {
        const raw = response.error?.code;
        const code = typeof raw === "string" && HOST_ERROR_CODES.includes(raw) ? raw : "internal";
        const detail = typeof response.error?.message === "string" ? boundedDetail(response.error.message) : void 0;
        const data = refusalData(response.error?.data);
        const message = refusalMessage(code, refusalText(response.error?.message), data);
        return finish(new HostError(code, message, detail, data));
      }
      if (response.ok !== true || !("result" in response)) {
        return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      }
      finish(null, response.result);
    });
    socket.on("error", () => finish(new HostError("unreachable", "Host is unreachable.")));
    socket.on("end", () => finish(new HostError("unreachable", "Host closed the connection.")));
  });
}

// packages/integration-kit/src/panel.ts
var PanelError = class extends Error {
};
var WaitingForOffer = class extends Error {
};
function toolDisplay(name, input) {
  if (name !== "execute") return name;
  const code = input?.code;
  if (typeof code !== "string") return name;
  const names = new Set(
    Array.from(
      code.matchAll(/\btools\.(\w+)(?:\.(\w+)|\[['"]([\w-]+)['"]\])\s*\(/g),
      ([, ns, dot, key]) => `${ns}_${dot ?? key}`
    )
  );
  if (names.size) return [...names].join(", ");
  return /\bsearch\s*\(/.test(code) ? null : name;
}
function briefly(error) {
  const text = String(error?.message ?? error ?? "unknown error").split(/\r?\n/)[0]?.replace(/\b[0-9a-f]{32,}\b/gi, "\u2026").replace(/(basic|bearer)\s+\S+/gi, "$1 \u2026").replace(/\b(port\s+|:)\d{2,5}\b/gi, "$1\u2026").slice(0, 240);
  return `${text || "unknown error"}${/[.!?]$/.test(text ?? "") ? "" : "."}`;
}
var modelKey = (model) => model ? `${model.providerID}/${model.id}${model.variant ? `#${model.variant}` : ""}` : "";
var HISTORY_LIMIT = 20;
function conversationEntry({ id, title, time }) {
  const minutes = time?.updated ? Math.max(0, Math.floor((Date.now() - time.updated) / 6e4)) : 0;
  const age = minutes >= 1440 ? `${Math.floor(minutes / 1440)}d` : minutes >= 60 ? `${Math.floor(minutes / 60)}h` : `${minutes}m`;
  return { id, title: `${title || "Untitled"} (${age} ago)` };
}
function history(messages) {
  return messages.flatMap((message) => {
    if (message.type === "user") return [{ role: "user", text: message.text ?? "" }];
    if (message.type !== "assistant") return [];
    return (message.content ?? []).flatMap((part) => {
      if (part.type === "text") return [{ role: "assistant", text: part.text ?? "" }];
      if (part.type === "tool") {
        const name = toolDisplay(part.name || "tool", part.state?.input);
        if (name === null) return [];
        const state = { running: "starting", streaming: "starting", error: "failed", completed: "completed" }[part.state?.status ?? ""] ?? "unknown";
        return [{ role: "tool", text: `${name} / ${state}`, name, state }];
      }
      return [];
    });
  });
}
function createPanel(config, deps) {
  const requestHost2 = deps.requestHost ?? requestHost;
  const checkEveryMs = deps.checkEveryMs ?? 5e3;
  const channels = /* @__PURE__ */ new Map();
  const targets = /* @__PURE__ */ new Map();
  const queues = /* @__PURE__ */ new Map();
  let stopping = false;
  let client;
  let registration;
  let rpc = {};
  const event = (c, name, data) => deps.send({ channel: c.id, event: name, data });
  const options = (c) => ({
    location: { directory: c.directory },
    signal: AbortSignal.timeout(3e3)
  });
  const host = (c, method) => config.hostControls === false ? Promise.resolve() : requestHost2(c.host, method, { script_handle: c.handle, session_id: c.sessionID }, { timeoutMs: 2e3 });
  async function api() {
    if (client) return client;
    const found = await deps.discover(registration);
    if (!found) throw new PanelError("Start OpenCode to use this conversation.");
    client = found;
    rpc = found.rpc(rpcDefinition(config.rpcID, "native"));
    return client;
  }
  async function findOffer(c) {
    let result;
    try {
      result = await rpc.hosts?.({}, options(c));
    } catch (error) {
      if (/RPC is unavailable|timed out|TimeoutError/i.test(briefly(error))) throw new WaitingForOffer();
      throw error;
    }
    const offers = (result?.offers ?? []).filter(
      (offer) => offer.label === c.label
    );
    if (offers.length > 1)
      throw new PanelError(`Several ${config.duplicateOffer} offer ${c.label}; this panel cannot pick one.`);
    if (!offers[0]) throw new WaitingForOffer();
    return offers[0];
  }
  async function attached(c) {
    const read = await c.rpc.bindingRead?.({ sessionID: c.sessionID }, options(c));
    return read?.state === "attached" && read.binding?.offerID === c.offerID;
  }
  async function folderSessions(service, directory) {
    let cursor;
    const sessions = [];
    do {
      const listed = await service.session.list({ directory, archived: false, order: "desc", limit: 100, cursor });
      sessions.push(
        ...listed.data.filter(
          (candidate) => !candidate.time?.archived && (!candidate.location || folderKey(candidate.location.directory) === folderKey(directory))
        )
      );
      cursor = listed.cursor.next ?? void 0;
    } while (cursor);
    return sessions.sort((a, b) => (b.time?.updated ?? 0) - (a.time?.updated ?? 0));
  }
  function folderKey(path) {
    const key = (0, import_node_path.normalize)(String(path ?? "")).replace(/[/\\]$/, "");
    return process.platform === "win32" ? key.toLowerCase() : key;
  }
  async function conversationList(target, directory) {
    const sessions = await folderSessions(await api(), directory);
    event(target, "conversations", {
      selected: target.selected,
      entries: sessions.map(conversationEntry)
    });
    return sessions;
  }
  async function close(c) {
    if (channels.get(c.id) === c) channels.delete(c.id);
    c.abort.abort();
    if ([...channels.values()].some((other) => other.sessionID === c.sessionID && other.offerID === c.offerID)) return;
    await attached(c).then((still) => still ? c.rpc.detachHost?.({ sessionID: c.sessionID }, options(c)) : void 0).catch(() => {
    });
  }
  function forward(c, type, data) {
    if (type === "session.model.selected") {
      c.model = data.model;
      event(c, "model", { selected: modelKey(c.model) });
    } else if (config.agent && type === "session.agent.selected") event(c, "agent", { agent: data.agent ?? null });
    else if (config.consoleEvents && type === "session.step.started") {
      c.model = data.model;
      event(c, "profile", { agent: data.agent, model: modelKey(c.model) });
    } else if (type === "session.execution.started") status(c, true);
    else if (type === "session.text.started") event(c, "assistant_start", {});
    else if (type === "session.text.delta") event(c, "assistant_delta", { text: data.delta ?? "" });
    else if (type === "session.text.ended") event(c, "assistant_end", {});
    else if (type === "session.tool.input.started") {
      c.tools.set(String(data.id), { name: String(data.name ?? "tool"), started: performance.now() });
      if (data.name !== "execute") event(c, "tool", { id: data.id, name: data.name, state: "starting" });
    } else if (type === "session.tool.called") {
      const tool = c.tools.get(String(data.id));
      if (tool?.name === "execute" && tool.display === void 0) {
        tool.display = toolDisplay(tool.name, data.input);
        if (tool.display !== null) event(c, "tool", { id: data.id, name: tool.display, state: "starting" });
      }
    } else if (type === "session.tool.success" || type === "session.tool.failed") {
      const tool = c.tools.get(String(data.id));
      c.tools.delete(String(data.id));
      if (tool?.display === null) return;
      event(c, "tool", {
        id: data.id,
        name: tool?.display ?? tool?.name,
        state: type === "session.tool.success" ? "completed" : "failed",
        ...config.consoleEvents && tool ? { duration_ms: Math.round(performance.now() - tool.started) } : {}
      });
    } else if (type === "permission.asked")
      event(c, "permission", { request_id: data.id, action: data.action, resources: data.resources ?? [] });
    else if (config.consoleEvents && type === "permission.replied")
      event(c, "permission_done", { request_id: data.requestID });
    else if (type === "session.execution.succeeded" || type === "session.idle") status(c, false);
    else if (type === "session.execution.interrupted" || type === "session.execution.failed") {
      if (type === "session.execution.failed") event(c, "error", { message: "OpenCode execution failed." });
      status(c, false, config.consoleEvents && type === "session.execution.interrupted");
      void host(c, "cancel").catch(() => {
      });
    }
  }
  function status(c, busy, interrupted) {
    c.busy = busy;
    event(c, "status", { state: busy ? "busy" : "idle", ...interrupted ? { interrupted: true } : {} });
  }
  async function stream(c, service) {
    try {
      for await (const item of service.event.subscribe({ signal: c.abort.signal })) {
        const data = item.data;
        if (data?.sessionID !== c.sessionID) continue;
        if (item.type === "session.renamed") {
          void serialize(c.id, async () => {
            const target = targets.get(c.id);
            if (target && channels.get(c.id) === c) await conversationList(target, c.directory);
          }).catch(() => {
          });
        } else forward(c, item.type, data);
      }
    } catch {
    }
    if (!c.abort.signal.aborted) {
      void serialize(c.id, async () => {
        if (channels.get(c.id) !== c) return;
        const target = targets.get(c.id);
        if (target) await reconnect(target, c);
      });
    }
  }
  const step = async (doing, work) => {
    try {
      return await work();
    } catch (error) {
      if (error instanceof PanelError || error instanceof WaitingForOffer) throw error;
      throw new PanelError(`Could not connect while ${doing}: ${briefly(error)}`);
    }
  };
  async function connect(target, params) {
    const id = target.id;
    const previous = channels.get(id);
    if (previous) await close(previous);
    if (!params.token || !params.offer_label) throw new WaitingForOffer();
    if (params.host !== "127.0.0.1" || !Number.isInteger(params.port) || !/^[0-9a-f]{64}$/.test(String(params.token)))
      throw new Error("Invalid host endpoint.");
    const directory = String(params.directory ?? "");
    const label = String(params.offer_label ?? "");
    const handle2 = String(params.script_handle ?? "");
    if (!directory || !label || !handle2) throw new Error("Incomplete connect request.");
    const next = typeof params.registration === "string" ? params.registration : void 0;
    if (next !== registration) client = void 0;
    registration = next;
    const service = await step("reaching OpenCode", api);
    const currentRpc = service.rpc(rpcDefinition(config.rpcID, "native"));
    const offer = await step(`finding this ${config.document}'s offer`, () => findOffer({ directory, label }));
    const sessions = await step("listing conversations in this folder", () => folderSessions(service, directory));
    const known = target.fresh ? void 0 : sessions.find((s) => s.id === target.selected) ?? sessions[0];
    if (!known && !target.pending.length) {
      if (!target.empty) {
        target.empty = true;
        event(target, "session", { id: null, draft: Boolean(target.fresh), workspace: directory });
        event(target, "history", { messages: [] });
        event(target, "conversations", {
          entries: sessions.map(conversationEntry)
        });
        event(target, "status", { state: "idle" });
      }
      return;
    }
    const session = known ?? await step(
      `creating this ${config.document}'s conversation`,
      () => service.session.create({
        location: { directory }
      })
    );
    target.fresh = false;
    target.empty = false;
    target.selected = session.id;
    const c = {
      id,
      directory,
      sessionID: session.id,
      label,
      offerID: offer.offerID,
      host: { host: "127.0.0.1", port: Number(params.port), token: String(params.token) },
      handle: handle2,
      rpc: currentRpc,
      abort: new AbortController(),
      tools: /* @__PURE__ */ new Map(),
      busy: false,
      model: session.model
    };
    try {
      const result = await step(
        `attaching the conversation to this ${config.document}`,
        async () => c.rpc.attachHost?.({ offerID: offer.offerID, sessionID: c.sessionID, takeover: true }, options(c))
      );
      if (result?.outcome === "busy")
        throw new PanelError("This conversation is attached to another application; detach it there first.");
      if (result?.outcome !== "attached") throw new PanelError(`${config.app} attachment was refused.`);
      channels.set(id, c);
      const [messages, models, configured, active] = await step(
        "loading the conversation",
        () => Promise.all([
          service.message.list({ sessionID: c.sessionID, order: "desc", limit: HISTORY_LIMIT + 1 }),
          service.model.list({ location: { directory } }),
          service.model.default({ location: { directory } }),
          service.session.active()
        ])
      );
      if (!c.model && configured.data) c.model = configured.data;
      const recent = history(messages.data.slice(0, HISTORY_LIMIT).reverse());
      if (messages.data.length > HISTORY_LIMIT || messages.cursor?.next)
        recent.unshift({ role: "system", text: "Earlier messages are available in OpenCode." });
      event(c, "history", { messages: recent });
      event(c, "session", {
        id: c.sessionID,
        resumed: Boolean(known),
        model: modelKey(c.model),
        ...config.agent ? { agent: session.agent ?? null } : {},
        workspace: directory
      });
      event(c, "models", {
        selected: modelKey(c.model),
        models: models.data.filter((model) => model.enabled).map((model) => ({ id: model.id, provider_id: model.providerID, name: model.name }))
      });
      event(target, "conversations", {
        selected: session.id,
        entries: (known ? sessions : [session, ...sessions]).map(conversationEntry)
      });
      if (result.replaced) event(c, "notice", { message: "Conversation moved from another host to this one." });
      status(c, active[c.sessionID]?.type === "running");
      void stream(c, service);
    } catch (error) {
      await close(c);
      throw error;
    }
  }
  async function act(c, method, params) {
    if (method === "close") return await close(c);
    const service = await api();
    if (method === "interrupt") {
      await host(c, "cancel").catch(() => {
      });
      await service.session.interrupt({ sessionID: c.sessionID, resume: false });
    } else if (method === "switch_model") {
      const key = String(params.model ?? "");
      const catalog = await service.model.list({ location: { directory: c.directory } });
      const selected = catalog.data.find((model) => model.enabled && `${model.providerID}/${model.id}` === key);
      if (!selected) throw new PanelError("This model is not available in this workspace.");
      c.model = { id: selected.id, providerID: selected.providerID };
      await service.session.switchModel({ sessionID: c.sessionID, model: c.model });
      event(c, "model", { selected: modelKey(c.model) });
    } else if (method === "permission_reply") {
      const decision = params.reply;
      if (decision !== "once" && decision !== "reject") throw new Error("Invalid permission answer.");
      await service.permission.reply({ sessionID: c.sessionID, requestID: String(params.request_id), decision });
    } else throw new Error("Unknown panel action.");
  }
  function serialize(id, work) {
    if (stopping) return Promise.resolve();
    const next = (queues.get(id) ?? Promise.resolve()).then(work);
    queues.set(id, next);
    void next.finally(() => {
      if (queues.get(id) === next) queues.delete(id);
    }).catch(() => {
    });
    return next;
  }
  function later(target, ms) {
    clearTimeout(target.retry);
    if (stopping) return;
    target.retry = setTimeout(() => {
      void serialize(target.id, async () => {
        if (targets.get(target.id) !== target) return;
        const c = channels.get(target.id);
        if (c && !await attached(c).catch(() => false)) await reconnect(target, c);
        else {
          if (c?.busy) {
            const active = await (await api()).session.active().catch(() => void 0);
            if (active && active[c.sessionID]?.type !== "running" && c.busy)
              status(c, false);
          }
          await reconcile(target);
        }
      });
    }, ms);
    target.retry.unref?.();
  }
  async function reconnect(target, c) {
    const read = await c.rpc.bindingRead?.({ sessionID: c.sessionID }, options(c)).catch(() => void 0);
    if (read?.state === "attached" && read.binding.offerID !== c.offerID) {
      target.taken = true;
      await close(c);
      event(target, "status", { state: "connecting" });
      event(target, "notice", { message: "Conversation moved to another host. Open it again here to take it back." });
      return;
    }
    event(target, "status", { state: "connecting" });
    await close(c);
    client = void 0;
    later(target, deps.retryMs ?? 1e3);
  }
  async function reconcile(target) {
    if (!target.params || target.taken || stopping) return;
    let c = channels.get(target.id);
    if (!c) {
      try {
        await connect(target, target.params);
        target.problem = void 0;
      } catch (error) {
        client = void 0;
        if (!(error instanceof WaitingForOffer)) {
          const message = error instanceof PanelError ? error.message : `Could not connect: ${briefly(error)}`;
          if (message !== target.problem) event(target, "error", { message });
          target.problem = message;
        }
      }
      c = channels.get(target.id);
    }
    if (!c) {
      if (!target.empty || target.pending.length) later(target, deps.retryMs ?? 1e3);
      return;
    }
    later(target, checkEveryMs);
    while (target.pending.length) {
      if (!await attached(c).catch(() => false)) return await reconnect(target, c);
      try {
        await host(c, "resume");
      } catch {
        return later(target, deps.retryMs ?? 1e3);
      }
      const text = target.pending.shift();
      event(target, "user_message", { text });
      try {
        await (await api()).session.prompt({ sessionID: c.sessionID, text });
      } catch (error) {
        event(target, "error", { message: `Message delivery could not be confirmed: ${briefly(error)}` });
      }
    }
  }
  async function handle(request2) {
    try {
      const params = request2.params ?? {};
      const id = request2.channel;
      const target = targets.get(id) ?? { id, pending: [] };
      const c = channels.get(id);
      if (request2.method === "close") {
        clearTimeout(target.retry);
        targets.delete(id);
        if (c) await close(c);
      } else {
        targets.set(id, target);
        if (request2.method === "list" && target.params) {
          await conversationList(target, String(target.params.directory));
        } else if (request2.method === "open" && target.params) {
          const sessions = await folderSessions(await api(), String(target.params.directory));
          const selected = sessions.find((s) => s.id === params.session_id);
          if (!selected) throw new PanelError("That conversation is not in this folder.");
          target.selected = selected.id;
          target.taken = false;
          target.fresh = false;
          target.pending = [];
          if (c?.sessionID !== selected.id) {
            event(target, "status", { state: "connecting" });
            if (c) await close(c);
            await reconcile(target);
          }
        } else if (request2.method === "connect" || request2.method === "new_session") {
          const fresh = request2.method === "new_session";
          const moved = target.params && folderKey(target.params.directory) !== folderKey(params.directory);
          if (moved) target.selected = void 0;
          if (!target.params) {
            if (typeof params.session_id === "string") target.selected = params.session_id;
            target.fresh = params.draft === true;
          }
          if (fresh || moved) {
            if (target.pending.length)
              event(target, "notice", { message: "Queued messages were not sent to the new conversation." });
            target.pending = [];
          }
          const previous = target.params;
          target.params = params;
          if (c && previous && !fresh && !moved && ["host", "port", "token", "registration", "script_handle"].every((key) => params[key] === previous[key])) {
            deps.send({ id: request2.id, result: {} });
            return;
          }
          if (fresh || moved) {
            target.selected = void 0;
            target.fresh = fresh;
            target.empty = false;
          } else if (target.empty) {
            target.empty = false;
          }
          target.taken = false;
          target.problem = void 0;
          event(target, "status", { state: "connecting" });
          if (c) await close(c);
          await reconcile(target);
        } else if (request2.method === "prompt") {
          target.pending.push(String(params.text ?? ""));
          if (target.params) await reconcile(target);
        } else if (request2.method === "interrupt") {
          target.pending = [];
          if (c) await act(c, request2.method, params);
        } else if (c) await act(c, request2.method, params);
      }
      deps.send({ id: request2.id, result: {} });
    } catch (error) {
      deps.send({
        channel: request2.channel,
        event: "error",
        data: {
          message: error instanceof PanelError ? error.message : `The panel action failed: ${briefly(error)}`
        }
      });
      deps.send({ id: request2.id, error: { message: "Panel action failed." } });
    }
  }
  return {
    dispatch: (request2) => serialize(request2.channel, () => handle(request2)),
    closeAll: async () => {
      stopping = true;
      for (const target of targets.values()) clearTimeout(target.retry);
      await Promise.allSettled(queues.values());
      await Promise.allSettled([...channels.values()].map(close));
    }
  };
}

// packages/integration-kit/src/panel-service.ts
var import_promises = require("node:fs/promises");
var import_node_http = require("node:http");
var import_node_os = require("node:os");
var import_node_path2 = require("node:path");
var import_node_stream = require("node:stream");
var agent = new import_node_http.Agent({ keepAlive: true, proxyEnv: {} });
function serviceURL(value) {
  if (!/^http:\/\/(?:127\.0\.0\.1|\[::1\])(?::\d+)?(?:\/|$)/.test(value))
    throw new Error("OpenCode service requires a literal loopback HTTP URL");
  const url = new URL(value);
  if (url.username || url.password || url.hash) throw new Error("Invalid OpenCode service URL");
  return url;
}
function serviceFetch(baseUrl) {
  const origin = serviceURL(baseUrl).origin;
  return async (input, init) => {
    const message = new Request(input, init);
    if (serviceURL(message.url).origin !== origin) throw new Error("OpenCode service origin changed");
    const body = message.body ? Buffer.from(await message.arrayBuffer()) : void 0;
    message.signal.throwIfAborted();
    return new Promise((resolve, reject) => {
      const req = (0, import_node_http.request)(
        message.url,
        {
          agent,
          method: message.method,
          headers: Object.fromEntries(message.headers),
          signal: message.signal
        },
        (response) => {
          const status = response.statusCode ?? 500;
          if (status >= 300 && status < 400) {
            response.resume();
            reject(new Error("OpenCode service redirect refused"));
            return;
          }
          const headers = new Headers();
          for (const [key, value] of Object.entries(response.headers)) {
            for (const item of Array.isArray(value) ? value : value === void 0 ? [] : [value])
              headers.append(key, item);
          }
          resolve(
            new Response(
              message.method === "HEAD" || [204, 205, 304].includes(status) ? null : import_node_stream.Readable.toWeb(response),
              { status, headers }
            )
          );
        }
      );
      req.on("error", reject);
      req.once("abort", () => reject(message.signal.reason ?? new Error("OpenCode request aborted")));
      req.end(body);
    });
  };
}
async function discoverService(file = (0, import_node_path2.join)(process.env.XDG_STATE_HOME ?? (0, import_node_path2.join)((0, import_node_os.homedir)(), ".local", "state"), "opencode", "service.json"), registrationFile) {
  try {
    if (registrationFile) {
      if (!/^service(?:-[A-Za-z0-9._-]{1,64})?\.json$/.test(registrationFile)) return void 0;
      file = (0, import_node_path2.join)((0, import_node_path2.dirname)(file), registrationFile);
    }
    const registration = JSON.parse(await (0, import_promises.readFile)(file, "utf8"));
    if (typeof registration.url !== "string" || !Number.isInteger(registration.pid) || registration.pid <= 0 || typeof registration.version !== "string" || !registration.version)
      return void 0;
    const fetch = serviceFetch(registration.url);
    const headers = {};
    if (typeof registration.password === "string")
      headers.authorization = `Basic ${Buffer.from(`opencode:${registration.password}`).toString("base64")}`;
    const response = await fetch(`${registration.url.replace(/\/$/, "")}/api/info`, {
      headers,
      signal: AbortSignal.timeout(3e3)
    });
    if (!response.ok) return void 0;
    const info = await response.json();
    if (info?.pid !== registration.pid || info?.version !== registration.version) return void 0;
    return { url: registration.url, headers, fetch };
  } catch {
    return void 0;
  }
}

// packages/integration-kit/src/panel-pipes.ts
function runPanel(config) {
  delete process.env.BUN_BE_BUN;
  const send = (value) => process.stdout.write(`${JSON.stringify(value)}
`);
  const panel = createPanel(config, {
    send,
    discover: async (registration) => {
      const endpoint = await discoverService(void 0, registration);
      return endpoint && exports_client.make({ baseUrl: endpoint.url, headers: endpoint.headers, fetch: endpoint.fetch });
    }
  });
  const input = import_node_readline.default.createInterface({ input: process.stdin, crlfDelay: Infinity });
  input.on("line", (line) => {
    if (!line.trim()) return;
    try {
      if (Buffer.byteLength(line) > 1024 * 1024) throw new Error("Request too large");
      const request2 = JSON.parse(line);
      if (!request2.id || !request2.channel || !request2.method) throw new Error("Invalid request");
      void panel.dispatch(request2);
    } catch {
      send({ error: { message: "Invalid panel request." } });
    }
  });
  input.on("close", () => {
    void panel.closeAll().finally(() => process.exit(0));
  });
}

// integrations/houdini/plugin/src/sidecar.ts
runPanel({ app: "Houdini", rpcID: "neuralnomads.houdini", document: "file", duplicateOffer: "Houdini instances" });
