"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// integrations/godot/plugin/src/sidecar.ts
var import_node_readline = __toESM(require("node:readline"), 1);

// node_modules/@opencode/client/dist/chunks/rpc-runtime-9rqn6x4v.js
var __defProp2 = Object.defineProperty;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp2(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};

// node_modules/@opencode/client/dist/chunks/rpc-runtime-gecjxyvt.js
var exports_shared_events = {};
__export(exports_shared_events, {
  SharedEvents: () => exports_shared_events,
  make: () => make7
});
function make7(connect) {
  let current;
  const capacity = 4096;
  function stop(connection) {
    connection.connected = void 0;
    connection.controller.abort();
    if (current === connection)
      current = void 0;
  }
  async function run(connection) {
    let iterator;
    let completion = {};
    try {
      if (connection.controller.signal.aborted)
        return;
      iterator = connect(connection.controller.signal, () => {
        connection.subscribers.forEach((subscriber) => subscriber.activity?.());
      })[Symbol.asyncIterator]();
      while (!connection.controller.signal.aborted) {
        const item = await iterator.next();
        if (item.done || connection.controller.signal.aborted)
          break;
        if (item.value.type === "server.connected")
          connection.connected = item.value;
        connection.subscribers.forEach((subscriber) => subscriber.push(item.value));
      }
    } catch (error) {
      completion = { error };
    } finally {
      stop(connection);
      try {
        await iterator?.return?.();
      } catch (error) {
        if (!("error" in completion))
          completion = { error };
      }
      connection.subscribers.forEach((subscriber) => subscriber.finish(completion));
    }
  }
  return {
    subscribe(options) {
      return {
        [Symbol.asyncIterator]() {
          const pending = [];
          const queued = [];
          let started = false;
          let completion;
          let connection;
          const types = options?.types?.length ? new Set(options.types) : void 0;
          const selected = (value) => !types || value.type === "server.connected" || types.has(value.type);
          function finish(result, discard = true) {
            completion = result;
            if (discard)
              queued.length = 0;
            options?.signal?.removeEventListener("abort", abort);
            if (connection?.subscribers.delete(subscriber) && !connection.subscribers.size)
              stop(connection);
            pending.splice(0).forEach((request2) => {
              if ("error" in result)
                request2.reject(result.error);
              else
                request2.resolve({ done: true, value: void 0 });
            });
          }
          function abort() {
            finish({});
          }
          const subscriber = {
            activity: options?.onActivity,
            finish(result) {
              finish(result, false);
            },
            push(value) {
              if (completion)
                return;
              if (!selected(value))
                return;
              const request2 = pending.shift();
              if (request2) {
                request2.resolve({ done: false, value });
                return;
              }
              if (queued.length === capacity) {
                finish({ error: new Error(`Event subscriber exceeded its ${capacity}-event capacity`) });
                return;
              }
              queued.push(value);
            }
          };
          function start() {
            if (completion)
              return;
            const fresh = !current;
            connection = current ?? {
              controller: new AbortController(),
              subscribers: /* @__PURE__ */ new Set()
            };
            current = connection;
            connection.subscribers.add(subscriber);
            if (connection.connected)
              subscriber.push(connection.connected);
            if (fresh)
              run(connection);
          }
          return {
            next() {
              const value = queued.shift();
              if (value)
                return Promise.resolve({ done: false, value });
              if (completion) {
                if ("error" in completion)
                  return Promise.reject(completion.error);
                return Promise.resolve({ done: true, value: void 0 });
              }
              if (options?.signal?.aborted) {
                abort();
                return Promise.resolve({ done: true, value: void 0 });
              }
              const request2 = Promise.withResolvers();
              pending.push(request2);
              if (!started) {
                started = true;
                options?.signal?.addEventListener("abort", abort, { once: true });
                start();
              }
              return request2.promise;
            },
            return() {
              finish({});
              return Promise.resolve({ done: true, value: void 0 });
            }
          };
        }
      };
    }
  };
}

// node_modules/@opencode/client/dist/chunks/rpc-runtime-js54wxgp.js
var ClientError2 = class extends Error {
  reason;
  name = "ClientError";
  constructor(reason, options) {
    const detail = options?.detail ?? (options?.cause instanceof Error ? options.cause.message : void 0);
    super(detail ? `${reason}: ${detail}` : reason, options);
    this.reason = reason;
  }
};

// node_modules/@opencode/client/dist/chunks/rpc-runtime-t2ajednw.js
var exports_client2 = {};
__export(exports_client2, {
  make: () => make3
});
var maxSseEventBytes = 16 * 1024 * 1024;
function make3(options) {
  const fetch = options.fetch ?? globalThis.fetch;
  const prepare = (descriptor, requestOptions) => {
    const baseUrl = new URL(options.baseUrl);
    if (!baseUrl.pathname.endsWith("/"))
      baseUrl.pathname += "/";
    const url = new URL(descriptor.path.slice(1), baseUrl);
    for (const [key, value] of Object.entries(descriptor.query ?? {}))
      appendQuery(url.searchParams, key, value);
    const headers = new Headers(options.headers);
    for (const [key, value] of Object.entries(descriptor.headers ?? {})) {
      if (value !== void 0 && value !== null)
        headers.set(key, String(value));
    }
    for (const [key, value] of new Headers(requestOptions?.headers))
      headers.set(key, value);
    if (descriptor.body !== void 0 && !headers.has("content-type"))
      headers.set("content-type", descriptor.binaryBody ? "application/octet-stream" : "application/json");
    return {
      url,
      init: {
        method: descriptor.method,
        signal: requestOptions?.signal,
        headers,
        body: descriptor.body === void 0 ? void 0 : descriptor.binaryBody ? descriptor.body : JSON.stringify(descriptor.body)
      }
    };
  };
  const execute = async (descriptor, requestOptions) => {
    try {
      const prepared = prepare(descriptor, requestOptions);
      return await fetch(prepared.url, prepared.init);
    } catch (cause) {
      throw new ClientError2("Transport", { cause });
    }
  };
  const responseError = async (response, descriptor) => {
    if (descriptor.declaredStatuses.includes(response.status))
      throw declared(await json(response));
    try {
      await response.body?.cancel();
    } catch {
    }
    throw new ClientError2("UnexpectedStatus", { cause: { status: response.status }, detail: String(response.status) });
  };
  const request2 = async (descriptor, requestOptions) => {
    const response = await execute(descriptor, requestOptions);
    if (response.status !== descriptor.successStatus)
      return responseError(response, descriptor);
    if (descriptor.binary)
      return new Uint8Array(await response.arrayBuffer());
    if (descriptor.empty) {
      try {
        await response.body?.cancel();
      } catch {
      }
      return;
    }
    return await json(response);
  };
  const sse = (descriptor, requestOptions) => ({
    async *[Symbol.asyncIterator]() {
      const response = await execute(descriptor, requestOptions);
      if (response.status !== descriptor.successStatus)
        await responseError(response, descriptor);
      if (!isContentType(response, "text/event-stream")) {
        try {
          await response.body?.cancel();
        } catch {
        }
        throw new ClientError2("UnsupportedContentType", { detail: response.headers.get("content-type") });
      }
      if (response.body === null)
        throw new ClientError2("MalformedResponse");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      try {
        while (true) {
          let next;
          try {
            next = await reader.read();
          } catch (cause) {
            throw new ClientError2("Transport", { cause });
          }
          if (!next.done)
            requestOptions?.onActivity?.();
          buffer += decoder.decode(next.value, { stream: !next.done });
          if (buffer.length > maxSseEventBytes)
            throw new ClientError2("SseEventTooLarge");
          const trailingCarriageReturn = !next.done && buffer.endsWith("\r");
          if (trailingCarriageReturn)
            buffer = buffer.slice(0, -1);
          buffer = buffer.replaceAll(`\r
`, `
`).replaceAll("\r", `
`);
          if (trailingCarriageReturn)
            buffer += "\r";
          if (next.done && buffer !== "")
            buffer += `

`;
          let boundary = buffer.indexOf(`

`);
          while (boundary >= 0) {
            const block = buffer.slice(0, boundary);
            buffer = buffer.slice(boundary + 2);
            const data = block.split(`
`).flatMap((line) => line.startsWith("data:") ? [line.slice(5).trimStart()] : []).join(`
`);
            if (data !== "") {
              try {
                yield JSON.parse(data);
              } catch (cause) {
                throw new ClientError2("MalformedResponse", { cause });
              }
            }
            boundary = buffer.indexOf(`

`);
          }
          if (next.done)
            return;
        }
      } finally {
        try {
          await reader.cancel();
        } catch {
        }
        reader.releaseLock();
      }
    }
  });
  const client = {
    server: {
      info: (requestOptions) => request2({ method: "GET", path: `/api/info`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions),
      pair: (requestOptions) => request2({ method: "POST", path: `/api/pair`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions),
      connect: (input2, requestOptions) => request2({
        method: "GET",
        path: `/auth/connect/${encodeURIComponent(input2.code)}`,
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions)
    },
    location: {
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/location`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      reload: (requestOptions) => request2({
        method: "POST",
        path: `/api/location/reload`,
        successStatus: 204,
        declaredStatuses: [400, 401, 503],
        empty: true
      }, requestOptions)
    },
    agent: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/agent`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/agent/${encodeURIComponent(input2.agentID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    plugin: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/plugin`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      gui: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/plugin/gui`,
        query: { location: input2["location"], id: input2["id"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      check: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/plugin/check`,
        query: { location: input2?.["location"] },
        body: { target: input2?.["target"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      update: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/plugin/update`,
        query: { location: input2["location"] },
        body: { targets: input2["targets"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 503],
        empty: true
      }, requestOptions)
    },
    session: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session`,
        query: {
          limit: input2?.["limit"],
          order: input2?.["order"],
          search: input2?.["search"],
          parentID: input2?.["parentID"],
          archived: input2?.["archived"],
          directory: input2?.["directory"],
          project: input2?.["project"],
          subpath: input2?.["subpath"],
          cursor: input2?.["cursor"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session`,
        body: {
          id: input2?.["id"],
          parentID: input2?.["parentID"],
          title: input2?.["title"],
          agent: input2?.["agent"],
          model: input2?.["model"],
          location: input2?.["location"],
          metadata: input2?.["metadata"],
          permissions: input2?.["permissions"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      active: (requestOptions) => request2({
        method: "GET",
        path: `/api/session/active`,
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions).then((value) => value.data),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      remove: (input2, requestOptions) => request2({
        method: "DELETE",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}`,
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      fork: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/fork`,
        body: { before: input2["before"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      switchAgent: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/agent`,
        body: { agent: input2["agent"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      switchModel: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/model`,
        body: { model: input2["model"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      update: (input2, requestOptions) => request2({
        method: "PATCH",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}`,
        body: {
          title: input2["title"],
          metadata: input2["metadata"],
          permissions: input2["permissions"],
          archived: input2["archived"]
        },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      move: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/move`,
        body: { directory: input2["directory"], delivery: input2["delivery"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      prompt: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/prompt`,
        body: {
          id: input2["id"],
          text: input2["text"],
          files: input2["files"],
          agents: input2["agents"],
          skills: input2["skills"],
          metadata: input2["metadata"],
          delivery: input2["delivery"],
          resume: input2["resume"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      command: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/command`,
        body: {
          name: input2["name"],
          text: input2["text"],
          files: input2["files"],
          agents: input2["agents"],
          skills: input2["skills"],
          delivery: input2["delivery"]
        },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 500],
        empty: true
      }, requestOptions),
      synthetic: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/synthetic`,
        body: {
          id: input2["id"],
          text: input2["text"],
          description: input2["description"],
          metadata: input2["metadata"],
          delivery: input2["delivery"],
          resume: input2["resume"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      shell: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/shell`,
        body: { id: input2["id"], command: input2["command"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      compact: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/compact`,
        body: { id: input2["id"], delivery: input2["delivery"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      revert: {
        stage: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/revert/stage`,
          body: { messageID: input2["messageID"], files: input2["files"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409, 500],
          empty: false
        }, requestOptions).then((value) => value.data),
        clear: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/revert`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409, 500],
          empty: true
        }, requestOptions),
        commit: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/revert/commit`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      context: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/context`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions).then((value) => value.data),
      diff: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/diff`,
        query: { from: input2["from"], to: input2["to"], context: input2["context"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions).then((value) => value.data),
      inbox: {
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/inbox`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        cancel: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/inbox/${encodeURIComponent(input2.inboxID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        update: (input2, requestOptions) => request2({
          method: "PATCH",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/inbox/${encodeURIComponent(input2.inboxID)}`,
          body: { delivery: input2["delivery"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      generate: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/generate`,
        body: { prompt: input2["prompt"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions).then((value) => value.data),
      interrupt: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/interrupt`,
        query: { resume: input2["resume"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      background: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/background`,
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      message: {
        get: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/message/${encodeURIComponent(input2.messageID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      form: {
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        create: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form`,
          body: { id: input2["id"], title: input2["title"], metadata: input2["metadata"], fields: input2["fields"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        get: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form/${encodeURIComponent(input2.formID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        reply: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form/${encodeURIComponent(input2.formID)}/reply`,
          body: { answer: input2["answer"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions),
        cancel: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/session/${encodeURIComponent(input2.sessionID)}/form/${encodeURIComponent(input2.formID)}`,
          query: { message: input2["message"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 409],
          empty: true
        }, requestOptions)
      },
      environment: (input2, requestOptions) => request2({
        method: "PUT",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/environment`,
        body: { variables: input2["variables"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      view: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/view`,
        body: { idle: input2["idle"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    experimental: {
      session: {
        stats: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/stats`,
          query: {
            from: input2?.["from"],
            to: input2?.["to"],
            project: input2?.["project"],
            timezone: input2?.["timezone"],
            tools: input2?.["tools"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401],
          empty: false
        }, requestOptions).then((value) => value.data),
        import: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/import`,
          body: { info: input2["info"], messages: input2["messages"], location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        export: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/export`,
          query: { sanitize: input2["sanitize"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 500],
          empty: false
        }, requestOptions).then((value) => value.data),
        skill: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/skill`,
          body: { id: input2["id"], resume: input2["resume"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        wait: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/wait`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        instructions: {
          entry: {
            list: (input2, requestOptions) => request2({
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/instructions/entries`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false
            }, requestOptions).then((value) => value.data),
            put: (input2, requestOptions) => request2({
              method: "PUT",
              path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/instructions/entries/${encodeURIComponent(input2.key)}`,
              body: { value: input2["value"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 413],
              empty: true
            }, requestOptions),
            remove: (input2, requestOptions) => request2({
              method: "DELETE",
              path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/instructions/entries/${encodeURIComponent(input2.key)}`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true
            }, requestOptions)
          }
        },
        log: (input2, requestOptions) => sse({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/log`,
          query: { after: input2["after"], follow: input2["follow"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      generate: {
        text: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/generate/text`,
          body: { prompt: input2["prompt"], model: input2["model"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        image: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/generate/image`,
          body: {
            model: input2["model"],
            prompt: input2["prompt"],
            images: input2["images"],
            n: input2["n"],
            aspect: input2["aspect"],
            resolution: input2["resolution"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        decisions: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/generate/decisions`,
          body: { model: input2["model"], input: input2["input"], questions: input2["questions"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 422, 502, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      voice: {
        models: (requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/voice/models`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        session: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/voice/session`,
          body: { model: input2["model"], session: input2["session"], transport: input2["transport"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      integration: {
        wellknown: {
          add: (input2, requestOptions) => request2({
            method: "POST",
            path: `/api/experimental/integration/wellknown`,
            query: { location: input2["location"] },
            body: { url: input2["url"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true
          }, requestOptions)
        }
      },
      mcp: {
        add: (input2, requestOptions) => request2({
          method: "PUT",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}`,
          query: { location: input2["location"] },
          body: { config: input2["config"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        remove: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        connect: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}/connect`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        disconnect: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/mcp/${encodeURIComponent(input2.server)}/disconnect`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        client: {
          token: (input2, requestOptions) => request2({
            method: "POST",
            path: `/api/experimental/client-mcp/token`,
            query: { location: input2["location"], name: input2["name"] },
            headers: { "x-opencode-ticket": input2["x-opencode-ticket"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 403, 404],
            empty: false
          }, requestOptions)
        }
      },
      file: {
        write: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/fs/write`,
          query: { location: input2["location"], path: input2["path"] },
          body: input2["payload"],
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false,
          binaryBody: true
        }, requestOptions),
        watch: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/fs/watch`,
          query: { location: input2["location"] },
          body: { path: input2["path"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        unwatch: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/fs/watch`,
          query: { location: input2["location"] },
          body: { path: input2["path"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      persistentPty: {
        read: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/terminal/read`,
          query: { lines: input2["lines"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/terminal`,
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        create: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/session/${encodeURIComponent(input2.sessionID)}/terminal`,
          body: {
            command: input2["command"],
            args: input2["args"],
            cwd: input2["cwd"],
            title: input2["title"],
            env: input2["env"],
            size: input2["size"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        shutdown: (requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/persistent-pty/shutdown`,
          successStatus: 204,
          declaredStatuses: [400, 401, 503],
          empty: true
        }, requestOptions),
        handoff: (requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/persistent-pty/handoff`,
          successStatus: 200,
          declaredStatuses: [400, 401, 503],
          empty: false
        }, requestOptions),
        get: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        update: (input2, requestOptions) => request2({
          method: "PUT",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}`,
          body: { attachmentID: input2["attachmentID"], size: input2["size"], title: input2["title"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 501, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        snapshot: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}/snapshot`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data),
        remove: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 404, 503],
          empty: true
        }, requestOptions),
        connectToken: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/persistent-pty/${encodeURIComponent(input2.ptyID)}/connect-token`,
          headers: { "x-opencode-ticket": input2["x-opencode-ticket"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions).then((value) => value.data)
      },
      media: {
        get: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/media/${encodeURIComponent(input2.hash)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false,
          binary: true
        }, requestOptions)
      },
      schedule: {
        create: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/schedule`,
          body: {
            sessionID: input2["sessionID"],
            name: input2["name"],
            when: input2["when"],
            if: input2["if"],
            until: input2["until"],
            ends: input2["ends"],
            prompt: input2["prompt"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/schedule`,
          query: { sessionID: input2["sessionID"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        get: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        pause: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}/pause`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        resume: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}/resume`,
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        delete: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/schedule/${encodeURIComponent(input2.scheduleID)}`,
          successStatus: 204,
          declaredStatuses: [400, 401, 403, 404],
          empty: true
        }, requestOptions)
      },
      artifacts: {
        providers: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts/providers`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts`,
          query: { location: input2?.["location"], sessionID: input2?.["sessionID"], provider: input2?.["provider"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        create: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/experimental/artifacts`,
          query: { location: input2["location"] },
          body: {
            title: input2["title"],
            files: input2["files"],
            entry: input2["entry"],
            provider: input2["provider"],
            sessionID: input2["sessionID"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        get: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        update: (input2, requestOptions) => request2({
          method: "PATCH",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}`,
          query: { location: input2["location"] },
          body: {
            title: input2["title"],
            files: input2["files"],
            entry: input2["entry"],
            sessionID: input2["sessionID"]
          },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false
        }, requestOptions),
        delete: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: true
        }, requestOptions),
        view: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/artifacts/${encodeURIComponent(input2.artifactID)}/view/${encodePath(input2.path)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404, 503],
          empty: false,
          binary: true
        }, requestOptions)
      },
      migration: {
        v1: {
          status: (requestOptions) => request2({
            method: "GET",
            path: `/api/experimental/migration/v1`,
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false
          }, requestOptions)
        }
      },
      usage: {
        limits: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/experimental/usage/limits`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 503],
          empty: false
        }, requestOptions)
      },
      config: {
        update: (input2, requestOptions) => request2({
          method: "PATCH",
          path: `/api/experimental/config`,
          body: { shell: input2["shell"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      }
    },
    message: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/message`,
        query: { limit: input2["limit"], order: input2["order"], cursor: input2["cursor"], type: input2["type"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions)
    },
    model: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/model`,
        query: { location: input2?.["location"], types: input2?.["types"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      default: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/model/default`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    provider: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/provider`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/provider/${encodeURIComponent(input2.providerID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    integration: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/integration`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/integration/${encodeURIComponent(input2.integrationID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      connect: {
        key: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/key`,
          query: { location: input2["location"] },
          body: { key: input2["key"], answer: input2["answer"], label: input2["label"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        external: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/external`,
          query: { location: input2["location"] },
          body: { methodID: input2["methodID"], answer: input2["answer"], label: input2["label"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      oauth: {
        connect: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth`,
          query: { location: input2["location"] },
          body: { methodID: input2["methodID"], answer: input2["answer"], label: input2["label"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        status: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        complete: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth/${encodeURIComponent(input2.attemptID)}/complete`,
          query: { location: input2["location"] },
          body: { code: input2["code"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions),
        cancel: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/oauth/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      },
      command: {
        connect: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/command`,
          query: { location: input2["location"] },
          body: { methodID: input2["methodID"], label: input2["label"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        status: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/command/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions),
        cancel: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/integration/${encodeURIComponent(input2.integrationID)}/connect/command/${encodeURIComponent(input2.attemptID)}`,
          query: { location: input2["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401, 404],
          empty: true
        }, requestOptions)
      }
    },
    mcp: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/mcp`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      resource: {
        catalog: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/mcp/resource`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      }
    },
    credential: {
      list: (requestOptions) => request2({ method: "GET", path: `/api/credential`, successStatus: 200, declaredStatuses: [400, 401], empty: false }, requestOptions).then((value) => value.data),
      create: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/credential`,
        body: {
          id: input2["id"],
          integrationID: input2["integrationID"],
          label: input2["label"],
          value: input2["value"],
          activate: input2["activate"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 409],
        empty: false
      }, requestOptions).then((value) => value.data),
      update: (input2, requestOptions) => request2({
        method: "PATCH",
        path: `/api/credential/${encodeURIComponent(input2.credentialID)}`,
        body: { label: input2["label"] },
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions),
      activate: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/credential/${encodeURIComponent(input2.credentialID)}/activate`,
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions),
      remove: (input2, requestOptions) => request2({
        method: "DELETE",
        path: `/api/credential/${encodeURIComponent(input2.credentialID)}`,
        successStatus: 204,
        declaredStatuses: [400, 401],
        empty: true
      }, requestOptions)
    },
    project: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/project`,
        query: { archived: input2?.["archived"] },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions),
      update: (input2, requestOptions) => request2({
        method: "PATCH",
        path: `/api/project/${encodeURIComponent(input2.projectID)}`,
        body: {
          canonical: input2["canonical"],
          name: input2["name"],
          icon: input2["icon"],
          commands: input2["commands"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    form: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/form`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    permission: {
      request: {
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/permission/request`,
          query: { location: input2?.["location"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      saved: {
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/permission/saved`,
          query: { projectID: input2?.["projectID"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions).then((value) => value.data),
        update: (input2, requestOptions) => request2({
          method: "PATCH",
          path: `/api/permission/saved/${encodeURIComponent(input2.id)}`,
          body: { action: input2["action"], resource: input2["resource"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404, 409],
          empty: false
        }, requestOptions).then((value) => value.data),
        remove: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/permission/saved/${encodeURIComponent(input2.id)}`,
          successStatus: 204,
          declaredStatuses: [400, 401],
          empty: true
        }, requestOptions)
      },
      create: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission`,
        body: {
          id: input2["id"],
          action: input2["action"],
          resources: input2["resources"],
          save: input2["save"],
          metadata: input2["metadata"],
          source: input2["source"],
          agent: input2["agent"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission/${encodeURIComponent(input2.requestID)}`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions).then((value) => value.data),
      reply: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/session/${encodeURIComponent(input2.sessionID)}/permission/${encodeURIComponent(input2.requestID)}/reply`,
        body: { decision: input2["decision"], message: input2["message"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    file: {
      read: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/fs/read/${encodePath(input2.path)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false,
        binary: true
      }, requestOptions),
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/fs/list`,
        query: { location: input2?.["location"], path: input2?.["path"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      find: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/fs/find`,
        query: { location: input2["location"], query: input2["query"], type: input2["type"], limit: input2["limit"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    command: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/command`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    skill: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/skill`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    rpc: {
      call: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/rpc/${encodeURIComponent(input2.rpcID)}/${encodeURIComponent(input2.method)}`,
        query: { location: input2["location"] },
        body: { input: input2["input"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 500],
        empty: false
      }, requestOptions)
    },
    event: {
      subscribe: (input2, requestOptions) => sse({
        method: "GET",
        path: `/api/event`,
        query: { types: input2?.["types"] },
        successStatus: 200,
        declaredStatuses: [400, 401],
        empty: false
      }, requestOptions)
    },
    pty: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/pty`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/pty`,
        query: { location: input2?.["location"] },
        body: {
          command: input2?.["command"],
          args: input2?.["args"],
          cwd: input2?.["cwd"],
          title: input2?.["title"],
          env: input2?.["env"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/pty/${encodeURIComponent(input2.ptyID)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      update: (input2, requestOptions) => request2({
        method: "PUT",
        path: `/api/pty/${encodeURIComponent(input2.ptyID)}`,
        query: { location: input2["location"] },
        body: { title: input2["title"], size: input2["size"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input2, requestOptions) => request2({
        method: "DELETE",
        path: `/api/pty/${encodeURIComponent(input2.ptyID)}`,
        query: { location: input2["location"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      connect: {
        token: (input2, requestOptions) => request2({
          method: "POST",
          path: `/api/pty/${encodeURIComponent(input2.ptyID)}/connect-token`,
          query: { location: input2["location"] },
          headers: { "x-opencode-ticket": input2["x-opencode-ticket"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 403, 404],
          empty: false
        }, requestOptions)
      }
    },
    shell: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/shell`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/shell`,
        query: { location: input2["location"] },
        body: {
          command: input2["command"],
          cwd: input2["cwd"],
          timeout: input2["timeout"],
          metadata: input2["metadata"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/shell/${encodeURIComponent(input2.id)}`,
        query: { location: input2["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      output: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/shell/${encodeURIComponent(input2.id)}/output`,
        query: { location: input2["location"], cursor: input2["cursor"], limit: input2["limit"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input2, requestOptions) => request2({
        method: "DELETE",
        path: `/api/shell/${encodeURIComponent(input2.id)}`,
        query: { location: input2["location"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    reference: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/reference`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    },
    worktree: {
      list: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/worktree`,
        query: { projectID: input2["projectID"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      create: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/worktree`,
        body: {
          projectID: input2["projectID"],
          from: input2["from"],
          branch: input2["branch"],
          directory: input2["directory"],
          name: input2["name"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      remove: (input2, requestOptions) => request2({
        method: "DELETE",
        path: `/api/worktree`,
        body: { projectID: input2["projectID"], directory: input2["directory"], force: input2["force"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions),
      refresh: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/worktree/refresh`,
        body: { projectID: input2["projectID"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404],
        empty: true
      }, requestOptions)
    },
    vcs: {
      init: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/vcs/init`,
        query: { location: input2?.["location"], provider: input2?.["provider"] },
        successStatus: 204,
        declaredStatuses: [400, 401, 404, 409, 501, 503],
        empty: true
      }, requestOptions),
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      base: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs/base`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      status: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs/status`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      branch: {
        list: (input2, requestOptions) => request2({
          method: "GET",
          path: `/api/vcs/branch`,
          query: { location: input2?.["location"], search: input2?.["search"], limit: input2?.["limit"] },
          successStatus: 200,
          declaredStatuses: [400, 401, 404],
          empty: false
        }, requestOptions)
      },
      diff: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/vcs/diff`,
        query: {
          location: input2["location"],
          mode: input2["mode"],
          base: input2["base"],
          context: input2["context"],
          untracked: input2["untracked"]
        },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    debug: {
      heapDump: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/debug/heap-dump`,
        query: { directory: input2?.["directory"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 500],
        empty: false
      }, requestOptions),
      location: {
        list: (requestOptions) => request2({
          method: "GET",
          path: `/api/debug/location`,
          successStatus: 200,
          declaredStatuses: [400, 401],
          empty: false
        }, requestOptions),
        evict: (input2, requestOptions) => request2({
          method: "DELETE",
          path: `/api/debug/location`,
          query: { location: input2?.["location"] },
          successStatus: 204,
          declaredStatuses: [400, 401],
          empty: true
        }, requestOptions)
      }
    },
    websearch: {
      providers: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/websearch/provider`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions),
      query: (input2, requestOptions) => request2({
        method: "POST",
        path: `/api/websearch`,
        query: { location: input2["location"] },
        body: { query: input2["query"], providerID: input2["providerID"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404, 503],
        empty: false
      }, requestOptions)
    },
    config: {
      get: (input2, requestOptions) => request2({
        method: "GET",
        path: `/api/config`,
        query: { location: input2?.["location"] },
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions),
      shells: (requestOptions) => request2({
        method: "GET",
        path: `/api/config/shell`,
        successStatus: 200,
        declaredStatuses: [400, 401, 404],
        empty: false
      }, requestOptions)
    }
  };
  return {
    ...client,
    session: {
      ...client.session,
      stats: client.experimental.session.stats,
      import: client.experimental.session.import,
      export: client.experimental.session.export,
      skill: client.experimental.session.skill,
      wait: client.experimental.session.wait,
      instructions: {
        entry: {
          list: client.experimental.session.instructions.entry.list,
          put: client.experimental.session.instructions.entry.put,
          remove: client.experimental.session.instructions.entry.remove
        }
      },
      log: client.experimental.session.log
    },
    generate: {
      text: client.experimental.generate.text,
      image: client.experimental.generate.image,
      decisions: client.experimental.generate.decisions
    },
    voice: {
      models: client.experimental.voice.models,
      session: client.experimental.voice.session
    },
    integration: {
      ...client.integration,
      wellknown: {
        add: client.experimental.integration.wellknown.add
      }
    },
    mcp: {
      ...client.mcp,
      add: client.experimental.mcp.add,
      remove: client.experimental.mcp.remove,
      connect: client.experimental.mcp.connect,
      disconnect: client.experimental.mcp.disconnect,
      client: {
        token: client.experimental.mcp.client.token
      }
    },
    file: {
      ...client.file,
      write: client.experimental.file.write,
      watch: client.experimental.file.watch,
      unwatch: client.experimental.file.unwatch
    },
    migration: {
      v1: {
        status: client.experimental.migration.v1.status
      }
    },
    usage: {
      limits: client.experimental.usage.limits
    },
    config: {
      ...client.config,
      update: client.experimental.config.update
    }
  };
}
function encodePath(value) {
  return value.split("/").map(encodeURIComponent).join("/");
}
function appendQuery(params, key, value) {
  if (value === void 0)
    return;
  if (value === null) {
    params.append(key, "null");
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value)
      appendQuery(params, key, item);
    return;
  }
  if (typeof value === "object") {
    for (const [child, item] of Object.entries(value))
      appendQuery(params, `${key}[${child}]`, item);
    return;
  }
  params.append(key, String(value));
}
async function json(response) {
  if (!isContentType(response, "application/json") && !response.headers.get("content-type")?.includes("+json")) {
    try {
      await response.body?.cancel();
    } catch {
    }
    throw new ClientError2("UnsupportedContentType", { detail: response.headers.get("content-type") });
  }
  let text;
  try {
    text = await response.text();
  } catch (cause) {
    throw new ClientError2("Transport", { cause });
  }
  if (text === "")
    throw new ClientError2("MalformedResponse");
  try {
    return JSON.parse(text);
  } catch (cause) {
    throw new ClientError2("MalformedResponse", { cause });
  }
}
function declared(body) {
  const error = Object.assign(new Error(body.message ?? body.data?.message), body);
  if (body._tag)
    error.name = body._tag;
  return error;
}
function isContentType(response, expected) {
  return response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() === expected;
}

// node_modules/@opencode/client/dist/chunks/rpc-runtime-sdjh9vmn.js
var isRpcError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "RpcError";
var isRpcInternalError2 = (value) => typeof value === "object" && value !== null && "_tag" in value && value["_tag"] === "RpcInternalError";

// node_modules/@opencode/client/dist/chunks/rpc-runtime-xqwq6bgr.js
function makeRpc2(raw, events) {
  return (definition) => {
    const subscribe = (name, options) => {
      if (!Object.hasOwn(definition.events, name))
        throw new Error(`Unknown RPC event: ${definition.id}.${name}`);
      const type = eventType(definition, name);
      return {
        [Symbol.asyncIterator]() {
          const controller = new AbortController();
          const signal = options?.signal ? AbortSignal.any([controller.signal, options.signal]) : controller.signal;
          const iterator = (async function* () {
            try {
              for await (const published of events.subscribe({ signal })) {
                if (signal.aborted)
                  return;
                if (published.type !== type)
                  continue;
                yield published;
              }
            } catch (error) {
              if (!signal.aborted)
                throw error;
            } finally {
              controller.abort();
            }
          })();
          return {
            next: () => iterator.next(),
            return: () => {
              controller.abort();
              return iterator.return();
            }
          };
        }
      };
    };
    return Object.assign(Object.fromEntries(Object.keys(definition.methods).map((name) => [
      name,
      async (input2, options) => {
        try {
          const result = await raw.rpc.call({
            rpcID: definition.id,
            method: name,
            input: input2,
            location: options?.location
          }, { signal: options?.signal, headers: options?.headers });
          return result.output;
        } catch (error) {
          if (!isRpcError2(error) && !isRpcInternalError2(error))
            throw error;
          throw error.data === void 0 ? { type: error.type, message: error.message } : { type: error.type, message: error.message, data: error.data };
        }
      }
    ])), {
      events: {
        subscribe,
        on: (name, handler, options) => {
          const controller = new AbortController();
          const signal = options?.signal ? AbortSignal.any([controller.signal, options.signal]) : controller.signal;
          const source = subscribe(name, { signal });
          (async () => {
            for await (const event of source)
              await handler(event);
          })().catch((error) => console.error(error));
          return () => controller.abort();
        }
      }
    });
  };
}
function eventType(definition, name) {
  return `rpc.${definition.id}.${name}`;
}

// node_modules/@opencode/client/dist/chunks/rpc-runtime-wbnz2gjn.js
var exports_client = {};
__export(exports_client, {
  OpenCode: () => exports_client,
  make: () => make2
});
function make2(options) {
  const raw = make3(options);
  const events = make7((signal, onActivity) => raw.event.subscribe(void 0, { signal, onActivity }));
  return {
    ...raw,
    rpc: Object.assign(makeRpc2(raw, events), raw.rpc),
    event: events
  };
}

// integrations/godot/plugin/src/service.ts
var import_promises = require("node:fs/promises");
var import_node_http = require("node:http");
var import_node_os = require("node:os");
var import_node_path = require("node:path");
var import_node_stream = require("node:stream");
var agent = new import_node_http.Agent({ keepAlive: true, proxyEnv: {} });
function serviceURL(value) {
  if (!/^http:\/\/(?:127\.0\.0\.1|\[::1\])(?::\d+)?(?:\/|$)/.test(value))
    throw new Error("OpenCode service requires a literal loopback HTTP URL");
  const url = new URL(value);
  if (url.username || url.password || url.hash) throw new Error("Invalid OpenCode service URL");
  return url;
}
function serviceFetch(baseUrl) {
  const origin = serviceURL(baseUrl).origin;
  return async (input2, init) => {
    const message = new Request(input2, init);
    if (serviceURL(message.url).origin !== origin) throw new Error("OpenCode service origin changed");
    const body = message.body ? Buffer.from(await message.arrayBuffer()) : void 0;
    message.signal.throwIfAborted();
    return new Promise((resolve, reject) => {
      const req = (0, import_node_http.request)(
        message.url,
        {
          agent,
          method: message.method,
          headers: Object.fromEntries(message.headers),
          signal: message.signal
        },
        (response) => {
          const status = response.statusCode ?? 500;
          if (status >= 300 && status < 400) {
            response.resume();
            reject(new Error("OpenCode service redirect refused"));
            return;
          }
          const headers = new Headers();
          for (const [key, value] of Object.entries(response.headers)) {
            for (const item of Array.isArray(value) ? value : value === void 0 ? [] : [value])
              headers.append(key, item);
          }
          resolve(
            new Response(
              message.method === "HEAD" || [204, 205, 304].includes(status) ? null : import_node_stream.Readable.toWeb(response),
              { status, headers }
            )
          );
        }
      );
      req.on("error", reject);
      req.once("abort", () => reject(message.signal.reason ?? new Error("OpenCode request aborted")));
      req.end(body);
    });
  };
}
async function discoverService(file = (0, import_node_path.join)(process.env.XDG_STATE_HOME ?? (0, import_node_path.join)((0, import_node_os.homedir)(), ".local", "state"), "opencode", "service.json")) {
  try {
    const registration = JSON.parse(await (0, import_promises.readFile)(file, "utf8"));
    if (typeof registration.url !== "string" || !Number.isInteger(registration.pid) || registration.pid <= 0 || typeof registration.version !== "string" || !registration.version)
      return void 0;
    const fetch = serviceFetch(registration.url);
    const headers = {};
    if (typeof registration.password === "string")
      headers.authorization = `Basic ${Buffer.from(`opencode:${registration.password}`).toString("base64")}`;
    const response = await fetch(`${registration.url.replace(/\/$/, "")}/api/info`, {
      headers,
      signal: AbortSignal.timeout(3e3)
    });
    if (!response.ok) return void 0;
    const info = await response.json();
    if (info?.pid !== registration.pid || info?.version !== registration.version) return void 0;
    return { url: registration.url, headers, fetch };
  } catch {
    return void 0;
  }
}

// packages/integration-kit/src/contract.ts
var MAX_OFFERS = 16;
var LABEL_MAX = 120;
var DETAIL_MAX = 300;
var APP_VERSION_MAX = 64;
var SEMVER_PATTERN = "^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?(\\+[0-9A-Za-z.-]+)?$";
var DISPLAY_PATTERN = "^[^/\\\\\\p{Cc}]+$";
var HANDLE_PATTERN = "^[^\\p{Cc}]+$";
var CONTROL_PATTERN = "[\\p{Cc}]";
var OFFER_ID_PATTERN = "^[A-Za-z0-9_-]{8,64}$";
var SESSION_ID_PATTERN = "^[A-Za-z0-9_-]{1,128}$";
var GENERATION_PATTERN = "^[A-Za-z0-9_-]{1,128}(?![\\s\\S])";
var semver = () => ({ type: "string", maxLength: 64, pattern: SEMVER_PATTERN });
var display = (maxLength) => ({ type: "string", minLength: 1, maxLength, pattern: DISPLAY_PATTERN });
var empty = () => ({ type: "object", additionalProperties: false, properties: {} });
var outcome = (values) => ({
  type: "object",
  required: ["outcome"],
  properties: { outcome: { enum: values } }
});
var bindingAuthority = {
  type: "object",
  additionalProperties: false,
  required: ["serviceGeneration", "registryGeneration", "revision"],
  properties: {
    serviceGeneration: { type: "string", pattern: GENERATION_PATTERN },
    registryGeneration: { type: "string", pattern: GENERATION_PATTERN },
    revision: { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER }
  }
};
var publicBinding = {
  type: "object",
  additionalProperties: false,
  required: ["offerID", "label"],
  properties: {
    offerID: { type: "string", pattern: `${OFFER_ID_PATTERN}(?![\\s\\S])` },
    label: display(LABEL_MAX)
  }
};
var RPC_SCHEMAS = {
  "status.input": empty(),
  "status.output": {
    type: "object",
    required: ["contract", "integration"],
    properties: {
      contract: { const: 1 },
      integration: {
        type: "object",
        required: ["id", "version", "family", "spec"],
        properties: {
          id: { type: "string", pattern: "^[a-z][a-z0-9-]{0,31}$" },
          version: semver(),
          family: { enum: ["native", "vendor-mcp", "api"] },
          spec: { const: 0 }
        }
      },
      host: {
        type: "object",
        required: ["state"],
        properties: {
          state: { enum: ["absent", "incompatible", "outdated", "ok", "unknown", "unsupported"] },
          partVersion: semver(),
          expectedRange: { type: "string", minLength: 1, maxLength: 64, pattern: "^[0-9xX*^~<>=|. -]+$" },
          appVersion: display(APP_VERSION_MAX),
          action: { enum: ["install", "update"] }
        }
      },
      connection: {
        type: "object",
        required: ["state"],
        properties: {
          state: { enum: ["none", "available", "attached", "connected", "signed_out", "error"] },
          offers: { type: "integer", minimum: 0, maximum: MAX_OFFERS },
          attachedSessions: { type: "integer", minimum: 0, maximum: 1e4 }
        }
      },
      notices: {
        type: "array",
        maxItems: 8,
        uniqueItems: true,
        items: { type: "string", pattern: "^[a-z][a-z0-9_]{0,31}$" }
      }
    }
  },
  "installHost.input": { type: "object", additionalProperties: false, properties: { target: { const: "default" } } },
  "installHost.output": {
    type: "object",
    required: ["outcome"],
    properties: {
      outcome: { enum: ["installed", "updated", "unchanged", "refused", "failed"] },
      detail: display(DETAIL_MAX)
    }
  },
  "hosts.input": empty(),
  "hosts.output": {
    type: "object",
    required: ["offers"],
    properties: {
      offers: {
        type: "array",
        maxItems: MAX_OFFERS,
        items: {
          type: "object",
          required: ["offerID", "label", "protocol"],
          properties: {
            offerID: { type: "string", pattern: OFFER_ID_PATTERN },
            label: display(LABEL_MAX),
            document: display(LABEL_MAX),
            appVersion: display(APP_VERSION_MAX),
            protocol: { enum: ["ok", "incompatible"] }
          }
        }
      }
    }
  },
  "attachHost.input": {
    type: "object",
    additionalProperties: false,
    required: ["offerID", "sessionID"],
    properties: {
      offerID: { type: "string", pattern: OFFER_ID_PATTERN },
      sessionID: { type: "string", pattern: SESSION_ID_PATTERN }
    }
  },
  "attachHost.output": outcome(["attached", "busy", "gone", "refused"]),
  "detachHost.input": {
    type: "object",
    additionalProperties: false,
    required: ["sessionID"],
    properties: { sessionID: { type: "string", pattern: SESSION_ID_PATTERN } }
  },
  "detachHost.output": outcome(["detached", "none"]),
  "bindingRead.input": {
    type: "object",
    additionalProperties: false,
    required: ["sessionID"],
    properties: { sessionID: { type: "string", pattern: `${SESSION_ID_PATTERN}(?![\\s\\S])` } }
  },
  "bindingRead.output": {
    type: "object",
    oneOf: [
      {
        type: "object",
        additionalProperties: false,
        required: ["state", "authority", "binding"],
        properties: { state: { const: "attached" }, authority: bindingAuthority, binding: publicBinding }
      },
      {
        type: "object",
        additionalProperties: false,
        required: ["state", "authority"],
        properties: { state: { const: "none" }, authority: bindingAuthority }
      },
      {
        type: "object",
        additionalProperties: false,
        required: ["state"],
        properties: { state: { const: "unknown" }, authority: bindingAuthority }
      }
    ]
  },
  "advertise.output": outcome(["accepted", "renewed", "refused"]),
  "withdraw.output": outcome(["withdrawn", "none"]),
  "status_changed.event": empty(),
  "hosts_changed.event": empty()
};
var OPAQUE_INPUT = { type: "object" };
function withoutPatterns(value) {
  if (Array.isArray(value)) return value.map(withoutPatterns);
  if (typeof value !== "object" || value === null) return value;
  return Object.fromEntries(
    Object.entries(value).filter(([key, item]) => !(key === "pattern" && typeof item === "string")).map(([key, item]) => [key, withoutPatterns(item)])
  );
}
function rpcDefinition(rpcID, family) {
  const schemas = RPC_SCHEMAS;
  const schema = (name) => withoutPatterns(schemas[name] ?? OPAQUE_INPUT);
  const io = (method, input2) => ({
    input: input2 ? structuredClone(input2) : schema(`${method}.input`),
    output: schema(`${method}.output`)
  });
  const event = (name) => ({ schema: { ...schema(`${name}.event`), type: "object" } });
  const methods = { status: io("status") };
  const events = { status_changed: event("status_changed") };
  if (family === "native") {
    methods.installHost = io("installHost");
    methods.hosts = io("hosts");
    methods.attachHost = io("attachHost");
    methods.detachHost = io("detachHost");
    methods.bindingRead = io("bindingRead");
    methods.advertise = io("advertise", OPAQUE_INPUT);
    methods.withdraw = io("withdraw", OPAQUE_INPUT);
    events.hosts_changed = event("hosts_changed");
  }
  return { id: rpcID, methods, events };
}
var DISPLAY = new RegExp(DISPLAY_PATTERN, "u");
var HANDLE = new RegExp(HANDLE_PATTERN, "u");
function boundedDetail(value) {
  const clean = value.replace(/[/\\]/g, " ").replace(new RegExp(CONTROL_PATTERN, "gu"), " ").replace(/\s+/g, " ").trim();
  const bounded = [...clean].slice(0, DETAIL_MAX).join("").trim();
  return bounded.length > 0 ? bounded : void 0;
}

// packages/integration-kit/src/host-client.ts
var import_node_crypto = require("node:crypto");
var import_node_net = __toESM(require("node:net"), 1);
var HOST_ADDRESS = "127.0.0.1";
var MAX_REQUEST_BYTES = 1024 * 1024;
var MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
var DEFAULT_HOST_TIMEOUT_MS = 3e4;
var HOST_ERROR_CODES = [
  "unauthorized",
  "invalid_request",
  "method_not_found",
  "method_disabled",
  "invalid_args",
  "stale_handle",
  "stale_revision",
  "expectation_failed",
  "mode_conflict",
  "busy",
  "quarantined",
  "permission_denied",
  "internal"
];
var HostError = class extends Error {
  code;
  // The host's own explanation of a refusal, as bounded display text; never the endpoint.
  detail;
  // The details the host gave with its refusal (`error.data`, a JSON object), such as the current revision.
  data;
  constructor(code, message, detail, data) {
    super(message);
    this.name = "HostError";
    this.code = code;
    this.detail = detail;
    this.data = data;
  }
};
var MESSAGE_TEXT_MAX = 300;
var MESSAGE_DATA_MAX = 2e3;
function refusalText(message) {
  if (typeof message !== "string") return void 0;
  const clean = message.replace(new RegExp("\\p{Cc}", "gu"), " ").replace(/\s+/g, " ").trim();
  return clean ? [...clean].slice(0, MESSAGE_TEXT_MAX).join("") : void 0;
}
function refusalData(data) {
  if (typeof data !== "object" || data === null || Array.isArray(data) || !Object.keys(data).length) return void 0;
  return data;
}
function refusalMessage(code, text, data) {
  let message = `Host refused the request (${code})${text ? `: ${text}` : "."}`;
  if (data) {
    const json2 = JSON.stringify(data);
    message += ` ${json2.length > MESSAGE_DATA_MAX ? `${json2.slice(0, MESSAGE_DATA_MAX)}\u2026` : json2}`;
  }
  return message;
}
async function requestHost(endpoint, method, params = {}, options = {}) {
  if (endpoint.host !== HOST_ADDRESS) throw new HostError("invalid_request", "Hosts listen on 127.0.0.1 only.");
  const id = (0, import_node_crypto.randomUUID)();
  const line = `${JSON.stringify({ id, token: endpoint.token, method, params })}
`;
  if (Buffer.byteLength(line) > MAX_REQUEST_BYTES) throw new HostError("invalid_request", "Host request is too large.");
  const timeoutMs = options.timeoutMs ?? DEFAULT_HOST_TIMEOUT_MS;
  return await new Promise((resolve, reject) => {
    const socket = import_node_net.default.createConnection({ host: HOST_ADDRESS, port: endpoint.port });
    let buffer = Buffer.alloc(0);
    let settled = false;
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", abort);
      socket.destroy();
      if (error) reject(error);
      else resolve(result);
    };
    const abort = () => finish(new HostError("cancelled", "Host request cancelled."));
    const timer = setTimeout(() => finish(new HostError("timeout", "Host request timed out.")), timeoutMs);
    options.signal?.addEventListener("abort", abort, { once: true });
    if (options.signal?.aborted) return abort();
    socket.on("connect", () => socket.write(line));
    socket.on("data", (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      const newline = buffer.indexOf(10);
      if (newline < 0) {
        if (buffer.byteLength > MAX_RESPONSE_BYTES)
          finish(new HostError("invalid_response", "Host response too large."));
        return;
      }
      let envelope;
      try {
        envelope = JSON.parse(buffer.subarray(0, newline).toString("utf8"));
      } catch {
        return finish(new HostError("invalid_response", "Host returned malformed JSON."));
      }
      if (typeof envelope !== "object" || envelope === null || Array.isArray(envelope)) {
        return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      }
      const response = envelope;
      if (response.id !== id) return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      if (response.ok === false) {
        const raw = response.error?.code;
        const code = typeof raw === "string" && HOST_ERROR_CODES.includes(raw) ? raw : "internal";
        const detail = typeof response.error?.message === "string" ? boundedDetail(response.error.message) : void 0;
        const data = refusalData(response.error?.data);
        const message = refusalMessage(code, refusalText(response.error?.message), data);
        return finish(new HostError(code, message, detail, data));
      }
      if (response.ok !== true || !("result" in response)) {
        return finish(new HostError("invalid_response", "Host returned an invalid envelope."));
      }
      finish(null, response.result);
    });
    socket.on("error", () => finish(new HostError("unreachable", "Host is unreachable.")));
    socket.on("end", () => finish(new HostError("unreachable", "Host closed the connection.")));
  });
}

// packages/integration-kit/src/panel.ts
var PanelError = class extends Error {
};
function briefly(error) {
  const text = String(error?.message ?? error ?? "unknown error").split(/\r?\n/)[0]?.replace(/\b[0-9a-f]{32,}\b/gi, "\u2026").replace(/(basic|bearer)\s+\S+/gi, "$1 \u2026").replace(/\b(port\s+|:)\d{2,5}\b/gi, "$1\u2026").slice(0, 240);
  return `${text || "unknown error"}${/[.!?]$/.test(text ?? "") ? "" : "."}`;
}
var modelKey = (model) => model ? `${model.providerID}/${model.id}${model.variant ? `#${model.variant}` : ""}` : "";
function history(messages) {
  return messages.flatMap((message) => {
    if (message.type === "user") return [{ role: "user", text: message.text ?? "" }];
    if (message.type !== "assistant") return [];
    return (message.content ?? []).flatMap((part) => {
      if (part.type === "text") return [{ role: "assistant", text: part.text ?? "" }];
      if (part.type === "tool") return [{ role: "tool", text: `${part.name} / ${part.state?.status ?? "unknown"}` }];
      return [];
    });
  });
}
function createPanel(config, deps) {
  const requestHost2 = deps.requestHost ?? requestHost;
  const offerWaitMs = deps.offerWaitMs ?? 3e4;
  const checkEveryMs = deps.checkEveryMs ?? 5e3;
  const channels = /* @__PURE__ */ new Map();
  let client;
  let registration;
  let rpc = {};
  const event = (c, name, data) => deps.send({ channel: c.id, event: name, data });
  const options = (c) => ({
    location: { directory: c.directory },
    signal: AbortSignal.timeout(3e3)
  });
  const host = (c, method) => config.hostControls === false ? Promise.resolve() : requestHost2(c.host, method, { script_handle: c.handle, session_id: c.sessionID }, { timeoutMs: 2e3 });
  async function api() {
    if (client) return client;
    const found = await deps.discover(registration);
    if (!found) throw new PanelError("Start OpenCode before connecting the panel.");
    client = found;
    rpc = found.rpc(rpcDefinition(config.rpcID, "native"));
    return client;
  }
  async function findOffer(c) {
    const until = Date.now() + offerWaitMs;
    for (; ; ) {
      let result;
      try {
        result = await rpc.hosts?.({}, options(c));
      } catch (error) {
        if (!/RPC is unavailable/i.test(String(error?.message ?? error)) || Date.now() > until)
          throw error;
        await new Promise((resolve) => setTimeout(resolve, 1e3));
        continue;
      }
      const offers = (result?.offers ?? []).filter(
        (offer) => offer.label === c.label
      );
      if (offers.length > 1)
        throw new PanelError(
          `Several ${config.duplicateOffer} offer ${c.label}: attach this conversation from OpenCode (${config.app.toLowerCase()}_hosts).`
        );
      if (offers[0]) return offers[0];
      if (Date.now() > until)
        throw new PanelError(`This ${config.document} is not offered to OpenCode yet; choose Connect again.`);
      await new Promise((resolve) => setTimeout(resolve, 1e3));
    }
  }
  async function attached(c) {
    const read = await rpc.bindingRead?.({ sessionID: c.sessionID }, options(c));
    return read?.state === "attached" && read.binding?.offerID === c.offerID;
  }
  async function markedSession(service, directory, key) {
    let cursor;
    for (let page = 0; page < 10; page += 1) {
      const listed = await service.session.list({ directory, order: "desc", limit: 100, cursor });
      const found = listed.data.find(
        (candidate) => !candidate.time?.archived && candidate.metadata?.[config.marker] === key
      );
      if (found) return found;
      cursor = listed.cursor.next ?? void 0;
      if (!cursor) return void 0;
    }
    return void 0;
  }
  async function close(c) {
    if (channels.get(c.id) === c) channels.delete(c.id);
    if (c.timer) clearInterval(c.timer);
    c.abort.abort();
    await host(c, "cancel").catch(() => {
    });
    await attached(c).then((still) => still ? rpc.detachHost?.({ sessionID: c.sessionID }, options(c)) : void 0).catch(() => {
    });
  }
  function forward(c, type, data) {
    if (type === "session.model.selected") {
      c.model = data.model;
      event(c, "model", { selected: modelKey(c.model) });
    } else if (config.agent && type === "session.agent.selected") event(c, "agent", { agent: data.agent ?? null });
    else if (config.consoleEvents && type === "session.step.started") {
      c.model = data.model;
      event(c, "profile", { agent: data.agent, model: modelKey(c.model) });
    } else if (type === "session.execution.started") event(c, "status", { state: "busy" });
    else if (type === "session.text.started") event(c, "assistant_start", {});
    else if (type === "session.text.delta") event(c, "assistant_delta", { text: data.delta ?? "" });
    else if (type === "session.text.ended") event(c, "assistant_end", {});
    else if (type === "session.tool.input.started") {
      c.tools.set(String(data.id), { name: String(data.name ?? "tool"), started: performance.now() });
      event(c, "tool", { id: data.id, name: data.name, state: "starting" });
    } else if (type === "session.tool.success" || type === "session.tool.failed") {
      const tool = c.tools.get(String(data.id));
      c.tools.delete(String(data.id));
      event(c, "tool", {
        id: data.id,
        name: tool?.name,
        state: type === "session.tool.success" ? "completed" : "failed",
        ...config.consoleEvents && tool ? { duration_ms: Math.round(performance.now() - tool.started) } : {}
      });
    } else if (type === "permission.asked")
      event(c, "permission", { request_id: data.id, action: data.action, resources: data.resources ?? [] });
    else if (config.consoleEvents && type === "permission.replied")
      event(c, "permission_done", { request_id: data.requestID });
    else if (type === "session.execution.succeeded" || type === "session.idle") event(c, "status", { state: "idle" });
    else if (type === "session.execution.interrupted" || type === "session.execution.failed") {
      if (type === "session.execution.failed") event(c, "error", { message: "OpenCode execution failed." });
      event(c, "status", {
        state: "idle",
        ...config.consoleEvents && type === "session.execution.interrupted" ? { interrupted: true } : {}
      });
      void host(c, "cancel").catch(() => {
      });
    }
  }
  async function stream(c, service) {
    try {
      for await (const item of service.event.subscribe({ signal: c.abort.signal })) {
        const data = item.data;
        if (data?.sessionID === c.sessionID) forward(c, item.type, data);
      }
    } catch {
    }
    if (!c.abort.signal.aborted)
      event(c, config.consoleEvents ? "disconnected" : "error", {
        message: "OpenCode disconnected; choose Connect to reconnect."
      });
  }
  function watch(c) {
    let warned = false;
    c.timer = setInterval(() => {
      if (c.checking) return;
      c.checking = true;
      void api().then(() => attached(c)).then((still) => {
        if (!still) throw new Error("detached");
        warned = false;
      }).catch(() => {
        client = void 0;
        if (!warned && channels.get(c.id) === c)
          event(c, config.consoleEvents ? "disconnected" : "error", {
            message: "Conversation detached or service unavailable; choose Connect to reconnect."
          });
        warned = true;
      }).finally(() => {
        c.checking = false;
      });
    }, checkEveryMs);
    c.timer.unref?.();
  }
  const step = async (doing, work) => {
    try {
      return await work();
    } catch (error) {
      if (error instanceof PanelError) throw error;
      throw new PanelError(
        `Connect failed while ${doing}: ${briefly(error)} Check that OpenCode runs, then choose Connect.`
      );
    }
  };
  async function connect(id, params, fresh) {
    const previous = channels.get(id);
    if (previous) await close(previous);
    if (params.host !== "127.0.0.1" || !Number.isInteger(params.port) || !/^[0-9a-f]{64}$/.test(String(params.token)))
      throw new Error("Invalid host endpoint.");
    const directory = String(params.directory ?? "");
    const label = String(params.offer_label ?? "");
    const key = String(params[config.keyField] ?? "");
    const handle = String(params.script_handle ?? "");
    if (!directory || !label || !key || !handle) throw new Error("Incomplete connect request.");
    if (config.hostControls === false) {
      const next = typeof params.registration === "string" ? params.registration : void 0;
      if (next !== registration) client = void 0;
      registration = next;
    }
    const service = await step("reaching OpenCode", api);
    const known = fresh ? void 0 : await step(`finding this ${config.document}'s conversation`, () => markedSession(service, directory, key));
    const session = known ?? await step(
      `creating this ${config.document}'s conversation`,
      () => service.session.create({
        title: `${config.app}: ${String(params[config.nameField] || config.defaultName)}`,
        location: { directory },
        metadata: { [config.marker]: key }
      })
    );
    const c = {
      id,
      directory,
      sessionID: session.id,
      label,
      offerID: "",
      host: { host: "127.0.0.1", port: Number(params.port), token: String(params.token) },
      handle,
      abort: new AbortController(),
      checking: false,
      tools: /* @__PURE__ */ new Map(),
      model: session.model
    };
    try {
      const offer = await step(`finding this ${config.document}'s offer`, () => findOffer(c));
      const result = await step(
        `attaching the conversation to this ${config.document}`,
        async () => rpc.attachHost?.({ offerID: offer.offerID, sessionID: c.sessionID }, options(c))
      );
      if (result?.outcome === "busy")
        throw new PanelError("This conversation is attached to another application; detach it there first.");
      if (result?.outcome !== "attached") throw new PanelError(`${config.app} attachment was refused.`);
      c.offerID = offer.offerID;
      channels.set(id, c);
      watch(c);
      void stream(c, service);
      const [messages, models, configured, active] = await step(
        "loading the conversation",
        () => Promise.all([
          service.message.list({ sessionID: c.sessionID, order: "desc", limit: 200 }),
          service.model.list({ location: { directory } }),
          service.model.default({ location: { directory } }),
          service.session.active()
        ])
      );
      if (!c.model && configured.data) c.model = configured.data;
      event(c, "session", {
        id: c.sessionID,
        resumed: Boolean(known),
        model: modelKey(c.model),
        ...config.agent ? { agent: session.agent ?? null } : {},
        workspace: directory
      });
      event(c, "models", {
        selected: modelKey(c.model),
        models: models.data.filter((model) => model.enabled).map((model) => ({ id: model.id, provider_id: model.providerID, name: model.name }))
      });
      event(c, "history", { messages: history([...messages.data].reverse()) });
      event(c, "status", {
        state: active[c.sessionID]?.type === "running" ? "busy" : "idle"
      });
    } catch (error) {
      await close(c);
      throw error;
    }
  }
  async function act(c, method, params) {
    if (method === "close") return await close(c);
    const service = await api();
    if (method === "interrupt") {
      await host(c, "cancel").catch(() => {
      });
      await service.session.interrupt({ sessionID: c.sessionID, resume: false });
    } else if (method === "prompt") {
      if (!await attached(c)) throw new PanelError(`${config.app} was detached; choose Connect to attach again.`);
      await host(c, "resume");
      await service.session.prompt({ sessionID: c.sessionID, text: String(params.text ?? "") });
    } else if (method === "switch_model") {
      const key = String(params.model ?? "");
      const catalog = await service.model.list({ location: { directory: c.directory } });
      const selected = catalog.data.find((model) => model.enabled && `${model.providerID}/${model.id}` === key);
      if (!selected) throw new PanelError("This model is not available in this workspace.");
      c.model = { id: selected.id, providerID: selected.providerID };
      await service.session.switchModel({ sessionID: c.sessionID, model: c.model });
      event(c, "model", { selected: modelKey(c.model) });
    } else if (method === "permission_reply") {
      const decision = params.reply;
      if (decision !== "once" && decision !== "reject") throw new Error("Invalid permission answer.");
      await service.permission.reply({ sessionID: c.sessionID, requestID: String(params.request_id), decision });
    } else throw new Error("Unknown panel action.");
  }
  async function dispatch(request2) {
    try {
      const params = request2.params ?? {};
      if (request2.method === "connect" || request2.method === "new_session")
        await connect(request2.channel, params, request2.method === "new_session");
      else {
        const c = channels.get(request2.channel);
        if (c) await act(c, request2.method, params);
        else if (request2.method !== "close") throw new PanelError("Choose Connect first.");
      }
      deps.send({ id: request2.id, result: {} });
    } catch (error) {
      deps.send({
        channel: request2.channel,
        event: "error",
        data: {
          message: error instanceof PanelError ? error.message : `The panel action failed: ${briefly(error)} Check that OpenCode runs, then choose Connect.`
        }
      });
      deps.send({ id: request2.id, error: { message: "Panel action failed." } });
    }
  }
  return {
    dispatch,
    closeAll: () => Promise.allSettled([...channels.values()].map(close))
  };
}

// integrations/godot/plugin/src/sidecar-core.ts
var PROJECT_MARKER = "opencode_godot_project";
var createPanel2 = (deps) => createPanel(
  {
    app: "Godot",
    rpcID: "neuralnomads.godot",
    marker: PROJECT_MARKER,
    document: "project",
    keyField: "project_key",
    nameField: "project_name",
    defaultName: "project",
    duplicateOffer: "Godot editors",
    agent: true
  },
  deps
);

// integrations/godot/plugin/src/sidecar.ts
var send = (value) => process.stdout.write(`${JSON.stringify(value)}
`);
var panel = createPanel2({
  send,
  discover: async () => {
    const endpoint = await discoverService();
    return endpoint && exports_client.make({ baseUrl: endpoint.url, headers: endpoint.headers, fetch: endpoint.fetch });
  }
});
var queues = /* @__PURE__ */ new Map();
var input = import_node_readline.default.createInterface({ input: process.stdin, crlfDelay: Infinity });
input.on("line", (line) => {
  if (!line.trim()) return;
  try {
    if (Buffer.byteLength(line) > 1024 * 1024) throw new Error("Request too large");
    const request2 = JSON.parse(line);
    if (!request2.id || !request2.channel || !request2.method) throw new Error("Invalid request");
    const next = (queues.get(request2.channel) ?? Promise.resolve()).then(() => panel.dispatch(request2));
    queues.set(request2.channel, next);
    void next.finally(() => {
      if (queues.get(request2.channel) === next) queues.delete(request2.channel);
    });
  } catch {
    send({ error: { message: "Invalid panel request." } });
  }
});
input.on("close", () => {
  void panel.closeAll().finally(() => process.exit(0));
});
